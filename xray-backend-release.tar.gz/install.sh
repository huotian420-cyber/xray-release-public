#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_NAME="$(basename "$0")"

INSTALL_DIR="/opt/xray-backend"
BIN_NAME="xray-backend"
CONFIG_FILE="${INSTALL_DIR}/config.conf"
XRAY_ASSET_DIR="/usr/local/share/xray"
STATE_DIR="/var/lib/xray-backend"
JOURNALD_RETENTION_CONF="/etc/systemd/journald.conf.d/99-xray-backend-retention.conf"

BACKEND_SERVICE="xray-backend"
SSL_RENEW_SERVICE="xray-ssl-renew"
SSL_RENEW_SCRIPT="/usr/local/bin/xray-ssl-renew.sh"
XRAY_PINNED_VERSION="v26.6.1"
MIHOMO_PINNED_VERSION="v1.19.26"
ACME_SH_TAG="3.1.2"
ACME_SH_COMMIT="40290ad"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

OS="unknown"
BINARY=""
XRAY_ARCH=""
SERVER_IP=""
XRAY_VERSION=""
MIHOMO_VERSION=""
MIHOMO_ARCH=""
SSL_ISSUER_TOOL=""

CAMOUFLAGE_SITES=(
  "www.tsinghua.edu.cn"
  "www.pku.edu.cn"
  "www.zju.edu.cn"
  "www.sjtu.edu.cn"
  "www.fudan.edu.cn"
  "www.ustc.edu.cn"
  "www.nju.edu.cn"
  "www.seu.edu.cn"
  "www.whu.edu.cn"
  "www.bit.edu.cn"
  "www.xjtu.edu.cn"
  "www.buaa.edu.cn"
  "www.scut.edu.cn"
  "www.hit.edu.cn"
  "www.csdn.net"
  "www.oschina.net"
  "www.runoob.com"
  "www.infoq.cn"
  "www.cnblogs.com"
  "juejin.cn"
)

log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
  echo -e "\n${BLUE}==>${NC} $1"
}

require_root() {
  if [ "$EUID" -ne 0 ]; then
    log_error "请使用 root 权限运行此脚本。"
    exit 1
  fi
}

bool_env_enabled() {
  case "$(printf "%s" "${1:-}" | tr '[:upper:]' '[:lower:]')" in
    1|true|yes|y|on) return 0 ;;
    *) return 1 ;;
  esac
}

purge_existing_install_if_requested() {
  if ! bool_env_enabled "${XRAY_BACKEND_PURGE:-${PURGE_EXISTING:-}}"; then
    return 0
  fi

  log_warn "XRAY_BACKEND_PURGE=1 已启用，将清空旧安装数据后重新安装。"
  log_warn "旧节点、订阅 token、流量状态会被删除。"

  systemctl disable --now "${BACKEND_SERVICE}.service" >/dev/null 2>&1 || true
  systemctl disable --now "${SSL_RENEW_SERVICE}.timer" >/dev/null 2>&1 || true
  systemctl disable --now xray-weekly-update.timer >/dev/null 2>&1 || true
  systemctl disable --now xray-cf-preferred-refresh.timer >/dev/null 2>&1 || true
  systemctl disable --now xray-security-monitor.timer >/dev/null 2>&1 || true
  systemctl disable --now xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true

  pkill -f "${INSTALL_DIR}/xray-core" >/dev/null 2>&1 || true
  pkill -f "${INSTALL_DIR}/${BIN_NAME}" >/dev/null 2>&1 || true

  rm -rf "${INSTALL_DIR}" "${STATE_DIR}"
  rm -f "/etc/systemd/system/${BACKEND_SERVICE}.service"
  rm -f "/etc/systemd/system/${SSL_RENEW_SERVICE}.service" "/etc/systemd/system/${SSL_RENEW_SERVICE}.timer"
  rm -f /etc/systemd/system/xray-weekly-update.service /etc/systemd/system/xray-weekly-update.timer
  rm -f /etc/systemd/system/xray-cf-preferred-refresh.service /etc/systemd/system/xray-cf-preferred-refresh.timer
  rm -f /etc/systemd/system/xray-security-monitor.service /etc/systemd/system/xray-security-monitor.timer
  rm -f /etc/systemd/system/xray-fail2ban-daily-report.service /etc/systemd/system/xray-fail2ban-daily-report.timer
  rm -f /usr/local/bin/xy
  rm -f /usr/local/bin/xray-weekly-update.sh /usr/local/bin/xray-cf-preferred-refresh.sh
  rm -f /usr/local/bin/xray-security-monitor.sh /usr/local/bin/xray-fail2ban-daily-report.sh
  rm -f "${SSL_RENEW_SCRIPT}"

  systemctl daemon-reload >/dev/null 2>&1 || true
}

read_cfg() {
  local key="$1"
  if [ -f "$CONFIG_FILE" ]; then
    grep "^${key}=" "$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

normalize_panel_domain_list() {
  local raw="$1"
  local normalized="" token domain
  raw="$(printf "%s" "$raw" | tr ';| ' ',,,')"
  IFS=',' read -r -a tokens <<< "$raw"
  for token in "${tokens[@]}"; do
    domain="$(mgr_normalize_access_host "$token")"
    [ -n "$domain" ] || continue
    if ! mgr_is_valid_access_host "$domain"; then
      continue
    fi
    case ",${normalized}," in
      *,"${domain}",*) ;;
      *)
        if [ -n "$normalized" ]; then
          normalized="${normalized},${domain}"
        else
          normalized="$domain"
        fi
        ;;
    esac
  done
  printf "%s" "$normalized"
}

normalize_cf_preferred_source_urls() {
  local raw="$1"
  local normalized="" token source_url
  raw="$(printf "%s" "$raw" | tr '\r\n\t ' ',,,,')"
  IFS=',' read -r -a tokens <<< "$raw"
  for token in "${tokens[@]}"; do
    source_url="$(printf "%s" "$token" | tr -d '\r\n\t ')"
    case "$source_url" in
      http://*|https://*) ;;
      *) continue ;;
    esac
    if [ "${#source_url}" -gt 2048 ] || [[ "$source_url" == *[' "'"'"'`$;|&<>\\']* ]]; then
      continue
    fi
    case ",${normalized}," in
      *,"${source_url}",*) ;;
      *)
        if [ -n "$normalized" ]; then
          normalized="${normalized},${source_url}"
        else
          normalized="$source_url"
        fi
        ;;
    esac
  done
  printf "%s" "$normalized"
}

is_legacy_cf_preferred_source_url() {
  local normalized
  normalized="$(normalize_cf_preferred_source_urls "$1")"
  case "$normalized" in
    https://cdn.tangsengai.com|https://cdn.tangsengai.com/)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

save_cfg() {
  local key="$1"
  local value="$2"
  local tmp_file

  if [ -z "$key" ] || [[ ! "$key" =~ ^[A-Z0-9_]+$ ]]; then
    log_error "配置键名无效: ${key}"
    return 1
  fi
  case "$value" in
    *$'\r'*|*$'\n'*)
      log_error "配置 ${key} 包含不支持的换行或空字符。"
      return 1
      ;;
  esac
  case "$key" in
    CF_PREFERRED_DOMAINS)
      value="$(normalize_panel_domain_list "$value")"
      ;;
    CF_PREFERRED_DOMAINS_SOURCE_URL)
      value="$(normalize_cf_preferred_source_urls "$value")"
      ;;
  esac
  mkdir -p "$(dirname "$CONFIG_FILE")"
  tmp_file="$(mktemp "${CONFIG_FILE}.tmp.XXXXXX")" || {
    log_error "创建临时配置文件失败。"
    return 1
  }

  if [ -f "$CONFIG_FILE" ]; then
    if ! awk -v key="$key" -v value="$value" '
      BEGIN {
        updated = 0
      }
      index($0, key "=") == 1 {
        if (!updated) {
          print key "=" value
          updated = 1
        }
        next
      }
      {
        print
      }
      END {
        if (!updated) {
          print key "=" value
        }
      }
    ' "$CONFIG_FILE" > "$tmp_file"; then
      rm -f "$tmp_file"
      log_error "写入配置 ${key} 失败。"
      return 1
    fi
  else
    if ! printf "%s=%s\n" "$key" "$value" > "$tmp_file"; then
      rm -f "$tmp_file"
      log_error "初始化配置 ${key} 失败。"
      return 1
    fi
  fi

  if ! mv "$tmp_file" "$CONFIG_FILE"; then
    rm -f "$tmp_file"
    log_error "更新配置文件失败。"
    return 1
  fi

  harden_runtime_permissions
}

ensure_dir_permissions() {
  local dir="$1"
  local mode="$2"
  [ -n "$dir" ] || return 0
  mkdir -p "$dir"
  chmod "$mode" "$dir" 2>/dev/null || true
}

ensure_file_permissions() {
  local file="$1"
  local mode="$2"
  [ -n "$file" ] || return 0
  [ -f "$file" ] || return 0
  chmod "$mode" "$file" 2>/dev/null || true
}

harden_runtime_permissions() {
  local db_file="${INSTALL_DIR}/data.db"
  local backend_binary="${INSTALL_DIR}/${BIN_NAME}"

  ensure_dir_permissions "$INSTALL_DIR" 700
  ensure_dir_permissions "$(dirname "$CONFIG_FILE")" 700
  ensure_file_permissions "$CONFIG_FILE" 600
  ensure_file_permissions "$db_file" 600

  if [ -n "$BIN_NAME" ]; then
    ensure_file_permissions "$backend_binary" 700
  fi

  ensure_dir_permissions "$XRAY_ASSET_DIR" 755
  ensure_file_permissions "${XRAY_ASSET_DIR}/geoip.dat" 644
  ensure_file_permissions "${XRAY_ASSET_DIR}/geosite.dat" 644

  ensure_dir_permissions /etc/certs 700
  ensure_dir_permissions "$STATE_DIR" 700
}

configure_log_retention() {
  log_step "配置日志保留策略"

  mkdir -p /etc/systemd/journald.conf.d
  cat > "$JOURNALD_RETENTION_CONF" <<'EOF'
[Journal]
MaxRetentionSec=72h
SystemMaxUse=200M
RuntimeMaxUse=50M
EOF

  mkdir -p /etc/logrotate.d
  cat > /etc/logrotate.d/xray-backend <<'EOF'
/var/log/xray-weekly-update.log {
    daily
    rotate 3
    maxage 3
    missingok
    notifempty
    compress
    copytruncate
}

/var/log/auth.log /var/log/secure /var/log/fail2ban.log {
    daily
    rotate 3
    maxage 3
    missingok
    notifempty
    compress
    sharedscripts
}
EOF

  journalctl --vacuum-time=72h >/dev/null 2>&1 || true
  systemctl restart systemd-journald >/dev/null 2>&1 || true
}

detect_arch() {
  log_step "检测 CPU 架构"
  local arch
  arch="$(uname -m)"
  case "$arch" in
    x86_64)
      BINARY="xray-backend-linux-amd64"
      XRAY_ARCH="64"
      MIHOMO_ARCH="amd64"
      ;;
    aarch64|arm64)
      BINARY="xray-backend-linux-arm64"
      XRAY_ARCH="arm64-v8a"
      MIHOMO_ARCH="arm64"
      ;;
    *)
      log_error "暂不支持当前 CPU 架构: $arch"
      exit 1
      ;;
  esac
  log_info "CPU 架构: $arch"
  log_info "将使用二进制: $BINARY"
}

detect_os() {
  if [ -f /etc/debian_version ]; then
    OS="debian"
  elif [ -f /etc/redhat-release ]; then
    OS="centos"
  else
    OS="unknown"
  fi
  log_info "检测到系统: $OS"
}

check_binary() {
  local binary_path="${SCRIPT_DIR}/${BINARY}"
  if [ -f "$binary_path" ]; then
    return
  fi

  binary_path="${SCRIPT_DIR}/${BIN_NAME}"
  if [ -f "$binary_path" ]; then
    BINARY="${BIN_NAME}"
    return
  fi

  log_error "未找到可执行文件: ${SCRIPT_DIR}/${BINARY}"
  exit 1
}

fetch_public_ip() {
  local ip=""
  local curl_cmd=(curl -4 -fsS --connect-timeout 3 --max-time 6)

  if ! command -v curl >/dev/null 2>&1; then
    echo "unknown"
    return
  fi

  ip="$(${curl_cmd[@]} https://ifconfig.me 2>/dev/null | tr -d '[:space:]')" || true
  if [ -z "$ip" ]; then
    ip="$(${curl_cmd[@]} https://icanhazip.com 2>/dev/null | tr -d '[:space:]')" || true
  fi
  if [ -z "$ip" ]; then
    ip="$(${curl_cmd[@]} https://api.ipify.org 2>/dev/null | tr -d '[:space:]')" || true
  fi

  if [ -n "$ip" ]; then
    echo "$ip"
  else
    echo "unknown"
  fi
}

get_server_ip() {
  log_step "检测服务器公网 IP"
  SERVER_IP="$(fetch_public_ip)"
  log_info "服务器公网 IP: $SERVER_IP"
}

generate_random_suffix() {
  tr -dc 'a-z0-9' < /dev/urandom | head -c 10
}

pick_random_camouflage_site() {
  local index=$((RANDOM % ${#CAMOUFLAGE_SITES[@]}))
  echo "${CAMOUFLAGE_SITES[$index]}"
}

init_runtime_config() {
  mkdir -p "$INSTALL_DIR"

  local legacy_camouflage xray_mode tg_alert_enabled tg_alert_cooldown tg_traffic_alert_mbps security_alert_ingest_url security_alert_ingest_token
  local ping_block_enabled block_cn_traffic vps_display_name reality_sni_domain ssh_port
  local tls_node_network reality_node_network tls_xhttp_mode
  local subscription_enabled subscription_listen subscription_token public_ip
  local cf_preferred_domains cf_preferred_source_url
  legacy_camouflage="$(read_cfg "CAMOUFLAGE_SITE")"
  xray_mode="$(read_cfg "XRAY_MODE")"
  tg_alert_enabled="$(read_cfg "TG_ALERT_ENABLED")"
  tg_alert_cooldown="$(read_cfg "TG_ALERT_COOLDOWN")"
  tg_traffic_alert_mbps="$(read_cfg "TG_TRAFFIC_ALERT_MBPS")"
  security_alert_ingest_url="$(read_cfg "SECURITY_ALERT_INGEST_URL")"
  security_alert_ingest_token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")"
  ping_block_enabled="$(read_cfg "PING_BLOCK_ENABLED")"
  block_cn_traffic="$(read_cfg "BLOCK_CN_TRAFFIC")"
  vps_display_name="$(read_cfg "VPS_DISPLAY_NAME")"
  reality_sni_domain="$(read_cfg "REALITY_SNI_DOMAIN")"
  ssh_port="$(read_cfg "SSH_PORT")"
  tls_node_network="$(read_cfg "TLS_NODE_NETWORK")"
  reality_node_network="$(read_cfg "REALITY_NODE_NETWORK")"
  tls_xhttp_mode="$(read_cfg "TLS_NODE_XHTTP_MODE")"
  subscription_enabled="$(read_cfg "SUBSCRIPTION_ENABLED")"
  subscription_listen="$(read_cfg "SUBSCRIPTION_LISTEN")"
  subscription_token="$(read_cfg "SUBSCRIPTION_TOKEN")"
  public_ip="$(read_cfg "PUBLIC_IP")"
  cf_preferred_domains="$(read_cfg "CF_PREFERRED_DOMAINS")"
  cf_preferred_source_url="$(read_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL")"

  if [ -z "$xray_mode" ]; then
    xray_mode="reality"
  fi
  if [ -z "$vps_display_name" ]; then
    vps_display_name="$(hostname 2>/dev/null || echo "Xray 节点")"
  fi

  save_cfg "CAMOUFLAGE_SITE" "$legacy_camouflage"
  save_cfg "XRAY_MODE" "$xray_mode"
  save_cfg "VPS_DISPLAY_NAME" "$vps_display_name"
  if [ -z "$reality_sni_domain" ] && [ -n "$legacy_camouflage" ]; then
    save_cfg "REALITY_SNI_DOMAIN" "$legacy_camouflage"
  fi
  if ! [[ "$ssh_port" =~ ^[0-9]+$ ]] || [ "$ssh_port" -lt 1 ] || [ "$ssh_port" -gt 65535 ]; then
    save_cfg "SSH_PORT" "22"
  fi
  if [ -z "$tls_node_network" ]; then
    save_cfg "TLS_NODE_NETWORK" "ws"
  fi
  if [ -z "$reality_node_network" ]; then
    save_cfg "REALITY_NODE_NETWORK" "tcp"
  fi
  if [ -z "$tls_xhttp_mode" ]; then
    save_cfg "TLS_NODE_XHTTP_MODE" "auto"
  fi
  if [ -z "$(read_cfg "TLS_NODE_DECRYPTION")" ]; then
    save_cfg "TLS_NODE_DECRYPTION" "none"
  fi
  if [ -z "$(read_cfg "TLS_NODE_ENCRYPTION")" ]; then
    save_cfg "TLS_NODE_ENCRYPTION" "none"
  fi
  if [ -z "$(read_cfg "REALITY_NODE_DECRYPTION")" ]; then
    save_cfg "REALITY_NODE_DECRYPTION" "none"
  fi
  if [ -z "$(read_cfg "REALITY_NODE_ENCRYPTION")" ]; then
    save_cfg "REALITY_NODE_ENCRYPTION" "none"
  fi
  if [ -z "$tg_alert_enabled" ]; then
    save_cfg "TG_ALERT_ENABLED" "0"
  fi
  if ! [[ "$tg_alert_cooldown" =~ ^[0-9]+$ ]]; then
    save_cfg "TG_ALERT_COOLDOWN" "1800"
  fi
  if ! [[ "$tg_traffic_alert_mbps" =~ ^[0-9]+$ ]] || [ "$tg_traffic_alert_mbps" -lt 1 ]; then
    save_cfg "TG_TRAFFIC_ALERT_MBPS" "500"
  fi
  if [ -z "$security_alert_ingest_url" ]; then
    save_cfg "SECURITY_ALERT_INGEST_URL" ""
  fi
  if [ -z "$security_alert_ingest_token" ]; then
    save_cfg "SECURITY_ALERT_INGEST_TOKEN" ""
  fi
  if [ -z "$ping_block_enabled" ]; then
    save_cfg "PING_BLOCK_ENABLED" "1"
  fi
  if [ -z "$block_cn_traffic" ]; then
    save_cfg "BLOCK_CN_TRAFFIC" "0"
  fi
  if [ "$subscription_enabled" != "1" ]; then
    save_cfg "SUBSCRIPTION_ENABLED" "1"
  fi
  if [ "$subscription_listen" != "0.0.0.0:2096" ]; then
    save_cfg "SUBSCRIPTION_LISTEN" "0.0.0.0:2096"
  fi
  if ! is_valid_subscription_token_value "$subscription_token"; then
    save_generated_subscription_token
    subscription_token="$(read_cfg "SUBSCRIPTION_TOKEN")"
  fi
  if [ -n "$SERVER_IP" ] && [ "$SERVER_IP" != "unknown" ]; then
    save_cfg "PUBLIC_IP" "$SERVER_IP"
  elif [ -z "$public_ip" ]; then
    save_cfg "PUBLIC_IP" ""
  fi
  if [ -n "$cf_preferred_domains" ]; then
    save_cfg "CF_PREFERRED_DOMAINS" "$cf_preferred_domains"
  fi
  if is_legacy_cf_preferred_source_url "$cf_preferred_source_url"; then
    log_info "检测到旧 Cloudflare 优选公开源，已恢复为内置中国移动 CMCC 源。"
    save_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" ""
    cf_preferred_source_url=""
  fi
  if [ -n "$cf_preferred_source_url" ]; then
    save_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" "$cf_preferred_source_url"
  fi
  if [ -f "$CONFIG_FILE" ]; then
    local legacy_removed_key="SSH""_KNOCK_ENABLED"
    sed -i "/^${legacy_removed_key}=/d" "$CONFIG_FILE"
  fi

  harden_runtime_permissions
}

is_ping_block_enabled() {
  local value
  value="$(read_cfg "PING_BLOCK_ENABLED" | tr '[:upper:]' '[:lower:]')"
  if [ -z "$value" ] || [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ]; then
    return 0
  fi
  return 1
}

is_cn_traffic_block_enabled() {
  local value
  value="$(read_cfg "BLOCK_CN_TRAFFIC" | tr '[:upper:]' '[:lower:]')"
  if [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ] || [ "$value" = "on" ]; then
    return 0
  fi
  return 1
}

install_packages() {
  case "$OS" in
    debian)
      export DEBIAN_FRONTEND=noninteractive
      apt-get update -y
      apt-get upgrade -y
      apt-get install -y curl wget git unzip tar openssh-server fail2ban sqlite3 socat
      ;;
    centos)
      yum update -y
      yum install -y curl wget git unzip tar openssh-server sqlite socat
      yum install -y epel-release || true
      yum install -y fail2ban || true
      ;;
    *)
      log_warn "暂不识别当前系统，请手动安装依赖。"
      ;;
  esac
}

ensure_socat() {
  if command -v socat >/dev/null 2>&1; then
    return 0
  fi

  log_info "未检测到 socat，正在安装 ACME standalone 签发依赖。"
  case "$OS" in
    debian)
      export DEBIAN_FRONTEND=noninteractive
      if ! apt-get update -y || ! apt-get install -y socat; then
        log_error "自动安装 socat 失败，请先手动安装后再申请证书。"
        return 1
      fi
      ;;
    centos)
      if command -v dnf >/dev/null 2>&1; then
        if ! dnf install -y socat; then
          log_error "自动安装 socat 失败，请先手动安装后再申请证书。"
          return 1
        fi
      elif ! yum install -y socat; then
        log_error "自动安装 socat 失败，请先手动安装后再申请证书。"
        return 1
      fi
      ;;
    *)
      log_error "未检测到 socat，且当前系统无法自动安装，请先手动安装 socat。"
      return 1
      ;;
  esac

  if ! command -v socat >/dev/null 2>&1; then
    log_error "socat 安装后仍不可用，请检查系统包管理器。"
    return 1
  fi
}

download_file_with_fallback() {
  local url="$1"
  local output="$2"
  local label="$3"

  rm -f "$output"

  if command -v wget >/dev/null 2>&1; then
    if wget --tries=3 --timeout=30 --waitretry=2 --retry-connrefused --show-progress -O "$output" "$url"; then
      return 0
    fi
    log_warn "${label} 下载失败，准备回退到 curl。"
  fi

  if command -v curl >/dev/null 2>&1; then
    if curl -fL --connect-timeout 15 --max-time 300 --retry 3 --retry-delay 2 -o "$output" "$url"; then
      return 0
    fi
  fi

  rm -f "$output"
  return 1
}

sha256_file() {
  local file="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$file" | awk '{print $1}'
    return 0
  fi
  if command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$file" | awk '{print $NF}'
    return 0
  fi
  return 1
}

verify_file_sha256() {
  local file="$1"
  local expected="$2"
  local label="$3"
  local actual

  expected="$(printf "%s" "$expected" | tr '[:upper:]' '[:lower:]' | tr -d '\r\n ')"
  if ! [[ "$expected" =~ ^[a-f0-9]{64}$ ]]; then
    log_error "${label} 缺少有效 SHA256 校验值。"
    return 1
  fi
  actual="$(sha256_file "$file" | tr '[:upper:]' '[:lower:]' | tr -d '\r\n ')" || {
    log_error "未找到 sha256sum 或 openssl，无法校验 ${label}。"
    return 1
  }
  if [ "$actual" != "$expected" ]; then
    log_error "${label} SHA256 校验失败。"
    log_error "期望: ${expected}"
    log_error "实际: ${actual}"
    return 1
  fi
  log_info "${label} SHA256 校验通过。"
  return 0
}

extract_sha256_for_asset() {
  local digest_file="$1"
  local asset_name="$2"
  local escaped_name

  escaped_name="$(printf "%s" "$asset_name" | sed 's/[][\/.^$*+?{}()|]/\\&/g')"
  sed -n "s/.*\([A-Fa-f0-9]\{64\}\).*${escaped_name}.*/\1/p" "$digest_file" | head -n 1
}

github_release_asset_url() {
  local release_json="$1"
  local asset_name="$2"

  printf "%s\n" "$release_json" |
    awk -v asset="$asset_name" '
      $0 ~ /"browser_download_url"/ {
        url = $0
        sub(/^.*"browser_download_url"[[:space:]]*:[[:space:]]*"/, "", url)
        sub(/".*$/, "", url)
        name = url
        sub(/^.*\//, "", name)
        if (name == asset) {
          print url
          exit
        }
      }
    '
}

github_release_asset_digest() {
  local release_json="$1"
  local asset_name="$2"

  printf "%s\n" "$release_json" |
    awk -v asset="$asset_name" '
      $0 ~ /"name"/ {
        name = $0
        sub(/^.*"name"[[:space:]]*:[[:space:]]*"/, "", name)
        sub(/".*$/, "", name)
        in_asset = (name == asset)
      }
      in_asset && $0 ~ /"digest"/ {
        digest = $0
        sub(/^.*"digest"[[:space:]]*:[[:space:]]*"/, "", digest)
        sub(/".*$/, "", digest)
        sub(/^sha256:/, "", digest)
        print digest
        exit
      }
    '
}

download_github_asset_verified() {
  local release_json="$1"
  local asset_url="$2"
  local output="$3"
  local label="$4"
  local asset_name digest_name digest_url digest_path checksum_url checksum_path expected

  asset_name="${asset_url##*/}"
  expected="$(github_release_asset_digest "$release_json" "$asset_name" || true)"
  if [ -n "$expected" ]; then
    if ! download_file_with_fallback "$asset_url" "$output" "$label"; then
      return 1
    fi
    if ! verify_file_sha256 "$output" "$expected" "$label"; then
      rm -f "$output"
      return 1
    fi
    return 0
  fi

  digest_name="${asset_name}.dgst"
  digest_url="$(github_release_asset_url "$release_json" "$digest_name" || true)"
  if [ -n "$digest_url" ]; then
    digest_path="${output}.dgst"
    if ! download_file_with_fallback "$digest_url" "$digest_path" "${label} checksum"; then
      log_error "${label} 校验文件下载失败。"
      rm -f "$digest_path"
      return 1
    fi

    expected="$(extract_sha256_for_asset "$digest_path" "$asset_name" || true)"
    if [ -z "$expected" ]; then
      log_error "${label} 校验文件中未找到 ${asset_name} 的 SHA256。"
      rm -f "$digest_path"
      return 1
    fi

    if ! download_file_with_fallback "$asset_url" "$output" "$label"; then
      rm -f "$digest_path"
      return 1
    fi
    if ! verify_file_sha256 "$output" "$expected" "$label"; then
      rm -f "$digest_path" "$output"
      return 1
    fi

    rm -f "$digest_path"
    return 0
  fi

  checksum_url="$(printf "%s\n" "$release_json" |
    awk '
      $0 ~ /"browser_download_url"/ {
        url = $0
        sub(/^.*"browser_download_url"[[:space:]]*:[[:space:]]*"/, "", url)
        sub(/".*$/, "", url)
        lower = tolower(url)
        if (lower ~ /(sha256|checksum|checksums|sha256sum|sha256sums)/) {
          print url
          exit
        }
      }
    ' || true)"
  if [ -z "$checksum_url" ]; then
    log_error "${label} 未找到 SHA256 digest 或 checksum 资产，拒绝安装未校验的发行包。"
    return 1
  fi

  checksum_path="${output}.checksums"
  if ! download_file_with_fallback "$checksum_url" "$checksum_path" "${label} checksum"; then
    rm -f "$checksum_path"
    return 1
  fi

  expected="$(extract_sha256_for_asset "$checksum_path" "$asset_name" || true)"
  if [ -z "$expected" ]; then
    log_error "${label} checksum 中未找到 ${asset_name} 的 SHA256。"
    rm -f "$checksum_path"
    return 1
  fi

  if ! download_file_with_fallback "$asset_url" "$output" "$label"; then
    rm -f "$checksum_path"
    return 1
  fi
  if ! verify_file_sha256 "$output" "$expected" "$label"; then
    rm -f "$checksum_path" "$output"
    return 1
  fi

  rm -f "$checksum_path"
  return 0
}

is_valid_port_number() {
  local port="$1"
  [[ "$port" =~ ^[0-9]+$ ]] && [ "$port" -ge 1 ] && [ "$port" -le 65535 ]
}

get_configured_ssh_port() {
  local port
  port="$(read_cfg "SSH_PORT" | tr -d '\r\n ')"
  if is_valid_port_number "$port"; then
    echo "$port"
  else
    echo "22"
  fi
}

generate_subscription_token() {
  local token
  token="$(tr -dc 'a-zA-Z0-9' < /dev/urandom 2>/dev/null | head -c 32)"
  if [ "${#token}" -ne 32 ]; then
    return 1
  fi
  printf "%s" "$token"
}

is_valid_subscription_token_value() {
  local token="$1"
  [[ "$token" =~ ^[A-Za-z0-9._-]{16,256}$ ]]
}

save_generated_subscription_token() {
  local token
  if ! token="$(generate_subscription_token)" || [ -z "$token" ]; then
    log_error "无法从系统随机源生成订阅 token，拒绝写入弱 token。"
    return 1
  fi
  save_cfg "SUBSCRIPTION_TOKEN" "$token"
}

refresh_subscription_token() {
  local token
  token="$(generate_subscription_token)"
  if [ -z "$token" ]; then
    return 1
  fi
  save_cfg "SUBSCRIPTION_TOKEN" "$token"
  printf "%s\n" "$token"
}

refresh_subscription_token_on_managed_node_change() {
  if ! get_subscription_enabled; then
    return 0
  fi
  refresh_subscription_token
}

get_subscription_enabled() {
  local value
  value="$(read_cfg "SUBSCRIPTION_ENABLED" | tr '[:upper:]' '[:lower:]')"
  if [ -z "$value" ] || [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ] || [ "$value" = "on" ]; then
    return 0
  fi
  return 1
}

get_subscription_listen() {
  local listen
  listen="$(read_cfg "SUBSCRIPTION_LISTEN" | tr -d '\r\n ')"
  if [ -z "$listen" ]; then
    echo "0.0.0.0:2096"
    return
  fi
  echo "$listen"
}

get_subscription_token() {
  read_cfg "SUBSCRIPTION_TOKEN" | tr -d '\r\n '
}

get_subscription_port() {
  local listen
  listen="$(get_subscription_listen)"
  if [[ "$listen" =~ :([0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
    return
  fi
  echo "2096"
}

mgr_normalize_access_host() {
  local host="$1"
  host="$(printf "%s" "$host" | tr -d '\r\n\t ')"
  host="${host#[}"
  host="${host%]}"
  case "$(printf "%s" "$host" | tr '[:upper:]' '[:lower:]')" in
    ""|unknown)
      printf "\n"
      return 0
      ;;
  esac
  printf "%s\n" "$host"
}

mgr_is_valid_ipv4_literal() {
  local host="$1"
  local o1 o2 o3 o4 octet

  [[ "$host" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  IFS='.' read -r o1 o2 o3 o4 <<< "$host"
  for octet in "$o1" "$o2" "$o3" "$o4"; do
    [[ "$octet" =~ ^[0-9]+$ ]] || return 1
    [ "$((10#$octet))" -le 255 ] || return 1
  done
  return 0
}

mgr_is_valid_access_host() {
  local host="$1"

  if [ -z "$host" ]; then
    return 1
  fi
  if [[ "$host" =~ ^localhost$ ]]; then
    return 0
  fi
  if mgr_is_valid_ipv4_literal "$host"; then
    return 0
  fi
  if [[ "$host" == *:* ]] && [[ "$host" =~ ^[0-9A-Fa-f:]+$ ]]; then
    return 0
  fi
  if [[ "$host" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$ ]]; then
    return 0
  fi
  return 1
}

mgr_pick_access_host() {
  local primary fallback
  primary="$(mgr_normalize_access_host "$1")"
  if [ -n "$primary" ] && mgr_is_valid_access_host "$primary"; then
    printf "%s\n" "$primary"
    return 0
  fi

  fallback="$(mgr_normalize_access_host "$2")"
  if [ -n "$fallback" ] && mgr_is_valid_access_host "$fallback"; then
    printf "%s\n" "$fallback"
    return 0
  fi

  return 1
}

mgr_get_public_ip() {
  local saved detected
  saved="$(mgr_normalize_access_host "$(read_cfg "PUBLIC_IP")")"
  if [ -n "$saved" ] && mgr_is_valid_access_host "$saved"; then
    printf "%s\n" "$saved"
    return 0
  fi

  detected="$(mgr_normalize_access_host "${SERVER_IP:-$(fetch_public_ip)}")"
  if [ -n "$detected" ] && mgr_is_valid_access_host "$detected"; then
    printf "%s\n" "$detected"
    return 0
  fi

  return 1
}

mgr_format_uri_host() {
  local host
  host="$(mgr_normalize_access_host "$1")"
  if [ -z "$host" ]; then
    return 1
  fi
  if [[ "$host" == *:* ]]; then
    printf "[%s]\n" "$host"
    return 0
  fi
  printf "%s\n" "$host"
}

mgr_get_cf_preferred_domains() {
  local raw token host
  raw="$(read_cfg "CF_PREFERRED_DOMAINS" | tr ';| ' ',,,')"
  IFS=',' read -r -a tokens <<< "$raw"
  for token in "${tokens[@]}"; do
    host="$(mgr_normalize_access_host "$token")"
    [ -n "$host" ] || continue
    mgr_is_valid_access_host "$host" || continue
    printf "%s\n" "$host"
  done | awk '!seen[$0]++'
}

is_subscription_public_listen() {
  local listen
  listen="$(get_subscription_listen)"
  case "$listen" in
    127.0.0.1:*|localhost:*|\[::1\]:*)
      return 1
      ;;
    *)
      return 0
      ;;
  esac
}

apply_subscription_firewall_policy() {
  local port
  port="$(get_subscription_port)"
  if ! [[ "$port" =~ ^[0-9]+$ ]]; then
    return
  fi

  if get_subscription_enabled && is_subscription_public_listen && subscription_tls_ready; then
    firewall_allow_port "$port"
  else
    firewall_remove_port "$port"
  fi
}

subscription_tls_host() {
  local host
  host="$(mgr_pick_access_host "$(mgr_get_panel_domain)" "$(mgr_get_public_ip || true)" || true)"
  if [ -z "$host" ]; then
    return 1
  fi
  if [ ! -f "/etc/certs/${host}.crt" ] || [ ! -f "/etc/certs/${host}.key" ]; then
    return 1
  fi
  printf "%s\n" "$host"
}

subscription_tls_ready() {
  subscription_tls_host >/dev/null 2>&1
}

build_subscription_url() {
  local host url_host port token
  host="$(subscription_tls_host || true)"
  port="$(get_subscription_port)"
  token="$(get_subscription_token)"
  if [ -z "$host" ] || [ -z "$token" ]; then
    return 1
  fi
  url_host="$(mgr_format_uri_host "$host")" || return 1
  echo "https://${url_host}:${port}/sub/${token}"
}

describe_ssh_port_policy() {
  local ssh_port
  ssh_port="$(get_configured_ssh_port)"
  if [ "$ssh_port" = "22" ]; then
    echo "22 保持开放"
  else
    echo "${ssh_port}（22 已关闭）"
  fi
}

is_reserved_ssh_port() {
  local port="$1"
  if [ "$port" = "80" ] || [ "$port" = "443" ]; then
    return 0
  fi
  if [ -n "${PANEL_PORT:-}" ] && [ "$port" = "${PANEL_PORT}" ]; then
    return 0
  fi
  if [ -n "${FALLBACK_PORT:-}" ] && [ "$port" = "${FALLBACK_PORT}" ]; then
    return 0
  fi
  return 1
}

ssh_set_option() {
  local file="$1"
  local key="$2"
  local value="$3"
  if grep -Eq "^[#[:space:]]*${key}[[:space:]]+" "$file"; then
    sed -i -E "s|^[#[:space:]]*${key}[[:space:]].*|${key} ${value}|g" "$file"
  else
    printf '\n%s %s\n' "$key" "$value" >> "$file"
  fi
}

ssh_has_authorized_keys() {
  local sudo_home=""
  local file
  shopt -s nullglob
  if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
    sudo_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
  fi

  for file in \
    /root/.ssh/authorized_keys \
    /home/*/.ssh/authorized_keys \
    /etc/ssh/authorized_keys.d/* \
    "${sudo_home}/.ssh/authorized_keys"
  do
    if [ -n "$file" ] && [ -s "$file" ]; then
      shopt -u nullglob
      return 0
    fi
  done

  shopt -u nullglob
  return 1
}

ssh_validate_config() {
  local ssh_config="$1"
  local sshd_bin=""

  if command -v sshd >/dev/null 2>&1; then
    sshd_bin="$(command -v sshd)"
  elif [ -x /usr/sbin/sshd ]; then
    sshd_bin="/usr/sbin/sshd"
  fi

  if [ -z "$sshd_bin" ]; then
    log_warn "未找到 sshd 可执行文件，跳过 SSH 配置语法校验。"
    return 0
  fi

  "$sshd_bin" -t -f "$ssh_config" >/dev/null 2>&1
}

restart_ssh_service() {
  systemctl restart sshd >/dev/null 2>&1 || systemctl restart ssh >/dev/null 2>&1
}

apply_ssh_runtime_config() {
  local target_port="$1"
  local ssh_config="/etc/ssh/sshd_config"
  local backup_path=""

  if [ ! -f "$ssh_config" ]; then
    log_warn "未找到 sshd_config，跳过 SSH 配置更新。"
    return 1
  fi

  backup_path="${ssh_config}.bak.$(date +%s)"
  cp "$ssh_config" "$backup_path"
  ssh_set_option "$ssh_config" "PermitRootLogin" "prohibit-password"
  ssh_set_option "$ssh_config" "PubkeyAuthentication" "yes"
  ssh_set_option "$ssh_config" "Port" "$target_port"

  if ssh_has_authorized_keys; then
    ssh_set_option "$ssh_config" "PasswordAuthentication" "no"
    ssh_set_option "$ssh_config" "KbdInteractiveAuthentication" "no"
    ssh_set_option "$ssh_config" "ChallengeResponseAuthentication" "no"
    log_info "已检测到 SSH 公钥，默认禁用密码登录，仅保留密钥登录。"
  else
    log_warn "未检测到可用的 authorized_keys，暂不强制关闭密码登录，避免把当前机器锁死。"
    log_warn "请先写入 SSH 公钥，再手动执行：PasswordAuthentication no。"
  fi

  if ! ssh_validate_config "$ssh_config"; then
    cp "$backup_path" "$ssh_config"
    log_error "sshd 配置校验失败，已回滚到变更前配置。"
    return 1
  fi

  if ! restart_ssh_service; then
    cp "$backup_path" "$ssh_config"
    restart_ssh_service || true
    log_error "SSH 服务重启失败，已回滚到变更前配置。"
    return 1
  fi

  return 0
}

harden_ssh() {
  log_step "加固 SSH 配置"
  if ! apply_ssh_runtime_config "$(get_configured_ssh_port)"; then
    log_warn "SSH 加固未完全生效，请检查 sshd_config。"
  fi
}

setup_swap() {
  log_step "配置交换分区"
  if [ "$(swapon --show | wc -l)" -gt 0 ]; then
    log_warn "已存在交换分区，跳过创建。"
    return
  fi

  fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  if ! grep -q '/swapfile' /etc/fstab; then
    echo '/swapfile none swap sw 0 0' >> /etc/fstab
  fi
  if ! grep -q '^vm.swappiness=10$' /etc/sysctl.conf; then
    echo 'vm.swappiness=10' >> /etc/sysctl.conf
  fi
  sysctl vm.swappiness=10 || true
}

enable_bbr() {
  log_step "启用 BBR"
  local kernel_major
  kernel_major="$(uname -r | cut -d. -f1)"

  if [ "${kernel_major:-0}" -lt 4 ]; then
    log_warn "内核版本低于 4.x，跳过 BBR。"
    return
  fi

  if ! grep -q '^net.core.default_qdisc=fq$' /etc/sysctl.conf; then
    echo 'net.core.default_qdisc=fq' >> /etc/sysctl.conf
  fi
  if ! grep -q '^net.ipv4.tcp_congestion_control=bbr$' /etc/sysctl.conf; then
    echo 'net.ipv4.tcp_congestion_control=bbr' >> /etc/sysctl.conf
  fi
  sysctl -p || true
}

setup_firewall() {
  log_step "配置防火墙"
  apply_firewall_profile_baseline
  firewall_block_external_ping
  firewall_reload
}

detect_firewall_tool() {
  if command -v ufw >/dev/null 2>&1; then
    echo "ufw"
    return
  fi

  if command -v firewall-cmd >/dev/null 2>&1; then
    echo "firewalld"
    return
  fi

  if command -v iptables >/dev/null 2>&1; then
    echo "iptables"
    return
  fi

  echo "none"
}

firewall_allow_port_proto() {
  local port="$1"
  local proto="${2:-tcp}"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw allow "${port}/${proto}" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --add-port="${port}/${proto}" >/dev/null 2>&1 || true
      ;;
    iptables)
      if ! iptables -C INPUT -p "${proto}" --dport "${port}" -j ACCEPT >/dev/null 2>&1; then
        iptables -I INPUT -p "${proto}" --dport "${port}" -j ACCEPT >/dev/null 2>&1 || true
      fi
      ;;
    *)
      ;;
  esac
}

firewall_allow_port() {
  firewall_allow_port_proto "$1" tcp
}

firewall_remove_port_proto() {
  local port="$1"
  local proto="${2:-tcp}"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force delete allow "${port}/${proto}" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --remove-port="${port}/${proto}" >/dev/null 2>&1 || true
      ;;
    iptables)
      while iptables -C INPUT -p "${proto}" --dport "${port}" -j ACCEPT >/dev/null 2>&1; do
        iptables -D INPUT -p "${proto}" --dport "${port}" -j ACCEPT >/dev/null 2>&1 || break
      done
      ;;
    *)
      ;;
  esac
}

firewall_remove_port() {
  firewall_remove_port_proto "$1" tcp
}

firewall_reload() {
  local fw_type
  fw_type="$(detect_firewall_tool)"
  case "$fw_type" in
    ufw)
      ufw --force reload >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --reload >/dev/null 2>&1 || true
      ;;
    iptables)
      ;;
    *)
      ;;
  esac
}

restore_http_firewall_policy() {
  local mode
  mode="$(mgr_get_current_mode)"

  if [ "$mode" = "http" ]; then
    firewall_allow_port 80
  else
    firewall_remove_port 80
  fi

  firewall_reload
}

firewall_apply_ssh_policy() {
  local fw_type
  local ssh_port
  fw_type="$(detect_firewall_tool)"
  ssh_port="$(get_configured_ssh_port)"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ufw allow "${ssh_port}/tcp" >/dev/null 2>&1 || true
      if [ "$ssh_port" != "22" ]; then
        ufw --force delete allow 22/tcp >/dev/null 2>&1 || true
        ufw --force delete allow proto tcp from any to any port 22 >/dev/null 2>&1 || true
      fi
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-port="${ssh_port}/tcp" >/dev/null 2>&1 || true
      if [ "$ssh_port" = "22" ]; then
        firewall-cmd --permanent --add-service=ssh >/dev/null 2>&1 || true
      else
        firewall-cmd --permanent --remove-service=ssh >/dev/null 2>&1 || true
        firewall-cmd --permanent --remove-port=22/tcp >/dev/null 2>&1 || true
      fi
      ;;
    *)
      ;;
  esac
}

firewall_block_external_ping() {
  local fw_type sysctl_file
  if ! is_ping_block_enabled; then
    return
  fi

  fw_type="$(detect_firewall_tool)"
  sysctl_file="/etc/sysctl.d/99-xray-disable-ping.conf"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-icmp-block=echo-request >/dev/null 2>&1 || true
      ;;
    *)
      ;;
  esac

  if [ -d /etc/sysctl.d ]; then
    cat > "$sysctl_file" <<'EOF'
# Managed by xray-backend installer.
net.ipv4.icmp_echo_ignore_all = 1
EOF
    if [ -f /proc/sys/net/ipv6/icmp/echo_ignore_all ]; then
      echo 'net.ipv6.icmp.echo_ignore_all = 1' >> "$sysctl_file"
    fi
  fi

  if [ -f /proc/sys/net/ipv4/icmp_echo_ignore_all ]; then
    echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null || true
  fi
  if [ -f /proc/sys/net/ipv6/icmp/echo_ignore_all ]; then
    echo 1 > /proc/sys/net/ipv6/icmp/echo_ignore_all 2>/dev/null || true
  fi
  sysctl -w net.ipv4.icmp_echo_ignore_all=1 >/dev/null 2>&1 || true
  sysctl -w net.ipv6.icmp.echo_ignore_all=1 >/dev/null 2>&1 || true
}

apply_firewall_profile_baseline() {
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force enable
      ufw default deny incoming
      ufw default allow outgoing
      ufw allow 443/tcp comment 'HTTPS'
      firewall_apply_ssh_policy
      apply_subscription_firewall_policy
      ufw --force reload
      ;;
    firewalld)
      systemctl start firewalld
      systemctl enable firewalld
      firewall-cmd --permanent --add-port=443/tcp
      firewall_apply_ssh_policy
      apply_subscription_firewall_policy
      firewall-cmd --reload
      ;;
    *)
      log_warn "未检测到受支持的防火墙工具。"
      ;;
  esac
}

mgr_apply_firewall_for_mode() {
  local mode="$1"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ufw default deny incoming >/dev/null 2>&1 || true
      ufw default allow outgoing >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      ;;
    iptables)
      ;;
    *)
      log_warn "未检测到防火墙工具，跳过端口加固。"
      return
      ;;
  esac

  firewall_apply_ssh_policy

  case "$mode" in
    tls)
      firewall_allow_port 443
      firewall_remove_port 80
      ;;
    reality)
      firewall_allow_port 443
      firewall_remove_port 80
      ;;
    *)
      return
      ;;
  esac

  apply_subscription_firewall_policy

  firewall_block_external_ping

  if [ "$fw_type" = "ufw" ]; then
    ufw --force reload >/dev/null 2>&1 || true
  elif [ "$fw_type" = "firewalld" ]; then
    firewall-cmd --reload >/dev/null 2>&1 || true
  fi
}

setup_fail2ban() {
  log_step "配置 Fail2ban"
  if ! command -v fail2ban-client >/dev/null 2>&1; then
    log_warn "未安装 Fail2ban，跳过配置。"
    return
  fi

  local ssh_log="/var/log/auth.log"
  local fw_type fail2ban_banaction ssh_port
  ssh_port="$(get_configured_ssh_port)"
  if [ "$OS" = "centos" ] && [ -f /var/log/secure ]; then
    ssh_log="/var/log/secure"
  fi

  mkdir -p /etc/fail2ban/filter.d
  mkdir -p /etc/fail2ban/jail.d

  fw_type="$(detect_firewall_tool)"
  case "$fw_type" in
    ufw)
      fail2ban_banaction="ufw"
      ;;
    firewalld)
      fail2ban_banaction="firewallcmd-rich-rules"
      ;;
    *)
      fail2ban_banaction="iptables-multiport"
      ;;
  esac

  cat > /usr/local/bin/xray-fail2ban-daily-report.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
umask 077

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
DB_FILE="${DB_FILE:-/opt/xray-backend/data.db}"
STATE_DIR="${STATE_DIR:-/var/lib/xray-backend}"
STATE_FILE="${STATE_DIR}/daily-report.state"

read_cfg() {
  local key="$1"
  if [ -f "$CONFIG_FILE" ]; then
    grep "^${key}=" "$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

escape_html() {
  local s="$1"
  s="${s//&/&amp;}"
  s="${s//</&lt;}"
  s="${s//>/&gt;}"
  printf "%s" "$s"
}

format_bytes() {
  local value="$1"
  local units=("B" "KB" "MB" "GB" "TB")
  local index=0
  local display="$value"
  while [ "$display" -ge 1024 ] && [ "$index" -lt 4 ]; do
    display=$((display / 1024))
    index=$((index + 1))
  done
  printf "%s %s" "$display" "${units[$index]}"
}

token="$(read_cfg "TG_BOT_TOKEN" | tr -d '\r\n')"
chat_id="$(read_cfg "TG_CHAT_ID" | tr -d '\r\n')"
vps_name="$(read_cfg "VPS_DISPLAY_NAME" | tr -d '\r')"
host_name="$(hostname 2>/dev/null | tr -d '\r\n' || true)"
public_ip="$(read_cfg "PUBLIC_IP" | tr -d '\r\n')"
if [ -z "$token" ] || [ -z "$chat_id" ]; then
  exit 0
fi
if [ -z "$vps_name" ]; then
  vps_name="${host_name:-unknown}"
fi
if [ -z "$host_name" ]; then
  host_name="unknown"
fi

mkdir -p "$STATE_DIR"

ban_lines="$(journalctl -u fail2ban --since '24 hours ago' --no-pager -o cat 2>/dev/null | grep -E '\] Ban ' || true)"
ban_events="$(printf "%s\n" "$ban_lines" | sed '/^[[:space:]]*$/d' | wc -l | tr -d ' ')"
ban_unique="$(printf "%s\n" "$ban_lines" | sed -n 's/.* Ban \([0-9A-Fa-f:.]\+\).*/\1/p' | sed '/^[[:space:]]*$/d' | sort -u | wc -l | tr -d ' ')"

if ! [[ "$ban_events" =~ ^[0-9]+$ ]]; then
  ban_events="0"
fi
if ! [[ "$ban_unique" =~ ^[0-9]+$ ]]; then
  ban_unique="0"
fi

current_total_bytes="0"
if command -v sqlite3 >/dev/null 2>&1 && [ -f "$DB_FILE" ]; then
  current_total_bytes="$(sqlite3 "$DB_FILE" 'SELECT COALESCE(SUM(up_time + down_time), 0) FROM inbounds;' 2>/dev/null | tr -d '\r\n ' || true)"
fi
if ! [[ "$current_total_bytes" =~ ^[0-9]+$ ]]; then
  current_total_bytes="0"
fi

previous_total_bytes="0"
if [ -f "$STATE_FILE" ]; then
  previous_total_bytes="$(sed -n 's/^TOTAL_BYTES=//p' "$STATE_FILE" | head -n 1 | tr -d '\r\n ' || true)"
fi
if ! [[ "$previous_total_bytes" =~ ^[0-9]+$ ]]; then
  previous_total_bytes="0"
fi

yesterday_bytes=$((current_total_bytes - previous_total_bytes))
if [ "$yesterday_bytes" -lt 0 ]; then
  yesterday_bytes=0
fi
printf 'TOTAL_BYTES=%s\n' "$current_total_bytes" > "$STATE_FILE"

safe_name="$(escape_html "$vps_name")"
safe_host="$(escape_html "$host_name")"
safe_public_ip="$(escape_html "${public_ip:-未配置}")"
safe_time="$(escape_html "$(date '+%F %T %z')")"
safe_unique="$(escape_html "$ban_unique")"
safe_events="$(escape_html "$ban_events")"
safe_traffic="$(escape_html "$(format_bytes "$yesterday_bytes")")"

msg="<b>[日报] 昨日节点摘要</b>
节点名称: <code>${safe_name}</code>
主机名: <code>${safe_host}</code>
公网 IP: <code>${safe_public_ip}</code>
昨日流量: <code>${safe_traffic}</code>
过去 24 小时封禁 IP 数: <code>${safe_unique}</code>
过去 24 小时封禁事件数: <code>${safe_events}</code>
统计时间: ${safe_time}"

curl -fsS --max-time 10 --config - \
  -d "chat_id=${chat_id}" \
  -d "disable_web_page_preview=true" \
  -d "parse_mode=HTML" \
  --data-urlencode "text=${msg}" >/dev/null <<CURLCFG || true
url = "https://api.telegram.org/bot${token}/sendMessage"
CURLCFG
EOF
  chown root:root /usr/local/bin/xray-fail2ban-daily-report.sh 2>/dev/null || true
  chmod 700 /usr/local/bin/xray-fail2ban-daily-report.sh

  cat > /etc/systemd/system/xray-fail2ban-daily-report.service <<EOF
[Unit]
Description=Xray Fail2ban Daily Telegram Summary
After=network-online.target fail2ban.service
Wants=network-online.target

[Service]
Type=oneshot
User=root
ExecStart=/usr/local/bin/xray-fail2ban-daily-report.sh
Environment=CONFIG_FILE=${CONFIG_FILE}
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectHome=true
ProtectSystem=full
ProtectKernelModules=true
ProtectControlGroups=true
LockPersonality=true
RestrictRealtime=true
RestrictSUIDSGID=true
ReadWritePaths=${STATE_DIR}
EOF

  cat > /etc/systemd/system/xray-fail2ban-daily-report.timer <<'EOF'
[Unit]
Description=Send Xray fail2ban summary once daily at random time between 05:00 and 09:00

[Timer]
OnCalendar=*-*-* 05:00:00
RandomizedDelaySec=4h
Persistent=true
Unit=xray-fail2ban-daily-report.service

[Install]
WantedBy=timers.target
EOF

  cat > /etc/fail2ban/jail.d/xray-panel.local <<EOF
[sshd]
enabled = true
port = ${ssh_port}
logpath = ${ssh_log}
maxretry = 5
findtime = 3600
bantime = 604800
banaction = ${fail2ban_banaction}
action = %(banaction)s[port="%(port)s", protocol=tcp]
EOF

  systemctl daemon-reload || true
  systemctl enable fail2ban || true
  systemctl restart fail2ban || true
  systemctl enable xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
  systemctl restart xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
}

set_timezone() {
  log_step "Setting timezone"
  timedatectl set-timezone Asia/Shanghai || true
}

install_xray_core() {
  log_step "Installing Xray core"
  local xray_release_json
  xray_release_json="$(curl -fsSL "https://api.github.com/repos/XTLS/Xray-core/releases/tags/${XRAY_PINNED_VERSION}" || true)"
  XRAY_VERSION="$(printf '%s' "$xray_release_json" | tr -d '\r\n' | sed -n 's/.*"tag_name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' || true)"
  if [ -n "$XRAY_VERSION" ] && ! printf '%s' "$XRAY_VERSION" | grep -Eq '^v[0-9]'; then
    log_warn "自动解析到异常 Xray 版本标识: ${XRAY_VERSION}，将改用内置回退版本。"
    XRAY_VERSION=""
  fi
  if [ -z "$XRAY_VERSION" ]; then
    XRAY_VERSION="$XRAY_PINNED_VERSION"
  fi

  local xray_url="https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/Xray-linux-${XRAY_ARCH}.zip"
  local temp_dir xray_zip unzip_log

  if [ -z "$XRAY_ARCH" ]; then
    log_error "未识别到可用的 Xray 架构标识，无法继续安装核心。"
    return 1
  fi

  temp_dir="$(mktemp -d "${TMPDIR:-/tmp}/xray-core.XXXXXX")" || {
    log_error "创建 Xray core 临时目录失败。"
    return 1
  }
  xray_zip="${temp_dir}/xray-core.zip"
  unzip_log="${temp_dir}/unzip.log"

  log_info "准备安装 Xray core 版本: ${XRAY_VERSION}"
  log_info "下载地址: ${xray_url}"

  if ! download_github_asset_verified "$xray_release_json" "$xray_url" "$xray_zip" "Xray core"; then
    log_error "Xray core 下载失败，请检查服务器网络或稍后重试。"
    rm -rf "$temp_dir"
    return 1
  fi

  if ! unzip -oj "$xray_zip" xray -d /usr/local/bin/ >"$unzip_log" 2>&1; then
    log_error "Xray core 解压失败。"
    tail -n 20 "$unzip_log" 2>/dev/null || true
    rm -rf "$temp_dir"
    return 1
  fi

  chmod 755 /usr/local/bin/xray

  if [ ! -x /usr/local/bin/xray ]; then
    log_error "Xray core 安装失败，未找到 /usr/local/bin/xray。"
    rm -rf "$temp_dir"
    return 1
  fi

  if ! install_xray_geodata "$xray_zip"; then
    rm -rf "$temp_dir"
    return 1
  fi

  rm -rf "$temp_dir"

  mkdir -p "$INSTALL_DIR"
  if [ -x /usr/local/bin/xray ]; then
    ln -sfn /usr/local/bin/xray "${INSTALL_DIR}/xray-core"
    log_info "已创建核心软链接: ${INSTALL_DIR}/xray-core -> /usr/local/bin/xray"
  fi
  log_info "Xray 资产目录: ${XRAY_ASSET_DIR}"
}

install_xray_geodata() {
  log_step "Installing Xray geodata"
  local xray_zip="$1"
  local geodata_log

  if [ -z "$xray_zip" ] || [ ! -f "$xray_zip" ]; then
    log_error "Xray geodata 安装失败：未找到核心安装包。"
    return 1
  fi

  geodata_log="$(mktemp "${TMPDIR:-/tmp}/xray-geodata.XXXXXX")" || {
    log_error "创建 Xray geodata 临时日志失败。"
    return 1
  }

  mkdir -p "$XRAY_ASSET_DIR"

  # 官方文档说明 geoip.dat / geosite.dat 已包含在每个 Xray 安装包中，
  # 这里直接从已下载的核心压缩包解出资产文件，避免再执行远端脚本。
  if ! unzip -oj "$xray_zip" geoip.dat geosite.dat -d "$XRAY_ASSET_DIR" >"$geodata_log" 2>&1; then
    log_error "Xray geodata 解压失败。"
    tail -n 20 "$geodata_log" 2>/dev/null || true
    rm -f "$geodata_log"
    return 1
  fi

  rm -f "$geodata_log"

  if [ ! -f "${XRAY_ASSET_DIR}/geoip.dat" ] || [ ! -f "${XRAY_ASSET_DIR}/geosite.dat" ]; then
    log_error "Xray 资产文件缺失，未找到 ${XRAY_ASSET_DIR}/geoip.dat 或 ${XRAY_ASSET_DIR}/geosite.dat。"
    return 1
  fi

  harden_runtime_permissions
  log_info "Xray 资产目录: ${XRAY_ASSET_DIR}"
}

select_mihomo_release_url() {
  local release_json="$1"
  local arch="$2"
  local url name

  while IFS= read -r url; do
    name="${url##*/}"
    case "$arch" in
      amd64)
        case "$name" in
          mihomo-linux-amd64-v1*.gz|mihomo-linux-amd64-compatible*.gz|mihomo-linux-amd64*.gz)
            printf "%s\n" "$url"
            return 0
            ;;
        esac
        ;;
      arm64)
        case "$name" in
          mihomo-linux-arm64-v8*.gz|mihomo-linux-arm64*.gz)
            printf "%s\n" "$url"
            return 0
            ;;
        esac
        ;;
    esac
  done < <(printf "%s\n" "$release_json" | grep '"browser_download_url"' | cut -d '"' -f 4)

  return 1
}

install_mihomo_core() {
  log_step "Installing Mihomo helper"

  if [ -z "$MIHOMO_ARCH" ]; then
    log_warn "未识别到可用的 Mihomo 架构标识，跳过 Mihomo 辅助内核安装。"
    return 1
  fi

  local release_json mihomo_url mihomo_archive mihomo_log version_output temp_dir

  release_json="$(curl -fsSL "https://api.github.com/repos/MetaCubeX/mihomo/releases/tags/${MIHOMO_PINNED_VERSION}" 2>/dev/null || true)"
  if [ -z "$release_json" ]; then
    log_warn "无法从 GitHub API 获取 Mihomo 指定稳定版信息，跳过 Mihomo 辅助内核安装。"
    return 1
  fi

  MIHOMO_VERSION="$(printf "%s\n" "$release_json" | grep '"tag_name"' | head -n 1 | cut -d '"' -f 4 || true)"
  mihomo_url="$(select_mihomo_release_url "$release_json" "$MIHOMO_ARCH" || true)"
  if [ -z "$mihomo_url" ]; then
    log_warn "未找到适用于 ${MIHOMO_ARCH} 的 Mihomo Linux 发行包，跳过 Mihomo 辅助内核安装。"
    return 1
  fi

  temp_dir="$(mktemp -d "${TMPDIR:-/tmp}/mihomo.XXXXXX")" || {
    log_warn "创建 Mihomo 临时目录失败，跳过 Mihomo 辅助内核安装。"
    return 1
  }
  mihomo_archive="${temp_dir}/mihomo.gz"
  mihomo_log="${temp_dir}/install.log"

  log_info "准备安装 Mihomo 版本: ${MIHOMO_VERSION:-$MIHOMO_PINNED_VERSION}"
  log_info "下载地址: ${mihomo_url}"

  if ! download_github_asset_verified "$release_json" "$mihomo_url" "$mihomo_archive" "Mihomo helper"; then
    log_warn "Mihomo 下载失败，继续安装 Xray 服务端。"
    rm -rf "$temp_dir"
    return 1
  fi

  if ! gzip -dc "$mihomo_archive" > /usr/local/bin/mihomo 2>"$mihomo_log"; then
    log_warn "Mihomo 解压失败，继续安装 Xray 服务端。"
    tail -n 20 "$mihomo_log" 2>/dev/null || true
    rm -rf "$temp_dir"
    rm -f /usr/local/bin/mihomo
    return 1
  fi

  chmod 755 /usr/local/bin/mihomo
  mkdir -p "$INSTALL_DIR"
  ln -sfn /usr/local/bin/mihomo "${INSTALL_DIR}/mihomo-core"

  rm -rf "$temp_dir"

  version_output="$("/usr/local/bin/mihomo" -v 2>/dev/null | head -n 1 | tr -d '\r')"
  if [ -n "$version_output" ]; then
    log_info "已安装 Mihomo: ${version_output}"
  else
    log_info "已安装 Mihomo: ${MIHOMO_VERSION:-unknown}"
  fi
  log_info "已创建辅助内核软链接: ${INSTALL_DIR}/mihomo-core -> /usr/local/bin/mihomo"
  return 0
}

install_backend_service() {
  log_step "安装后端服务"
  local binary_path="${SCRIPT_DIR}/${BINARY}"
  mkdir -p "$INSTALL_DIR"
  cp "$binary_path" "${INSTALL_DIR}/${BIN_NAME}"
  chmod 700 "${INSTALL_DIR}/${BIN_NAME}"

  init_runtime_config
  mkdir -p /etc/certs
  chmod 700 /etc/certs

  cat > /etc/systemd/system/xray-backend.service <<EOF
[Unit]
Description=Xray Backend Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
Environment=XRAY_LOCATION_ASSET=${XRAY_ASSET_DIR}
ExecStart=${INSTALL_DIR}/${BIN_NAME}
KillMode=control-group
Restart=on-failure
RestartSec=5s
LimitNOFILE=65535
LimitNPROC=65535
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectHome=true
ProtectSystem=full
ProtectKernelModules=true
ProtectControlGroups=true
LockPersonality=true
RestrictRealtime=true
RestrictSUIDSGID=true
ReadWritePaths=${INSTALL_DIR} /etc/certs ${STATE_DIR}

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable xray-backend
  systemctl restart xray-backend
  sync_ssl_renewal_timer
  harden_runtime_permissions
  sleep 2
}

disable_acme_cron_job() {
  local current_cron filtered_cron

  if ! command -v crontab >/dev/null 2>&1; then
    return
  fi

  current_cron="$(crontab -l 2>/dev/null || true)"
  if [ -z "$current_cron" ]; then
    return
  fi

  filtered_cron="$(printf '%s\n' "$current_cron" | grep -v '[.]acme[.]sh/acme[.]sh --cron' || true)"
  if [ "$filtered_cron" = "$current_cron" ]; then
    return
  fi

  if [ -n "$filtered_cron" ]; then
    printf '%s\n' "$filtered_cron" | crontab -
  else
    crontab -r || true
  fi
}

get_ssl_issuer_tool() {
  local issuer domain key_target
  issuer="$(read_cfg "SSL_ISSUER_TOOL" | tr -d '\r\n ')"

  case "$issuer" in
    acme.sh|certbot|manual)
      echo "$issuer"
      return
      ;;
  esac

  domain="$(mgr_normalize_access_host "$(read_cfg "PANEL_DOMAIN")")"
  if [ -z "$domain" ] || ! mgr_is_valid_access_host "$domain"; then
    echo ""
    return
  fi

  key_target="$(readlink "/etc/certs/${domain}.key" 2>/dev/null || true)"
  case "$key_target" in
    /etc/letsencrypt/*)
      issuer="certbot"
      ;;
  esac

  if [ -z "$issuer" ] && [ -x "$HOME/.acme.sh/acme.sh" ] && [ -f "/etc/certs/${domain}.crt" ] && [ -f "/etc/certs/${domain}.key" ]; then
    issuer="acme.sh"
  fi

  if [ -n "$issuer" ]; then
    save_cfg "SSL_ISSUER_TOOL" "$issuer"
  fi
  echo "$issuer"
}

ensure_modern_acme_sh() {
  local email="$1"
  local acme_home acme_bin tmp_dir

  acme_home="${HOME}/.acme.sh"
  acme_bin="${acme_home}/acme.sh"

  if [ -x "$acme_bin" ] && "$acme_bin" --help 2>/dev/null | grep -q -- '--certificate-profile'; then
    return 0
  fi

  if ! command -v git >/dev/null 2>&1; then
    log_error "未检测到 git，无法从官方仓库安装 acme.sh。"
    return 1
  fi

  tmp_dir="$(mktemp -d)"
  if [ -z "$tmp_dir" ] || [ ! -d "$tmp_dir" ]; then
    log_error "无法创建 acme.sh 临时目录。"
    return 1
  fi

  if ! git clone --depth 1 --branch "$ACME_SH_TAG" https://github.com/acmesh-official/acme.sh.git "${tmp_dir}/acme.sh" >/dev/null 2>&1; then
    rm -rf "$tmp_dir"
    log_error "acme.sh 官方仓库下载失败。"
    return 1
  fi
  if ! git -C "${tmp_dir}/acme.sh" rev-parse HEAD 2>/dev/null | grep -q "^${ACME_SH_COMMIT}"; then
    rm -rf "$tmp_dir"
    log_error "acme.sh tag 校验失败，拒绝安装未固定的代码。"
    return 1
  fi

  if ! (cd "${tmp_dir}/acme.sh" && ./acme.sh --install --home "$acme_home" --config-home "$acme_home" --nocron --noprofile -m "$email" >/dev/null 2>&1); then
    rm -rf "$tmp_dir"
    log_error "acme.sh 安装失败。"
    return 1
  fi

  rm -rf "$tmp_dir"

  if [ ! -x "$acme_bin" ]; then
    log_error "acme.sh 安装后未找到可执行文件。"
    return 1
  fi

  "$acme_bin" --upgrade --auto-upgrade 0 >/dev/null 2>&1 || true

  if ! "$acme_bin" --help 2>/dev/null | grep -q -- '--certificate-profile'; then
    log_error "当前 acme.sh 版本不支持 certificate profile。"
    return 1
  fi

  return 0
}

ACME_HTTP_STOPPED_SERVICES=""

stop_http_services_for_acme() {
  local svc

  ACME_HTTP_STOPPED_SERVICES=""
  if ! command -v systemctl >/dev/null 2>&1; then
    return 0
  fi

  for svc in nginx apache2 httpd caddy; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
      if systemctl stop "$svc" >/dev/null 2>&1; then
        ACME_HTTP_STOPPED_SERVICES="${ACME_HTTP_STOPPED_SERVICES}${svc} "
        log_info "已临时停止 ${svc} 服务，释放 80 端口用于证书签发。"
      else
        log_warn "停止 ${svc} 失败，80 端口可能仍被占用。"
      fi
    fi
  done
}

restore_http_services_for_acme() {
  local svc

  [ -n "$ACME_HTTP_STOPPED_SERVICES" ] || return 0
  if ! command -v systemctl >/dev/null 2>&1; then
    return 0
  fi

  for svc in $ACME_HTTP_STOPPED_SERVICES; do
    if ! systemctl start "$svc" >/dev/null 2>&1; then
      log_warn "恢复 ${svc} 失败，请手动检查服务状态。"
    fi
  done
  ACME_HTTP_STOPPED_SERVICES=""
}

write_ssl_renewal_script() {
  cat > "${SSL_RENEW_SCRIPT}" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
umask 077

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
STOPPED_HTTP_SERVICES=""

read_cfg() {
  local key="$1"
  [ -f "$CONFIG_FILE" ] || return 0
  sed -n "s/^${key}=//p" "$CONFIG_FILE" | tail -n 1
}

normalize_access_host() {
  local host="$1"
  host="$(printf "%s" "$host" | tr -d '\r\n\t ')"
  host="${host#https://}"
  host="${host#http://}"
  host="${host%%/*}"
  host="${host%%\?*}"
  host="${host%%#*}"
  host="${host#[}"
  host="${host%]}"
  case "$(printf "%s" "$host" | tr '[:upper:]' '[:lower:]')" in
    ""|unknown)
      printf "\n"
      return 0
      ;;
  esac
  printf "%s\n" "$host"
}

is_valid_access_host() {
  local host="$1"
  if [ -z "$host" ]; then
    return 1
  fi
  if [[ "$host" =~ ^localhost$ ]]; then
    return 0
  fi
  if [[ "$host" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
    local o1 o2 o3 o4 octet
    IFS='.' read -r o1 o2 o3 o4 <<< "$host"
    for octet in "$o1" "$o2" "$o3" "$o4"; do
      [[ "$octet" =~ ^[0-9]+$ ]] || return 1
      [ "$((10#$octet))" -le 255 ] || return 1
    done
    return 0
  fi
  if [[ "$host" == *:* ]] && [[ "$host" =~ ^[0-9A-Fa-f:]+$ ]]; then
    return 0
  fi
  if [[ "$host" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$ ]]; then
    return 0
  fi
  return 1
}

detect_firewall_tool() {
  if command -v ufw >/dev/null 2>&1; then
    echo "ufw"
    return
  fi
  if command -v firewall-cmd >/dev/null 2>&1; then
    echo "firewalld"
    return
  fi
  if command -v iptables >/dev/null 2>&1; then
    echo "iptables"
    return
  fi
  echo "none"
}

firewall_allow_port() {
  local port="$1"
  case "$(detect_firewall_tool)" in
    ufw)
      ufw allow "${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-port="${port}/tcp" >/dev/null 2>&1 || true
      ;;
    iptables)
      if ! iptables -C INPUT -p tcp --dport "${port}" -j ACCEPT >/dev/null 2>&1; then
        iptables -I INPUT -p tcp --dport "${port}" -j ACCEPT >/dev/null 2>&1 || true
      fi
      ;;
  esac
}

firewall_remove_port() {
  local port="$1"
  case "$(detect_firewall_tool)" in
    ufw)
      ufw --force delete allow "${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --remove-port="${port}/tcp" >/dev/null 2>&1 || true
      ;;
    iptables)
      while iptables -C INPUT -p tcp --dport "${port}" -j ACCEPT >/dev/null 2>&1; do
        iptables -D INPUT -p tcp --dport "${port}" -j ACCEPT >/dev/null 2>&1 || break
      done
      ;;
  esac
}

firewall_reload() {
  case "$(detect_firewall_tool)" in
    ufw)
      ufw --force reload >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --reload >/dev/null 2>&1 || true
      ;;
  esac
}

stop_http_services_for_challenge() {
  local svc

  STOPPED_HTTP_SERVICES=""
  if ! command -v systemctl >/dev/null 2>&1; then
    return 0
  fi

  for svc in nginx apache2 httpd caddy; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
      if systemctl stop "$svc" >/dev/null 2>&1; then
        STOPPED_HTTP_SERVICES="${STOPPED_HTTP_SERVICES}${svc} "
      fi
    fi
  done
}

restore_http_services_after_challenge() {
  local svc

  [ -n "$STOPPED_HTTP_SERVICES" ] || return 0
  if ! command -v systemctl >/dev/null 2>&1; then
    return 0
  fi

  for svc in $STOPPED_HTTP_SERVICES; do
    systemctl start "$svc" >/dev/null 2>&1 || true
  done
  STOPPED_HTTP_SERVICES=""
}

restore_http_policy() {
  firewall_remove_port 80
  firewall_reload
}

issuer="$(read_cfg "SSL_ISSUER_TOOL" | tr -d '\r\n ')"
domain="$(normalize_access_host "$(read_cfg "PANEL_DOMAIN")")"

cleanup() {
  restore_http_services_after_challenge
  restore_http_policy
}

trap cleanup EXIT

case "$issuer" in
  acme.sh|certbot) ;;
  *)
    exit 0
    ;;
esac

if [ -z "$domain" ] || ! is_valid_access_host "$domain"; then
  exit 0
fi

firewall_allow_port 80
firewall_reload
stop_http_services_for_challenge

case "$issuer" in
  acme.sh)
    acme_bin="$HOME/.acme.sh/acme.sh"
    [ -x "$acme_bin" ] || exit 0
    "$acme_bin" --cron --home "$HOME/.acme.sh" >/dev/null 2>&1
    "$acme_bin" --install-cert -d "$domain" --key-file "/etc/certs/${domain}.key" --fullchain-file "/etc/certs/${domain}.crt" >/dev/null 2>&1 || true
    ;;
  certbot)
    command -v certbot >/dev/null 2>&1 || exit 0
    certbot renew --standalone --preferred-challenges http --quiet >/dev/null 2>&1
    ln -sfn "/etc/letsencrypt/live/${domain}/privkey.pem" "/etc/certs/${domain}.key"
    ln -sfn "/etc/letsencrypt/live/${domain}/fullchain.pem" "/etc/certs/${domain}.crt"
    ;;
esac
EOF

  chown root:root "${SSL_RENEW_SCRIPT}" 2>/dev/null || true
  chmod 755 "${SSL_RENEW_SCRIPT}"
}

write_ssl_renewal_service() {
  cat > "/etc/systemd/system/${SSL_RENEW_SERVICE}.service" <<EOF
[Unit]
Description=Xray SSL renew helper
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=${SSL_RENEW_SCRIPT}
EOF

  cat > "/etc/systemd/system/${SSL_RENEW_SERVICE}.timer" <<EOF
[Unit]
Description=Run Xray SSL renew helper daily

[Timer]
OnCalendar=*-*-* 03:00:00
RandomizedDelaySec=2h
Persistent=true
Unit=${SSL_RENEW_SERVICE}.service

[Install]
WantedBy=timers.target
EOF
}

sync_ssl_renewal_timer() {
  local issuer
  issuer="$(get_ssl_issuer_tool)"

  write_ssl_renewal_script
  write_ssl_renewal_service
  systemctl daemon-reload

  systemctl disable --now certbot.timer >/dev/null 2>&1 || true
  disable_acme_cron_job

  case "$issuer" in
    acme.sh|certbot)
      systemctl enable --now "${SSL_RENEW_SERVICE}.timer" >/dev/null 2>&1 || true
      ;;
    *)
      systemctl disable --now "${SSL_RENEW_SERVICE}.timer" >/dev/null 2>&1 || true
      ;;
  esac
}

install_management_tool() {
  log_step "Installing management command: xy"
  cp "${SCRIPT_DIR}/install.sh" /usr/local/bin/xy
  chown root:root /usr/local/bin/xy 2>/dev/null || true
  chmod 755 /usr/local/bin/xy
}

install_weekly_auto_update() {
  log_step "Installing weekly auto-update timer"

  cat > /usr/local/bin/xray-weekly-update.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
umask 077

LOCK_FILE="/var/lock/xray-weekly-update.lock"

echo "[$(date '+%F %T %z')] weekly update start"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  flock -n 9 || {
    echo "[$(date '+%F %T %z')] another update is running, skip"
    exit 0
  }
fi

update_system_packages() {
  if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get upgrade -y
    apt-get install --only-upgrade -y openssh-server openssh-client || true
  elif command -v dnf >/dev/null 2>&1; then
    dnf -y upgrade
    dnf -y upgrade openssh-server openssh-clients || true
  elif command -v yum >/dev/null 2>&1; then
    yum -y update
    yum -y update openssh-server openssh-clients || true
  else
    echo "No supported package manager found, skip system update."
  fi
}

restart_ssh_service() {
  systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
}

update_system_packages
restart_ssh_service

echo "[$(date '+%F %T %z')] weekly update done"
EOF
  chown root:root /usr/local/bin/xray-weekly-update.sh 2>/dev/null || true
  chmod 700 /usr/local/bin/xray-weekly-update.sh

  cat > /etc/systemd/system/xray-weekly-update.service <<'EOF'
[Unit]
Description=Xray Weekly System Security Update
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/xray-weekly-update.sh
Nice=10
EOF

  cat > /etc/systemd/system/xray-weekly-update.timer <<'EOF'
[Unit]
Description=Run weekly system security update

[Timer]
OnBootSec=20min
OnUnitActiveSec=7d
RandomizedDelaySec=30min
Persistent=true
Unit=xray-weekly-update.service

[Install]
WantedBy=timers.target
EOF

  systemctl daemon-reload
  systemctl enable --now xray-weekly-update.timer
}

install_cf_preferred_domains_refresh_timer() {
  cat > /usr/local/bin/xray-cf-preferred-refresh.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
LOG_FILE="/var/log/xray-cf-preferred-refresh.log"
LOCK_FILE="/var/lock/xray-cf-preferred-refresh.lock"

mkdir -p "$(dirname "$LOG_FILE")" "$(dirname "$LOCK_FILE")"
exec >>"$LOG_FILE" 2>&1
echo "[$(date '+%F %T %z')] Cloudflare preferred CMCC addresses refresh start"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  flock -n 9 || {
    echo "[$(date '+%F %T %z')] another refresh is running, skip"
    exit 0
  }
fi

read_cfg() {
  local key="$1"
  [ -f "$CONFIG_FILE" ] || return 0
  grep -E "^${key}=" "$CONFIG_FILE" | tail -n 1 | cut -d= -f2-
}

is_valid_ipv4() {
  local ip="$1" octet
  local -a octets
  [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  IFS='.' read -r -a octets <<< "$ip"
  for octet in "${octets[@]}"; do
    [ "$octet" -le 255 ] || return 1
  done
  return 0
}

normalize_preferred_host() {
  local host="$1" maybe_port
  host="$(printf "%s" "$host" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')"
  host="${host#http://}"
  host="${host#https://}"
  host="${host%%/*}"
  host="${host%%\?*}"
  host="${host%%#*}"
  if [[ "$host" =~ ^\[([0-9a-f:]+)\]:([0-9]{1,5})$ ]]; then
    maybe_port="${BASH_REMATCH[2]}"
    [ "$maybe_port" -ge 1 ] && [ "$maybe_port" -le 65535 ] || return 0
    host="${BASH_REMATCH[1]}"
  fi
  host="${host#[}"
  host="${host%]}"
  if [[ "$host" =~ ^(.+):([0-9]{1,5})$ ]] && [[ "${BASH_REMATCH[1]}" != *:* ]]; then
    maybe_port="${BASH_REMATCH[2]}"
    [ "$maybe_port" -ge 1 ] && [ "$maybe_port" -le 65535 ] || return 0
    host="${BASH_REMATCH[1]}"
  fi
  if is_valid_ipv4 "$host"; then
    printf "%s" "$host"
    return
  fi
  if [[ "$host" =~ ^[0-9a-f]{0,4}: ]] && [[ "$host" == *:* ]]; then
    python3 - "$host" <<'PY' 2>/dev/null || true
import ipaddress
import sys
try:
    ip = ipaddress.ip_address(sys.argv[1])
except ValueError:
    sys.exit(0)
print(ip.compressed)
PY
    return
  fi
  if [[ "$host" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
    printf "%s" "$host"
  fi
}

extract_preferred_hosts() {
  local ipv4_hosts fallback_hosts
  ipv4_hosts="$(
    {
      grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}(:[0-9]{1,5})?' || true
    } |
      while IFS= read -r candidate; do
        normalize_preferred_host "$candidate"
        printf '\n'
      done |
      sed '/^[[:space:]]*$/d' |
      awk '!seen[$0]++' |
      head -n 50 |
      paste -sd, -
  )"
  if [ -n "$ipv4_hosts" ]; then
    printf "%s" "$ipv4_hosts"
    return
  fi

  fallback_hosts="$(
  {
    grep -Eo '(\[[0-9A-Fa-f:]+\]|([0-9]{1,3}\.){3}[0-9]{1,3}|([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63})(:[0-9]{1,5})?' || true
  } |
    while IFS= read -r candidate; do
      normalize_preferred_host "$candidate"
      printf '\n'
    done |
    sed '/^[[:space:]]*$/d' |
    awk '!seen[$0]++' |
    head -n 50 |
    paste -sd, -
  )"
  printf "%s" "$fallback_hosts"
}

default_source_urls() {
  cat <<'URLS'
https://090227.pages.dev/bestcf?isp=cmcc&ips=50
URLS
}

configured_source_urls() {
  local raw
  raw="$(read_cfg CF_PREFERRED_DOMAINS_SOURCE_URL | tr '\r\n\t ' ',,,,')"
  [ -n "$raw" ] || return 0
  printf "%s" "$raw" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
}

is_valid_source_url() {
  local source_url="$1"
  case "$source_url" in
    http://*|https://*) ;;
    *) return 1 ;;
  esac
  [ "${#source_url}" -le 2048 ] || return 1
  case "$source_url" in
    *[\'\"\`\$\;\|\&\<\>\\]*)
      return 1
      ;;
  esac
  return 0
}

update_config_value() {
  local key="$1"
  local value="$2"
  local tmp_file
  mkdir -p "$(dirname "$CONFIG_FILE")"
  tmp_file="$(mktemp "${CONFIG_FILE}.tmp.XXXXXX")"
  if [ -f "$CONFIG_FILE" ]; then
    grep -v "^${key}=" "$CONFIG_FILE" > "$tmp_file" || true
  fi
  printf "%s=%s\n" "$key" "$value" >> "$tmp_file"
  chmod 600 "$tmp_file"
  mv -f "$tmp_file" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
}

if ! command -v curl >/dev/null 2>&1; then
  echo "[$(date '+%F %T %z')] curl is unavailable, skip"
  exit 0
fi

sources="$(configured_source_urls)"
if [ -z "$sources" ]; then
  sources="$(default_source_urls)"
fi

payload=""
while IFS= read -r source_url; do
  [ -n "$source_url" ] || continue
  if ! is_valid_source_url "$source_url"; then
    echo "[$(date '+%F %T %z')] skip invalid source URL: ${source_url}"
    continue
  fi
  echo "[$(date '+%F %T %z')] fetching ${source_url}"
  payload="${payload}
$(curl -fsSL --connect-timeout 10 --max-time 60 "$source_url" 2>/dev/null || true)"
done <<< "$sources"

hosts="$(printf "%s" "$payload" | extract_preferred_hosts)"
if [ -z "$hosts" ]; then
  echo "[$(date '+%F %T %z')] no valid preferred addresses found, keep existing config"
  exit 0
fi

update_config_value CF_PREFERRED_DOMAINS "$hosts"
echo "[$(date '+%F %T %z')] updated CF_PREFERRED_DOMAINS=${hosts}"
EOF
  chown root:root /usr/local/bin/xray-cf-preferred-refresh.sh 2>/dev/null || true
  chmod 700 /usr/local/bin/xray-cf-preferred-refresh.sh

  cat > /etc/systemd/system/xray-cf-preferred-refresh.service <<'EOF'
[Unit]
Description=Refresh Xray Cloudflare Preferred CMCC Addresses
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/xray-cf-preferred-refresh.sh
Nice=10
EOF

  cat > /etc/systemd/system/xray-cf-preferred-refresh.timer <<'EOF'
[Unit]
Description=Refresh Xray Cloudflare preferred CMCC addresses every 24 hours

[Timer]
OnBootSec=10min
OnUnitActiveSec=24h
RandomizedDelaySec=20min
Persistent=true
Unit=xray-cf-preferred-refresh.service

[Install]
WantedBy=timers.target
EOF

  systemctl daemon-reload
  systemctl enable --now xray-cf-preferred-refresh.timer >/dev/null 2>&1 || true
}

print_summary() {
  local access_host reality_sni current_mode ssh_port mihomo_version subscription_url subscription_port

  access_host="$(mgr_get_panel_domain)"
  reality_sni="$(mgr_get_reality_sni_domain)"
  current_mode="$(mgr_get_current_mode)"
  ssh_port="$(get_configured_ssh_port)"
  mihomo_version="$(mgr_get_mihomo_version)"
  subscription_port="$(get_subscription_port)"
  subscription_url="$(build_subscription_url || true)"

  echo ""
  echo "=============================================="
  echo "安装完成。"
  echo "=============================================="
  echo "服务器 IP: $SERVER_IP"
  if [ -n "$access_host" ]; then
    echo "接入域名 / IP: ${access_host}"
  else
    echo "接入域名 / IP: 未设置"
  fi
  echo "当前模式: ${current_mode}"
  echo "Reality 伪装域名: ${reality_sni:-未设置}"
  echo "节点创建: xy -> 节点管理"
  echo "运行形态: Headless 直连（无前端、无 Nginx）"
  echo "防火墙基础开放: ${ssh_port}、443、${subscription_port}（订阅证书就绪后开放；80 仅在证书申请 / 续签时临时开放）"
  echo "SSH 端口: $(describe_ssh_port_policy)"
  echo "Xray 版本: ${XRAY_VERSION}"
  echo "Mihomo 辅助内核: ${mihomo_version}"
  if get_subscription_enabled; then
    if [ -n "$subscription_url" ]; then
      echo "V2Ray 标准订阅 URL: ${subscription_url}"
      echo "Mihomo 显式订阅 URL: ${subscription_url}?format=mihomo"
    else
      echo "订阅 URL: 未生成（缺少 TLS 证书或接入域名 / IP）"
    fi
  else
    echo "订阅 URL: 已禁用"
  fi
  echo "系统与 SSH 漏洞补丁定时更新: 已启用（每 7 天执行一次）"
  echo ""
  echo "管理命令: xy"
}

mgr_pause_wait() {
  echo ""
  echo -n "按回车继续..."
  read -r
}

mgr_get_panel_domain() {
  read_cfg "PANEL_DOMAIN"
}

mgr_get_current_mode() {
  local mode
  mode="$(read_cfg "XRAY_MODE" | tr '[:upper:]' '[:lower:]')"
  case "$mode" in
    tls|reality)
      echo "$mode"
      return
      ;;
  esac
  echo "reality"
}

mgr_set_current_mode() {
  local mode="$1"
  case "$mode" in
    tls|reality)
      save_cfg "XRAY_MODE" "$mode"
      ;;
  esac
}

mgr_normalize_camouflage_site() {
  local raw="$1"
  local site

  site="$(echo "$raw" | tr -d '\r\n\t ')"
  site="${site#https://}"
  site="${site#http://}"
  site="${site%%/*}"
  site="${site%%\?*}"
  site="${site%%#*}"
  echo "$site"
}

mgr_is_valid_camouflage_site() {
  local site="$1"
  if [ -z "$site" ]; then
    return 0
  fi

  if [[ "$site" =~ ^localhost$ ]]; then
    return 0
  fi
  if mgr_is_valid_ipv4_literal "$site"; then
    return 0
  fi
  if [[ "$site" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$ ]]; then
    return 0
  fi
  return 1
}

mgr_is_valid_reality_sni_domain() {
  local site="$1"
  if [ -z "$site" ]; then
    return 1
  fi
  if mgr_is_valid_ipv4_literal "$site"; then
    return 1
  fi
  if [[ "$site" == *:* ]] && [[ "$site" =~ ^[0-9A-Fa-f:]+$ ]]; then
    return 1
  fi
  [[ "$site" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$ ]]
}

mgr_is_ipv4_literal() {
  local host="$1"
  mgr_is_valid_ipv4_literal "$host"
}

mgr_get_camouflage_site() {
  local site
  site="$(mgr_normalize_camouflage_site "$(read_cfg "CAMOUFLAGE_SITE")")"
  if ! mgr_is_valid_camouflage_site "$site"; then
    log_warn "配置中的 CAMOUFLAGE_SITE 无效，已重置为空。"
    site=""
    save_cfg "CAMOUFLAGE_SITE" ""
  fi
  echo "$site"
}

mgr_get_reality_sni_domain() {
  local sni
  sni="$(mgr_normalize_camouflage_site "$(read_cfg "REALITY_SNI_DOMAIN")")"
  if [ -n "$sni" ] && ! mgr_is_valid_reality_sni_domain "$sni"; then
    sni=""
  fi
  if [ -z "$sni" ]; then
    sni="$(mgr_normalize_camouflage_site "$(read_cfg "CAMOUFLAGE_SITE")")"
    if [ -n "$sni" ] && ! mgr_is_valid_reality_sni_domain "$sni"; then
      sni=""
    fi
  fi
  if [ -z "$sni" ]; then
    sni="$(mgr_get_panel_domain)"
    if [ -n "$sni" ] && ! mgr_is_valid_reality_sni_domain "$sni"; then
      sni=""
    fi
  fi
  echo "$sni"
}

mgr_manage_reality_sni() {
  clear
  echo -e "${CYAN}==== Reality 伪装域名 ====${NC}"
  echo ""

  local current input site
  current="$(mgr_get_reality_sni_domain)"

  if [ -n "$current" ]; then
    echo "当前 Reality 伪装域名: $current"
  else
    echo "当前 Reality 伪装域名: 未设置"
  fi
  echo ""
  echo "输入格式: 仅支持真实域名，不要填本机 IP，不要带协议头和路径。"
  echo "留空表示清空，创建 Reality 节点时会回退到随机公开站点。"
  echo -n "请输入新的 Reality 伪装域名: "
  read -r input

  site="$(mgr_normalize_camouflage_site "$input")"
  if [ -n "$site" ] && ! mgr_is_valid_reality_sni_domain "$site"; then
    log_error "无效 Reality 伪装域名，请输入真实域名，不能填本机 IP。"
    mgr_pause_wait
    return
  fi

  save_cfg "REALITY_SNI_DOMAIN" "$site"
  if [ -n "$site" ]; then
    log_info "已保存 Reality 伪装域名: $site"
  else
    log_info "已清空 Reality 伪装域名。"
  fi
  mgr_pause_wait
}

mgr_rotate_camouflage_site() {
  mgr_get_camouflage_site
}

mgr_set_camouflage_site() {
  clear
  echo -e "${CYAN}==== Reality 伪装站上游设置 ====${NC}"
  echo ""

  local current input site
  current="$(mgr_get_camouflage_site)"

  if [ -n "$current" ]; then
    echo "当前伪装站上游: $current"
  else
    echo "当前伪装站上游: 未设置（仅用于生成节点时的默认伪装域名）"
  fi
  echo ""
  echo "输入格式: 仅支持域名或 IP，不要带协议头和路径。"
  echo -n "请输入伪装站上游域名（留空表示清空）: "
  read -r input

  site="$(mgr_normalize_camouflage_site "$input")"
  if ! mgr_is_valid_camouflage_site "$site"; then
    log_error "无效主机名，请输入域名或 IPv4 地址。"
    mgr_pause_wait
    return
  fi

  save_cfg "CAMOUFLAGE_SITE" "$site"
  if [ -n "$site" ]; then
    log_info "已保存伪装站上游: $site"
  else
    log_info "已清空伪装站上游。"
  fi
  mgr_pause_wait
}

mgr_mask_secret() {
  local raw="$1"
  local n
  n="${#raw}"
  if [ "$n" -le 8 ]; then
    printf "%s" "********"
    return
  fi
  printf "%s***%s" "${raw:0:4}" "${raw:$((n-4)):4}"
}

mgr_tg_alert_is_enabled() {
  [ "$(read_cfg "TG_ALERT_ENABLED")" = "1" ]
}

mgr_write_security_monitor_script() {
  cat > /usr/local/bin/xray-security-monitor.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
umask 077

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
STATE_DIR="${STATE_DIR:-/var/lib/xray-backend/security-monitor}"
DEFAULT_COOLDOWN=1800
DEFAULT_TRAFFIC_ALERT_MBPS=500
MAX_ALERT_LINES=12
MIN_PUSH_INTERVAL=60
PENDING_ALERT_FILE="${STATE_DIR}/pending-alerts.html"
GLOBAL_PUSH_STATE="${GLOBAL_PUSH_STATE:-/var/lib/xray-backend/tg-last-push.state}"
QUEUE_LOCK_DIR="${QUEUE_LOCK_DIR:-/var/lib/xray-backend/security-monitor/queue.lock.d}"
QUEUE_LOCK_HELD=0
ALERT_SECTIONS=""
ALERT_COUNT=0

read_cfg() {
  local key="$1"
  [[ "$key" =~ ^[A-Z0-9_]+$ ]] || return 0
  if [ -f "$CONFIG_FILE" ]; then
    awk -v key="$key" 'index($0, key "=") == 1 { print substr($0, length(key) + 2); exit }' "$CONFIG_FILE" 2>/dev/null || true
  fi
}

trim() {
  printf "%s" "$1" | tr -d '\r\n'
}

escape_html() {
  local s="$1"
  s="${s//&/&amp;}"
  s="${s//</&lt;}"
  s="${s//>/&gt;}"
  printf "%s" "$s"
}

hash_text() {
  if command -v sha256sum >/dev/null 2>&1; then
    printf "%s" "$1" | sha256sum | awk '{print $1}'
  else
    printf "%s" "$1" | cksum | awk '{print $1 "-" $2}'
  fi
}

send_tg() {
  local text="$1"
  curl -fsS --max-time 10 --config - \
    -d "chat_id=${TG_CHAT_ID}" \
    -d "disable_web_page_preview=true" \
    -d "parse_mode=HTML" \
    --data-urlencode "text=${text}" >/dev/null <<CURLCFG
url = "https://api.telegram.org/bot${TG_BOT_TOKEN}/sendMessage"
CURLCFG
}

acquire_queue_lock() {
  local deadline now
  mkdir -p "$(dirname "$QUEUE_LOCK_DIR")"
  deadline=$(( $(date +%s) + 10 ))
  while true; do
    if mkdir "$QUEUE_LOCK_DIR" 2>/dev/null; then
      QUEUE_LOCK_HELD=1
      printf '%s\n' "$$" > "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      trap release_queue_lock EXIT
      return 0
    fi
    if [ -d "$QUEUE_LOCK_DIR" ] && find "$QUEUE_LOCK_DIR" -maxdepth 0 -mmin +5 >/dev/null 2>&1; then
      rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    fi
    now="$(date +%s)"
    [ "$now" -ge "$deadline" ] && return 1
    sleep 0.1
  done
}

release_queue_lock() {
  if [ "${QUEUE_LOCK_HELD:-0}" = "1" ]; then
    rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
    rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    QUEUE_LOCK_HELD=0
  fi
}

post_central_alerts() {
  local text="$1"
  [ -n "$SECURITY_ALERT_INGEST_URL" ] || return 1
  [ -n "$SECURITY_ALERT_INGEST_TOKEN" ] || return 1
  curl -fsS --connect-timeout 5 --max-time 15 \
    -H "X-Requested-With: XMLHttpRequest" \
    -H "Authorization: Bearer ${SECURITY_ALERT_INGEST_TOKEN}" \
    --data-urlencode "machineName=${VPS_NAME}" \
    --data-urlencode "hostname=${HOST_NAME}" \
    --data-urlencode "publicIP=${PUBLIC_IP:-未配置}" \
    --data-urlencode "sectionsHtml=${text}" \
    "$SECURITY_ALERT_INGEST_URL" >/dev/null
}

cooldown_ok() {
  local key="$1"
  local now last safe_key file
  safe_key="$(printf "%s" "$key" | tr -c 'A-Za-z0-9_.-' '_')"
  file="${STATE_DIR}/cooldown-${safe_key}.state"
  now="$(date +%s)"
  last="0"
  if [ -f "$file" ]; then
    last="$(tr -dc '0-9' < "$file" || true)"
  fi
  if ! [[ "$last" =~ ^[0-9]+$ ]]; then
    last="0"
  fi
  if [ $((now - last)) -lt "$TG_COOLDOWN" ]; then
    return 1
  fi
  printf "%s\n" "$now" > "$file"
  return 0
}

append_alert_section() {
  local title="$1"
  local body="$2"
  if [ -n "$ALERT_SECTIONS" ]; then
    ALERT_SECTIONS="${ALERT_SECTIONS}

"
  fi
  ALERT_SECTIONS="${ALERT_SECTIONS}<b>${title}</b>
${body}"
  ALERT_COUNT=$((ALERT_COUNT + 1))
}

append_alert_section_throttled() {
  local key="$1"
  local title="$2"
  local body="$3"
  if ! cooldown_ok "$key"; then
    return 0
  fi
  append_alert_section "$title" "$body"
}

queue_current_alerts() {
  if [ "$ALERT_COUNT" -le 0 ]; then
    return 0
  fi
  if [ -s "$PENDING_ALERT_FILE" ]; then
    printf "\n\n" >> "$PENDING_ALERT_FILE"
  fi
  printf "%s\n" "$ALERT_SECTIONS" >> "$PENDING_ALERT_FILE"
  ALERT_SECTIONS=""
  ALERT_COUNT=0
}

machine_identity_lines() {
  local safe_name safe_host safe_public_ip
  safe_name="$(escape_html "$VPS_NAME")"
  safe_host="$(escape_html "$HOST_NAME")"
  safe_public_ip="$(escape_html "${PUBLIC_IP:-未配置}")"
  printf '机器名: <code>%s</code>\n主机名: <code>%s</code>\n公网 IP: <code>%s</code>' "$safe_name" "$safe_host" "$safe_public_ip"
}

flush_alerts() {
  local now last pending combined safe_time section_count msg
  pending=""
  if [ -s "$PENDING_ALERT_FILE" ]; then
    pending="$(cat "$PENDING_ALERT_FILE" 2>/dev/null || true)"
  fi
  combined="$pending"
  if [ -n "$ALERT_SECTIONS" ]; then
    if [ -n "$combined" ]; then
      combined="${combined}

${ALERT_SECTIONS}"
    else
      combined="$ALERT_SECTIONS"
    fi
  fi
  [ -n "$combined" ] || return 0

  if [ -n "$SECURITY_ALERT_INGEST_URL" ] && [ -n "$SECURITY_ALERT_INGEST_TOKEN" ]; then
    if post_central_alerts "$combined"; then
      rm -f "$PENDING_ALERT_FILE"
      ALERT_SECTIONS=""
      ALERT_COUNT=0
      return 0
    fi
    queue_current_alerts
    return 0
  fi

  now="$(date +%s)"
  last="0"
  if [ -f "$GLOBAL_PUSH_STATE" ]; then
    last="$(tr -dc '0-9' < "$GLOBAL_PUSH_STATE" || true)"
  fi
  if ! [[ "$last" =~ ^[0-9]+$ ]]; then
    last="0"
  fi
  if [ $((now - last)) -lt "$MIN_PUSH_INTERVAL" ]; then
    queue_current_alerts
    return 0
  fi

  safe_time="$(escape_html "$(date '+%F %T %z')")"
  section_count="$(printf "%s\n" "$combined" | grep -c '^<b>\[告警\]' || true)"
  msg="<b>[告警] VPS 安全事件汇总</b>
$(machine_identity_lines)
时间: ${safe_time}
汇总事件: <code>${section_count}</code>

${combined}"
  if ! send_tg "$msg"; then
    queue_current_alerts
    return 0
  fi
  printf "%s\n" "$now" > "$GLOBAL_PUSH_STATE"
  rm -f "$PENDING_ALERT_FILE"
  ALERT_SECTIONS=""
  ALERT_COUNT=0
}

format_code_lines() {
  local input="$1"
  local count=0
  local line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    count=$((count + 1))
    if [ "$count" -gt "$MAX_ALERT_LINES" ]; then
      printf "...more omitted...\n"
      break
    fi
    printf '<code>%s</code>\n' "$(escape_html "${line:0:220}")"
  done <<< "$input"
}

extract_login_ip_from_log() {
  local line="$1"
  local value
  value="$(printf "%s\n" "$line" | sed -nE 's/.* from ([^ ]+) port [0-9]+.*/\1/p' | head -n 1)"
  if [ -n "$value" ]; then
    printf "%s" "$value"
  else
    printf "unknown"
  fi
}

extract_login_user_from_log() {
  local line="$1"
  local value
  value="$(printf "%s\n" "$line" | sed -nE 's/.*Accepted [^ ]+ for ([^ ]+) from .*/\1/p; s/.*Failed [^ ]+ for invalid user ([^ ]+) from .*/\1/p; s/.*Failed [^ ]+ for ([^ ]+) from .*/\1/p; s/.*Invalid user ([^ ]+) from .*/\1/p' | head -n 1)"
  if [ -n "$value" ]; then
    printf "%s" "$value"
  else
    printf "unknown"
  fi
}

extract_login_time_from_log() {
  local line="$1"
  local value
  value="$(printf "%s\n" "$line" | sed -nE 's/^([0-9]{4}-[0-9]{2}-[0-9]{2}T[^ ]+).*/\1/p; s/^([A-Z][a-z]{2}[[:space:]]+[0-9]+[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}).*/\1/p' | head -n 1)"
  if [ -n "$value" ]; then
    printf "%s" "$value"
  else
    date '+%F %T %z'
  fi
}

format_ssh_login_records() {
  local input="$1"
  local count=0
  local line login_ip login_status login_user login_time server_ip
  server_ip="${PUBLIC_IP:-未配置}"
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    count=$((count + 1))
    if [ "$count" -gt "$MAX_ALERT_LINES" ]; then
      printf "还有更多记录已省略。\n"
      break
    fi
    login_ip="$(extract_login_ip_from_log "$line")"
    login_user="$(extract_login_user_from_log "$line")"
    login_time="$(extract_login_time_from_log "$line")"
    case "$line" in
      *" Accepted "*) login_status="成功" ;;
      *) login_status="失败" ;;
    esac
    printf '登录 IP：<code>%s</code>\n登录状态：<code>%s</code>\n服务器 IP：<code>%s</code>\n登录用户：<code>%s</code>\n登录时间：<code>%s</code>\n\n' \
      "$(escape_html "$login_ip")" \
      "$(escape_html "$login_status")" \
      "$(escape_html "$server_ip")" \
      "$(escape_html "$login_user")" \
      "$(escape_html "$login_time")"
  done <<< "$input"
}

collect_ssh_login_lines() {
  local lines=""
  if command -v journalctl >/dev/null 2>&1; then
    lines="$(journalctl -u ssh -u sshd --since '2 hours ago' --no-pager -o short-iso 2>/dev/null | grep -E 'sshd(\[[0-9]+\])?: (Accepted (publickey|password|keyboard-interactive/pam) for |Failed (password|publickey|keyboard-interactive/pam|none) for )' || true)"
  fi
  if [ -z "$lines" ]; then
    local log_file
    for log_file in /var/log/auth.log /var/log/secure; do
      if [ -r "$log_file" ]; then
        lines="${lines}
$(grep -E 'sshd.*(Accepted (publickey|password|keyboard-interactive/pam) for |Failed (password|publickey|keyboard-interactive/pam|none) for )' "$log_file" 2>/dev/null | tail -n 200 || true)"
      fi
    done
  fi
  printf "%s\n" "$lines" | sed '/^[[:space:]]*$/d' | tail -n 80
}

check_ssh_logins() {
  local state_file="${STATE_DIR}/ssh-login.seen"
  local new_file="${STATE_DIR}/ssh-login.new.$$"
  local first_run=0
  local line hash
  if [ ! -f "$state_file" ]; then
    first_run=1
    : > "$state_file"
  fi
  : > "$new_file"
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    hash="$(hash_text "$line")"
    if grep -Fxq "$hash" "$state_file" 2>/dev/null; then
      continue
    fi
    printf "%s\n" "$hash" >> "$state_file"
    if [ "$first_run" -eq 0 ]; then
      printf "%s\n" "$line" >> "$new_file"
    fi
  done < <(collect_ssh_login_lines)
  tail -n 500 "$state_file" > "${state_file}.tmp" 2>/dev/null && mv -f "${state_file}.tmp" "$state_file" || true
  if [ -s "$new_file" ]; then
    local body
    body="SSH 登录记录:
$(format_ssh_login_records "$(cat "$new_file")")"
    append_alert_section "[告警] SSH 登录记录" "$body"
  fi
  rm -f "$new_file"
}

valid_port() {
  [[ "$1" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]
}

configured_allowed_ports() {
  local value port listen
  printf "%s\n" "${EXPECTED_PUBLIC_PORTS:-80,443}" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
  port="$(trim "$(read_cfg "SSH_PORT")")"
  if valid_port "$port"; then
    printf "%s\n" "$port"
  fi
  listen="$(trim "$(read_cfg "SUBSCRIPTION_LISTEN")")"
  port="${listen##*:}"
  if valid_port "$port"; then
    printf "%s\n" "$port"
  fi
  value="$(trim "$(read_cfg "TG_EXTRA_ALLOWED_PORTS")")"
  if [ -n "$value" ]; then
    printf "%s\n" "$value" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
  fi
}

is_allowed_port() {
  local port="$1"
  configured_allowed_ports | sort -u | grep -Fxq "$port"
}

host_from_addr() {
  local addr="$1"
  local host
  if [[ "$addr" =~ ^\[(.*)\]:[0-9]+$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
    return
  fi
  host="${addr%:*}"
  printf "%s" "$host"
}

port_from_addr() {
  local addr="$1"
  if [[ "$addr" =~ ^\[.*\]:([0-9]+)$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
  elif [[ "$addr" =~ :([0-9]+)$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
  fi
}

is_loopback_addr() {
  local host
  host="$(host_from_addr "$1")"
  case "$host" in
    127.*|::1|localhost)
      return 0
      ;;
  esac
  return 1
}

collect_abnormal_listeners() {
  if command -v ss >/dev/null 2>&1; then
    ss -H -ltunp 2>/dev/null | while IFS= read -r line; do
      [ -z "$line" ] && continue
      set -- $line
      local local_addr="${4:-}"
      local port
      port="$(port_from_addr "$local_addr")"
      [ -z "$port" ] && continue
      is_loopback_addr "$local_addr" && continue
      if is_allowed_port "$port"; then
        continue
      fi
      printf 'port=%s addr=%s %s\n' "$port" "$local_addr" "$(printf "%s" "$line" | cut -c1-220)"
    done
  elif command -v netstat >/dev/null 2>&1; then
    netstat -ltunp 2>/dev/null | awk 'NR>2 {print}' | while IFS= read -r line; do
      set -- $line
      local local_addr="${4:-}"
      local port
      port="$(port_from_addr "$local_addr")"
      [ -z "$port" ] && continue
      is_loopback_addr "$local_addr" && continue
      if is_allowed_port "$port"; then
        continue
      fi
      printf 'port=%s addr=%s %s\n' "$port" "$local_addr" "$(printf "%s" "$line" | cut -c1-220)"
    done
  fi | sort -u
}

check_listening_ports() {
  local current_file="${STATE_DIR}/listeners.current"
  local previous_file="${STATE_DIR}/listeners.previous"
  local new_lines
  collect_abnormal_listeners > "$current_file" || true
  if [ ! -f "$previous_file" ]; then
    cp -f "$current_file" "$previous_file"
    new_lines="$(cat "$current_file")"
  else
    new_lines="$(comm -13 "$previous_file" "$current_file" 2>/dev/null || true)"
    cp -f "$current_file" "$previous_file"
  fi
  if [ -n "$new_lines" ]; then
    local body
    body="发现新的公网异常监听端口:
$(format_code_lines "$new_lines")
允许端口可在配置里追加 <code>TG_EXTRA_ALLOWED_PORTS=端口1,端口2</code>。"
    append_alert_section "[告警] 异常端口监听" "$body"
  fi
}

read_network_total_bytes() {
  if [ ! -r /proc/net/dev ]; then
    printf "0"
    return
  fi
  awk -F'[: ]+' 'NR > 2 { iface=$2; if (iface == "lo") next; total += $3 + $11 } END { printf "%.0f", total + 0 }' /proc/net/dev
}

check_traffic() {
  local state_file="${STATE_DIR}/traffic.state"
  local now total previous_ts previous_total interval delta mbps threshold
  threshold="$(trim "$(read_cfg "TG_TRAFFIC_ALERT_MBPS")")"
  if ! [[ "$threshold" =~ ^[0-9]+$ ]] || [ "$threshold" -lt 1 ]; then
    threshold="$DEFAULT_TRAFFIC_ALERT_MBPS"
  fi
  now="$(date +%s)"
  total="$(read_network_total_bytes)"
  if ! [[ "$total" =~ ^[0-9]+$ ]]; then
    return 0
  fi
  if [ ! -f "$state_file" ]; then
    printf 'TS=%s\nBYTES=%s\n' "$now" "$total" > "$state_file"
    return 0
  fi
  previous_ts="$(sed -n 's/^TS=//p' "$state_file" | head -n 1 | tr -dc '0-9' || true)"
  previous_total="$(sed -n 's/^BYTES=//p' "$state_file" | head -n 1 | tr -dc '0-9' || true)"
  printf 'TS=%s\nBYTES=%s\n' "$now" "$total" > "$state_file"
  if ! [[ "$previous_ts" =~ ^[0-9]+$ ]] || ! [[ "$previous_total" =~ ^[0-9]+$ ]]; then
    return 0
  fi
  interval=$((now - previous_ts))
  [ "$interval" -lt 30 ] && return 0
  if [ "$total" -lt "$previous_total" ]; then
    return 0
  fi
  delta=$((total - previous_total))
  mbps=$((delta * 8 / interval / 1000000))
  if [ "$mbps" -ge "$threshold" ]; then
    local body
    body="检测到 VPS 网卡聚合流量突增:
当前速率: <code>${mbps} Mbps</code>
阈值: <code>${threshold} Mbps</code>
采样间隔: <code>${interval}s</code>"
    append_alert_section_throttled "traffic" "[告警] 流量异常" "$body"
  fi
}

watch_paths() {
  cat <<'PATHS'
/opt/xray-backend/config.conf
/opt/xray-backend/xray-core
/opt/xray-backend/mihomo-core
/opt/xray-backend/subscriptions
/etc/ssh/sshd_config
/etc/ssh/sshd_config.d
/etc/systemd/system/xray-backend.service
/etc/systemd/system/xray-watchdog.service
/etc/systemd/system/xray-security-monitor.service
/etc/systemd/system/xray-security-monitor.timer
/etc/systemd/system/xray-fail2ban-daily-report.service
/etc/systemd/system/xray-fail2ban-daily-report.timer
/etc/fail2ban/jail.d/xray-panel.local
/etc/fail2ban/filter.d
/etc/certs
/usr/local/bin/xray-security-monitor.sh
/usr/local/bin/xray-fail2ban-daily-report.sh
PATHS
  local extra
  extra="$(trim "$(read_cfg "TG_FILE_WATCH_PATHS")")"
  if [ -n "$extra" ]; then
    printf "%s\n" "$extra" | tr ',' '\n'
  fi
}

snapshot_path() {
  local path="$1"
  [ -e "$path" ] || return 0
  if [ -d "$path" ]; then
    find "$path" -xdev \
      \( -path '*/backups/*' -o -name '*.log' -o -name '*.tmp' \) -prune -o \
      -type f -printf '%p|%s|%T@\n' 2>/dev/null || true
  else
    stat -Lc '%n|%s|%Y' "$path" 2>/dev/null || true
  fi
}

build_file_snapshot() {
  local path
  while IFS= read -r path; do
    [ -z "$path" ] && continue
    snapshot_path "$path"
  done < <(watch_paths) | sort -u
}

check_file_modifications() {
  local current_file="${STATE_DIR}/files.current"
  local previous_file="${STATE_DIR}/files.previous"
  local added removed body
  build_file_snapshot > "$current_file" || true
  if [ ! -f "$previous_file" ]; then
    cp -f "$current_file" "$previous_file"
    return 0
  fi
  added="$(comm -13 "$previous_file" "$current_file" 2>/dev/null | cut -d'|' -f1 | head -n "$MAX_ALERT_LINES" || true)"
  removed="$(comm -23 "$previous_file" "$current_file" 2>/dev/null | cut -d'|' -f1 | head -n "$MAX_ALERT_LINES" || true)"
  cp -f "$current_file" "$previous_file"
  if [ -n "$added" ] || [ -n "$removed" ]; then
    body="关键系统/服务文件发生变化。"
    if [ -n "$added" ]; then
      body="${body}
新增或变更:
$(format_code_lines "$added")"
    fi
    if [ -n "$removed" ]; then
      body="${body}
删除或旧版本消失:
$(format_code_lines "$removed")"
    fi
    body="${body}
如需扩大范围，可在配置里追加 <code>TG_FILE_WATCH_PATHS=/path1,/path2</code>。"
    append_alert_section "[告警] 关键文件变更" "$body"
  fi
}

TG_ENABLED="$(trim "$(read_cfg "TG_ALERT_ENABLED")")"
TG_BOT_TOKEN="$(trim "$(read_cfg "TG_BOT_TOKEN")")"
TG_CHAT_ID="$(trim "$(read_cfg "TG_CHAT_ID")")"
TG_COOLDOWN="$(trim "$(read_cfg "TG_ALERT_COOLDOWN")")"
SECURITY_ALERT_INGEST_URL="$(trim "$(read_cfg "SECURITY_ALERT_INGEST_URL")")"
SECURITY_ALERT_INGEST_TOKEN="$(trim "$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")")"
VPS_NAME="$(trim "$(read_cfg "VPS_DISPLAY_NAME")")"
HOST_NAME="$(hostname 2>/dev/null | tr -d '\r\n' || true)"
PUBLIC_IP="$(trim "$(read_cfg "PUBLIC_IP")")"

[ "$TG_ENABLED" = "1" ] || exit 0
if [ -z "$SECURITY_ALERT_INGEST_URL" ] || [ -z "$SECURITY_ALERT_INGEST_TOKEN" ]; then
  [ -n "$TG_BOT_TOKEN" ] || exit 0
  [ -n "$TG_CHAT_ID" ] || exit 0
fi
if ! [[ "$TG_COOLDOWN" =~ ^[0-9]+$ ]]; then
  TG_COOLDOWN="$DEFAULT_COOLDOWN"
fi
if [ -z "$VPS_NAME" ]; then
  VPS_NAME="${HOST_NAME:-Xray 节点}"
fi
if [ -z "$HOST_NAME" ]; then
  HOST_NAME="unknown"
fi

mkdir -p "$STATE_DIR"
acquire_queue_lock || exit 0
check_ssh_logins || true
check_listening_ports || true
check_traffic || true
check_file_modifications || true
flush_alerts || true
release_queue_lock
EOF
  chown root:root /usr/local/bin/xray-security-monitor.sh 2>/dev/null || true
  chmod 700 /usr/local/bin/xray-security-monitor.sh
}

mgr_write_security_monitor_service() {
  cat > /etc/systemd/system/xray-security-monitor.service <<EOF
[Unit]
Description=Xray Telegram Security Monitor
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
ExecStart=/usr/local/bin/xray-security-monitor.sh
Environment=CONFIG_FILE=${CONFIG_FILE}
Environment=STATE_DIR=${STATE_DIR}/security-monitor
Environment=EXPECTED_PUBLIC_PORTS=80,443
Environment=QUEUE_LOCK_DIR=${STATE_DIR}/security-monitor/queue.lock.d
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectHome=true
ProtectSystem=full
ProtectKernelModules=true
ProtectControlGroups=true
LockPersonality=true
RestrictRealtime=true
RestrictSUIDSGID=true
ReadWritePaths=${STATE_DIR}
EOF

  cat > /etc/systemd/system/xray-security-monitor.timer <<'EOF'
[Unit]
Description=Run Xray Telegram security monitor

[Timer]
OnBootSec=2min
OnUnitActiveSec=60s
AccuracySec=15s
Persistent=true
Unit=xray-security-monitor.service

[Install]
WantedBy=timers.target
EOF
}

mgr_sync_tg_alert_service() {
  local token chat_id ingest_url ingest_token
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"
  ingest_url="$(read_cfg "SECURITY_ALERT_INGEST_URL")"
  ingest_token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")"

  mgr_write_security_monitor_script
  mgr_write_security_monitor_service
  systemctl daemon-reload || true

  if mgr_tg_alert_is_enabled && { { [ -n "$token" ] && [ -n "$chat_id" ]; } || { [ -n "$ingest_url" ] && [ -n "$ingest_token" ]; }; }; then
    if [ -n "$token" ] && [ -n "$chat_id" ]; then
      systemctl enable xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
      systemctl restart xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
    else
      systemctl stop xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
      systemctl disable xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
    fi
    systemctl enable xray-security-monitor.timer >/dev/null 2>&1 || true
    systemctl restart xray-security-monitor.timer >/dev/null 2>&1 || true
    log_info "安全巡检已启动；告警将按配置发送到 Telegram 或中央面板。"
  else
    systemctl stop xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
    systemctl disable xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
    systemctl stop xray-security-monitor.timer >/dev/null 2>&1 || true
    systemctl disable xray-security-monitor.timer >/dev/null 2>&1 || true
    log_info "Telegram 日报和安全巡检已关闭。"
  fi
}

mgr_send_tg_test_message() {
  local token chat_id mode vps_name reality_sni host_name public_ip
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"
  mode="$(mgr_get_current_mode)"
  vps_name="$(read_cfg "VPS_DISPLAY_NAME")"
  reality_sni="$(mgr_get_reality_sni_domain)"
  host_name="$(hostname 2>/dev/null || echo "unknown")"
  public_ip="$(read_cfg "PUBLIC_IP")"
  if [ -z "$vps_name" ]; then
    vps_name="$host_name"
  fi

  if [ -z "$token" ] || [ -z "$chat_id" ]; then
    log_error "请先配置 TG_BOT_TOKEN 和 TG_CHAT_ID。"
    return 1
  fi

  if curl -fsS --max-time 10 --config - \
    -d "chat_id=${chat_id}" \
    -d "disable_web_page_preview=true" \
    --data-urlencode "text=[测试成功] Xray Telegram 通知
节点名称: ${vps_name}
主机名: ${host_name}
公网 IP: ${public_ip:-未配置}
时间: $(date '+%F %T %z')
模式: ${mode}
Reality 伪装域名: ${reality_sni:-未设置}
说明: 如果你收到这条消息，说明 Telegram 配置可用。" >/dev/null <<CURLCFG; then
url = "https://api.telegram.org/bot${token}/sendMessage"
CURLCFG
    log_info "测试消息发送成功。"
    return 0
  fi

  log_error "测试消息发送失败，请检查 Bot Token、Chat ID 或网络连通性。"
  return 1
}

mgr_send_central_alert_test_message() {
  local ingest_url ingest_token vps_name host_name public_ip section
  ingest_url="$(read_cfg "SECURITY_ALERT_INGEST_URL")"
  ingest_token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")"
  vps_name="$(read_cfg "VPS_DISPLAY_NAME")"
  host_name="$(hostname 2>/dev/null || echo "unknown")"
  public_ip="$(read_cfg "PUBLIC_IP")"
  if [ -z "$vps_name" ]; then
    vps_name="$host_name"
  fi
  if [ -z "$ingest_url" ] || [ -z "$ingest_token" ]; then
    log_error "请先配置中央面板上报地址和 Token。"
    return 1
  fi

  section="<b>[告警] 接入测试</b>
<code>无前端机器已成功上报到主面板。</code>
<code>时间: $(date '+%F %T %z')</code>"

  if curl -fsS --connect-timeout 5 --max-time 15 \
    -H "X-Requested-With: XMLHttpRequest" \
    -H "Authorization: Bearer ${ingest_token}" \
    --data-urlencode "machineName=${vps_name}" \
    --data-urlencode "hostname=${host_name}" \
    --data-urlencode "publicIP=${public_ip:-未配置}" \
    --data-urlencode "sectionsHtml=${section}" \
    "$ingest_url" >/dev/null; then
    log_info "中央面板测试上报成功。主面板会按 60 秒合并窗口统一推 TG。"
    return 0
  fi

  log_error "中央面板测试上报失败，请检查地址、Token、Nginx/API 前缀和网络连通性。"
  return 1
}

mgr_manage_tg_alert() {
  clear
  echo -e "${CYAN}==== Telegram 通知管理 ====${NC}"
  echo ""

  local enabled token chat_id cooldown traffic_threshold service_status security_status token_masked vps_name ingest_url ingest_token ingest_token_masked
  enabled="$(read_cfg "TG_ALERT_ENABLED")"
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"
  cooldown="$(read_cfg "TG_ALERT_COOLDOWN")"
  traffic_threshold="$(read_cfg "TG_TRAFFIC_ALERT_MBPS")"
  vps_name="$(read_cfg "VPS_DISPLAY_NAME")"
  ingest_url="$(read_cfg "SECURITY_ALERT_INGEST_URL")"
  ingest_token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")"
  service_status="$(systemctl is-active xray-fail2ban-daily-report.timer 2>/dev/null || echo "inactive")"
  security_status="$(systemctl is-active xray-security-monitor.timer 2>/dev/null || echo "inactive")"

  if [ -n "$token" ]; then
    token_masked="$(mgr_mask_secret "$token")"
  else
    token_masked="未设置"
  fi
  if [ -n "$ingest_token" ]; then
    ingest_token_masked="$(mgr_mask_secret "$ingest_token")"
  else
    ingest_token_masked="未设置"
  fi
  if [ -z "$chat_id" ]; then
    chat_id="未设置"
  fi
  if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
    cooldown="1800"
  fi
  if ! [[ "$traffic_threshold" =~ ^[0-9]+$ ]] || [ "$traffic_threshold" -lt 1 ]; then
    traffic_threshold="500"
  fi
  if [ -z "$vps_name" ]; then
    vps_name="$(hostname 2>/dev/null || echo "Xray 节点")"
  fi

  echo "状态: ${enabled:-0} (1=启用, 0=关闭)"
  echo "日报定时器: ${service_status}"
  echo "安全巡检定时器: ${security_status}"
  echo "节点名称: ${vps_name}"
  echo "Bot Token: ${token_masked}"
  echo "Chat ID: ${chat_id}"
  echo "中央上报地址: ${ingest_url:-未设置}"
  echo "中央上报 Token: ${ingest_token_masked}"
  echo "告警冷却时间: ${cooldown} 秒"
  echo "流量异常阈值: ${traffic_threshold} Mbps"
  echo ""
  echo "1) 配置节点名称、Token、Chat ID 并启用"
  echo "2) 关闭通知"
  echo "3) 发送测试消息"
  echo "4) 查看日报服务日志"
  echo "5) 配置中央面板上报并启用"
  echo "6) 测试中央面板上报"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r tg_choice

  case "$tg_choice" in
    1)
      echo -n "请输入节点名称 / VPS 名称（支持中文）: "
      read -r vps_name
      if [ -z "$vps_name" ]; then
        vps_name="$(hostname 2>/dev/null || echo "Xray 节点")"
      fi
      echo -n "请输入 Telegram Bot Token: "
      read -r token
      if [ -z "$token" ]; then
        log_error "Telegram Bot Token 不能为空。"
        mgr_pause_wait
        return
      fi
      echo -n "请输入 Telegram Chat ID: "
      read -r chat_id
      if [ -z "$chat_id" ]; then
        log_error "Telegram Chat ID 不能为空。"
        mgr_pause_wait
        return
      fi
      echo -n "请输入告警冷却秒数（默认 1800）: "
      read -r cooldown
      if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
        cooldown="1800"
      fi
      echo -n "请输入流量异常阈值 Mbps（默认 500）: "
      read -r traffic_threshold
      if ! [[ "$traffic_threshold" =~ ^[0-9]+$ ]] || [ "$traffic_threshold" -lt 1 ]; then
        traffic_threshold="500"
      fi
      save_cfg "VPS_DISPLAY_NAME" "$vps_name"
      save_cfg "TG_BOT_TOKEN" "$token"
      save_cfg "TG_CHAT_ID" "$chat_id"
      save_cfg "TG_ALERT_COOLDOWN" "$cooldown"
      save_cfg "TG_TRAFFIC_ALERT_MBPS" "$traffic_threshold"
      save_cfg "TG_ALERT_ENABLED" "1"
      mgr_sync_tg_alert_service
      mgr_send_tg_test_message || true
      ;;
    2)
      save_cfg "TG_ALERT_ENABLED" "0"
      mgr_sync_tg_alert_service
      ;;
    3)
      mgr_send_tg_test_message || true
      ;;
    4)
      journalctl -u xray-fail2ban-daily-report.service -u xray-security-monitor.service -n 100 --no-pager || true
      ;;
    5)
      echo -n "请输入节点名称 / VPS 名称（支持中文）: "
      read -r vps_name
      if [ -z "$vps_name" ]; then
        vps_name="$(hostname 2>/dev/null || echo "Xray 节点")"
      fi
      echo "请输入主面板给出的中央上报地址，形如 https://domain/<api-prefix>/api/system/security-alerts/ingest"
      echo -n "中央上报地址: "
      read -r ingest_url
      ingest_url="$(echo "$ingest_url" | tr -d '\r\n\t ')"
      if [[ ! "$ingest_url" =~ ^https?://[^[:space:]]+/api/system/security-alerts/ingest$ ]]; then
        log_error "中央上报地址格式无效。请从主面板 Telegram 通知管理中复制完整地址。"
        mgr_pause_wait
        return
      fi
      echo -n "中央上报 Token: "
      read -r ingest_token
      ingest_token="$(echo "$ingest_token" | tr -d '\r\n\t ')"
      if ! [[ "$ingest_token" =~ ^[A-Za-z0-9._-]{16,256}$ ]]; then
        log_error "中央上报 Token 格式无效。"
        mgr_pause_wait
        return
      fi
      echo -n "请输入告警冷却秒数（默认 1800）: "
      read -r cooldown
      if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
        cooldown="1800"
      fi
      echo -n "请输入流量异常阈值 Mbps（默认 500）: "
      read -r traffic_threshold
      if ! [[ "$traffic_threshold" =~ ^[0-9]+$ ]] || [ "$traffic_threshold" -lt 1 ]; then
        traffic_threshold="500"
      fi
      save_cfg "VPS_DISPLAY_NAME" "$vps_name"
      save_cfg "SECURITY_ALERT_INGEST_URL" "$ingest_url"
      save_cfg "SECURITY_ALERT_INGEST_TOKEN" "$ingest_token"
      save_cfg "TG_ALERT_COOLDOWN" "$cooldown"
      save_cfg "TG_TRAFFIC_ALERT_MBPS" "$traffic_threshold"
      save_cfg "TG_ALERT_ENABLED" "1"
      mgr_sync_tg_alert_service
      mgr_send_central_alert_test_message || true
      ;;
    6)
      mgr_send_central_alert_test_message || true
      ;;
    *)
      ;;
  esac

  mgr_pause_wait
}

mgr_get_xray_bin() {
  if command -v xray >/dev/null 2>&1; then
    command -v xray
    return
  fi
  if [ -x /usr/local/bin/xray ]; then
    echo "/usr/local/bin/xray"
    return
  fi
  echo ""
}

mgr_get_mihomo_bin() {
  if command -v mihomo >/dev/null 2>&1; then
    command -v mihomo
    return
  fi
  if [ -x /usr/local/bin/mihomo ]; then
    echo "/usr/local/bin/mihomo"
    return
  fi
  if [ -x "${INSTALL_DIR}/mihomo-core" ]; then
    echo "${INSTALL_DIR}/mihomo-core"
    return
  fi
  echo ""
}

mgr_get_mihomo_version() {
  local mihomo_bin version_output
  mihomo_bin="$(mgr_get_mihomo_bin)"
  if [ -z "$mihomo_bin" ]; then
    echo "未安装"
    return
  fi
  version_output="$("$mihomo_bin" -v 2>/dev/null | head -n 1 | tr -d '\r')"
  if [ -n "$version_output" ]; then
    echo "$version_output"
    return
  fi
  echo "已安装"
}

mgr_generate_uuid() {
  local xray_bin
  xray_bin="$(mgr_get_xray_bin)"
  if [ -n "$xray_bin" ]; then
    "$xray_bin" uuid 2>/dev/null | tr -d '\r\n '
    return
  fi
  cat /proc/sys/kernel/random/uuid 2>/dev/null || echo ""
}

mgr_generate_short_id() {
  local generated
  if command -v openssl >/dev/null 2>&1; then
    generated="$(openssl rand -hex 8 2>/dev/null | tr -d '\r\n ' | tr '[:upper:]' '[:lower:]')"
    if [[ "$generated" =~ ^[a-f0-9]{16}$ ]]; then
      printf "%s" "$generated"
      return
    fi
  fi
  generated="$(tr -dc 'a-f0-9' < /dev/urandom | head -c 16)"
  printf "%s" "$generated"
}

mgr_normalize_reality_short_id() {
  local raw normalized
  raw="$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')"
  normalized="$(printf "%s" "$raw" | tr -cd 'a-f0-9')"
  if [ "${#normalized}" -gt 16 ]; then
    normalized="${normalized:0:16}"
  fi
  if [ $(( ${#normalized} % 2 )) -ne 0 ]; then
    normalized="${normalized%?}"
  fi
  printf "%s" "$normalized"
}

mgr_normalize_reality_short_ids() {
  local raw="$1"
  local normalized output seen part
  local parts=()

  IFS=',' read -r -a parts <<< "$raw"
  output=""
  seen="|"

  for part in "${parts[@]}"; do
    normalized="$(mgr_normalize_reality_short_id "$part")"
    if [ -z "$normalized" ]; then
      continue
    fi
    case "$seen" in
      *"|${normalized}|"*) continue ;;
    esac
    seen="${seen}${normalized}|"
    if [ -n "$output" ]; then
      output="${output},${normalized}"
    else
      output="${normalized}"
    fi
  done

  printf "%s" "$output"
}

mgr_primary_reality_short_id() {
  local normalized
  normalized="$(mgr_normalize_reality_short_ids "$1")"
  printf "%s" "${normalized%%,*}"
}

normalize_node_path() {
  local raw="$1"
  local trimmed
  trimmed="$(echo "$raw" | tr -d '\r\n\t ')"
  trimmed="$(echo "$trimmed" | sed 's#[?#].*$##')"
  trimmed="$(echo "$trimmed" | sed 's#^/*##' | sed 's#/*$##')"
  trimmed="$(echo "$trimmed" | sed 's#[^a-zA-Z0-9/_-]##g')"
  trimmed="$(echo "$trimmed" | sed 's#//*#/#g')"
  if [ -z "$trimmed" ]; then
    trimmed="$(generate_random_suffix)"
  fi
  echo "/${trimmed}"
}

mgr_normalize_location_path() {
  local raw="$1"
  local trimmed
  trimmed="$(echo "$raw" | tr -d '\r\n\t ')"
  trimmed="$(echo "$trimmed" | sed 's#[?#].*$##')"
  trimmed="$(echo "$trimmed" | sed 's#^/*##' | sed 's#/*$##')"
  trimmed="$(echo "$trimmed" | sed 's#//*#/#g')"
  if [ -z "$trimmed" ]; then
    echo ""
    return
  fi
  echo "/${trimmed}"
}

mgr_paths_overlap() {
  local left right
  left="$(mgr_normalize_location_path "$1")"
  right="$(mgr_normalize_location_path "$2")"

  if [ -z "$left" ] || [ -z "$right" ]; then
    return 1
  fi
  if [ "$left" = "$right" ]; then
    return 0
  fi
  case "${left}/" in
    "${right}/"*) return 0 ;;
  esac
  case "${right}/" in
    "${left}/"*) return 0 ;;
  esac
  return 1
}

mgr_resolve_unique_tls_node_path() {
  local raw="$1"
  local node_path reality_path attempts
  node_path="$(normalize_node_path "$raw")"
  reality_path="$(mgr_normalize_location_path "$(read_cfg "REALITY_NODE_PATH")")"
  attempts=0

  while [ -n "$reality_path" ] && mgr_paths_overlap "$node_path" "$reality_path"; do
    attempts=$((attempts + 1))
    node_path="/$(generate_random_suffix)"
    if [ "$attempts" -ge 32 ]; then
      break
    fi
  done

  echo "$node_path"
}

mgr_get_tls_node_path() {
  local node_path
  node_path="$(read_cfg "TLS_NODE_PATH")"
  node_path="$(normalize_node_path "$node_path")"
  save_cfg "TLS_NODE_PATH" "$node_path"
  echo "$node_path"
}

mgr_normalize_tls_node_network() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')" in
    httpupgrade) echo "httpupgrade" ;;
    xhttp) echo "xhttp" ;;
    *) echo "ws" ;;
  esac
}

mgr_get_tls_node_network() {
  local node_network
  node_network="$(mgr_normalize_tls_node_network "$(read_cfg "TLS_NODE_NETWORK")")"
  save_cfg "TLS_NODE_NETWORK" "$node_network"
  echo "$node_network"
}

mgr_normalize_reality_node_network() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')" in
    xhttp) echo "xhttp" ;;
    *) echo "tcp" ;;
  esac
}

mgr_get_reality_node_network() {
  local node_network
  node_network="$(mgr_normalize_reality_node_network "$(read_cfg "REALITY_NODE_NETWORK")")"
  save_cfg "REALITY_NODE_NETWORK" "$node_network"
  echo "$node_network"
}

mgr_get_reality_node_path() {
  local node_path
  node_path="$(read_cfg "REALITY_NODE_PATH")"
  node_path="$(normalize_node_path "$node_path")"
  save_cfg "REALITY_NODE_PATH" "$node_path"
  echo "$node_path"
}

mgr_default_xhttp_padding_bytes() {
  echo "1000-2000"
}

mgr_default_xhttp_xmux_max_concurrency() {
  echo "16-32"
}

mgr_default_xhttp_xmux_hmaxrequesttimes() {
  echo "600-900"
}

mgr_default_xhttp_xmux_hmaxreusablesecs() {
  echo "1800-3000"
}

mgr_default_xhttp_cmaxreusetimes() {
  echo "0"
}

mgr_normalize_xhttp_mode() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')" in
    packet-up|packetup) echo "packet-up" ;;
    stream-up|streamup) echo "stream-up" ;;
    stream-one|streamone) echo "stream-one" ;;
    *) echo "auto" ;;
  esac
}

mgr_normalize_xhttp_padding_bytes() {
  local raw="$1"
  local trimmed min_value max_value

  trimmed="$(printf "%s" "$raw" | tr -d '\r' | sed 's/[[:space:]]//g')"
  if [ -z "$trimmed" ]; then
    echo ""
    return
  fi
  if ! printf "%s" "$trimmed" | grep -Eq '^[0-9]+-[0-9]+$'; then
    echo ""
    return
  fi

  min_value="${trimmed%%-*}"
  max_value="${trimmed##*-}"
  if [ "${min_value}" -le 0 ] || [ "${max_value}" -le 0 ]; then
    echo ""
    return
  fi
  if [ "${min_value}" -gt "${max_value}" ]; then
    local swap_value
    swap_value="${min_value}"
    min_value="${max_value}"
    max_value="${swap_value}"
  fi

  printf "%s-%s" "${min_value}" "${max_value}"
}

mgr_get_tls_node_xhttp_mode() {
  local value
  value="$(mgr_normalize_xhttp_mode "$(read_cfg "TLS_NODE_XHTTP_MODE")")"
  save_cfg "TLS_NODE_XHTTP_MODE" "$value"
  echo "$value"
}

mgr_get_reality_node_xhttp_mode() {
  local value
  value="$(mgr_normalize_xhttp_mode "$(read_cfg "REALITY_NODE_XHTTP_MODE")")"
  save_cfg "REALITY_NODE_XHTTP_MODE" "$value"
  echo "$value"
}

mgr_get_tls_node_xhttp_padding_bytes() {
  local value
  value="$(mgr_normalize_xhttp_padding_bytes "$(read_cfg "TLS_NODE_XHTTP_PADDING_BYTES")")"
  if [ -z "$value" ]; then
    value="$(mgr_default_xhttp_padding_bytes)"
  fi
  save_cfg "TLS_NODE_XHTTP_PADDING_BYTES" "$value"
  echo "$value"
}

mgr_get_reality_node_xhttp_padding_bytes() {
  local value
  value="$(mgr_normalize_xhttp_padding_bytes "$(read_cfg "REALITY_NODE_XHTTP_PADDING_BYTES")")"
  if [ -z "$value" ]; then
    value="$(mgr_default_xhttp_padding_bytes)"
  fi
  save_cfg "REALITY_NODE_XHTTP_PADDING_BYTES" "$value"
  echo "$value"
}

mgr_normalize_vless_crypto_value() {
  local raw="$1"
  local trimmed
  trimmed="$(printf "%s" "$raw" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
  if [ -z "$trimmed" ]; then
    echo "none"
    return
  fi
  echo "$trimmed"
}

mgr_get_tls_node_decryption() {
  local value
  value="$(mgr_normalize_vless_crypto_value "$(read_cfg "TLS_NODE_DECRYPTION")")"
  save_cfg "TLS_NODE_DECRYPTION" "$value"
  echo "$value"
}

mgr_get_tls_node_encryption() {
  local value
  value="$(mgr_normalize_vless_crypto_value "$(read_cfg "TLS_NODE_ENCRYPTION")")"
  save_cfg "TLS_NODE_ENCRYPTION" "$value"
  echo "$value"
}

mgr_get_reality_node_decryption() {
  local value
  value="$(mgr_normalize_vless_crypto_value "$(read_cfg "REALITY_NODE_DECRYPTION")")"
  save_cfg "REALITY_NODE_DECRYPTION" "$value"
  echo "$value"
}

mgr_get_reality_node_encryption() {
  local value
  value="$(mgr_normalize_vless_crypto_value "$(read_cfg "REALITY_NODE_ENCRYPTION")")"
  save_cfg "REALITY_NODE_ENCRYPTION" "$value"
  echo "$value"
}

mgr_vlessenc_status_text() {
  local decryption
  decryption="$(mgr_normalize_vless_crypto_value "$1")"
  if [ "$decryption" = "none" ]; then
    echo "已关闭"
  else
    echo "已启用"
  fi
}

mgr_compact_value() {
  local value="$1"
  local limit="${2:-64}"
  if [ "${#value}" -le "$limit" ]; then
    echo "$value"
    return
  fi
  printf "%s..." "${value:0:$limit}"
}

mgr_default_tls_alpn() {
  case "$1" in
    xhttp)
      echo ""
      ;;
    *)
      echo "http/1.1"
      ;;
  esac
}

mgr_supports_vlessenc() {
  local xray_bin
  xray_bin="$(mgr_get_xray_bin)"
  if [ -z "$xray_bin" ]; then
    return 1
  fi
  "$xray_bin" help 2>/dev/null | grep -q "vlessenc"
}

mgr_detect_vlessenc_auth_method() {
  local decryption encryption combined
  decryption="$(mgr_normalize_vless_crypto_value "$1")"
  encryption="$(mgr_normalize_vless_crypto_value "$2")"
  combined="$(printf "%s %s" "$decryption" "$encryption" | tr '[:upper:]' '[:lower:]')"
  case "$combined" in
    *mlkem768*)
      echo "mlkem768"
      ;;
    *)
      echo "x25519"
      ;;
  esac
}

mgr_prompt_vlessenc_auth_method() {
  local choice
  echo "" >&2
  echo "请选择 VLESS 加密认证方式：" >&2
  echo "1) X25519（兼容性更稳，非后量子认证）" >&2
  echo "2) ML-KEM-768（后量子认证）" >&2
  echo -n "请选择 [1-2]（回车默认 1）: " >&2
  read -r choice
  case "$choice" in
    2) echo "mlkem768" ;;
    *) echo "x25519" ;;
  esac
}

mgr_generate_vlessenc_pair() {
  local preferred_auth="$1"
  local xray_bin output decryption encryption current_auth line value
  xray_bin="$(mgr_get_xray_bin)"
  if [ -z "$xray_bin" ]; then
    log_error "未找到 xray 可执行文件，无法自动生成 VLESS 加密参数。"
    return 1
  fi
  if ! mgr_supports_vlessenc; then
    log_error "当前 Xray core 不支持 vlessenc，请升级到支持 VLESS Encryption 的版本。"
    return 1
  fi

  output="$("$xray_bin" vlessenc 2>/dev/null || true)"
  current_auth=""
  while IFS= read -r line; do
    case "$line" in
      "Authentication: X25519"*)
        current_auth="x25519"
        ;;
      "Authentication: ML-KEM-768"*)
        current_auth="mlkem768"
        ;;
      *'"decryption":'*)
        if [ "$current_auth" = "$preferred_auth" ]; then
          value="$(printf "%s" "$line" | sed -nE 's/.*"decryption"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/p')"
          decryption="$value"
        fi
        ;;
      *'"encryption":'*)
        if [ "$current_auth" = "$preferred_auth" ]; then
          value="$(printf "%s" "$line" | sed -nE 's/.*"encryption"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/p')"
          encryption="$value"
        fi
        ;;
    esac
  done <<< "$output"

  if [ -z "$decryption" ] || [ -z "$encryption" ]; then
    log_error "xray vlessenc 输出解析失败。"
    log_warn "未找到 ${preferred_auth} 对应的 decryption/encryption。"
    return 1
  fi

  echo "${decryption}|${encryption}"
}

mgr_prompt_vlessenc_pair() {
  local scope_label="$1"
  local decryption_key="$2"
  local encryption_key="$3"
  local current_decryption current_encryption choice selected_decryption selected_encryption generated_pair auth_method

  current_decryption="$(mgr_normalize_vless_crypto_value "$(read_cfg "$decryption_key")")"
  current_encryption="$(mgr_normalize_vless_crypto_value "$(read_cfg "$encryption_key")")"
  if [ "$current_decryption" = "none" ]; then
    current_encryption="none"
  fi

  echo "" >&2
  echo "${scope_label} VLESS 加密：" >&2
  echo "1) 关闭（decryption / encryption = none）" >&2
  echo "2) 自动生成并作废旧值（xray vlessenc）" >&2
  echo "3) 手动输入" >&2
  echo "" >&2
  echo "当前状态: $(mgr_vlessenc_status_text "$current_decryption")" >&2
  if [ "$current_decryption" != "none" ]; then
    echo "当前 decryption: $(mgr_compact_value "$current_decryption")" >&2
    echo "当前 encryption: $(mgr_compact_value "$current_encryption")" >&2
    echo "回车默认会按当前认证方式重新生成一组新值，旧值立即作废。" >&2
  else
    echo "回车默认会自动生成一组新值；如需关闭请选择 1。" >&2
  fi
  echo -n "请选择 [1-3]（回车自动生成）: " >&2
  read -r choice

  case "$choice" in
    1)
      selected_decryption="none"
      selected_encryption="none"
      ;;
    2)
      auth_method="$(mgr_prompt_vlessenc_auth_method)"
      generated_pair="$(mgr_generate_vlessenc_pair "$auth_method")" || return 1
      IFS='|' read -r selected_decryption selected_encryption <<< "$generated_pair"
      ;;
    3)
      echo -n "请输入服务端 decryption（留空视为关闭）: " >&2
      read -r selected_decryption
      selected_decryption="$(mgr_normalize_vless_crypto_value "$selected_decryption")"
      if [ "$selected_decryption" = "none" ]; then
        selected_encryption="none"
      else
        echo -n "请输入客户端 encryption（不能为空）: " >&2
        read -r selected_encryption
        selected_encryption="$(mgr_normalize_vless_crypto_value "$selected_encryption")"
        if [ "$selected_encryption" = "none" ]; then
          log_error "手动输入模式下，启用 VLESS 加密时 encryption 不能为空。"
          return 1
        fi
      fi
      ;;
    *)
      if [ "$current_decryption" = "none" ]; then
        auth_method="$(mgr_prompt_vlessenc_auth_method)"
        generated_pair="$(mgr_generate_vlessenc_pair "$auth_method")" || return 1
        IFS='|' read -r selected_decryption selected_encryption <<< "$generated_pair"
      else
        auth_method="$(mgr_detect_vlessenc_auth_method "$current_decryption" "$current_encryption")"
        generated_pair="$(mgr_generate_vlessenc_pair "$auth_method")" || return 1
        IFS='|' read -r selected_decryption selected_encryption <<< "$generated_pair"
      fi
      ;;
  esac

  save_cfg "$decryption_key" "$selected_decryption"
  save_cfg "$encryption_key" "$selected_encryption"
  if [ "$selected_decryption" != "$current_decryption" ] || [ "$selected_encryption" != "$current_encryption" ]; then
    if [ "$selected_decryption" = "none" ]; then
      log_info "${scope_label} VLESS 加密已关闭。"
    elif [ "$current_decryption" = "none" ]; then
      log_info "${scope_label} VLESS 加密参数已生成。"
    else
      log_info "${scope_label} VLESS 加密参数已更新，旧值已作废。"
    fi
  fi
  echo "${selected_decryption}|${selected_encryption}"
}

mgr_prompt_tls_node_network() {
  local current_network choice selected_network
  current_network="$(mgr_get_tls_node_network)"

  echo "" >&2
  echo "TLS 受管节点传输协议：" >&2
  echo "1) WebSocket" >&2
  echo "2) HTTPUpgrade" >&2
  echo "3) XHTTP" >&2
  echo "" >&2
  case "$current_network" in
    httpupgrade) echo "当前选择: HTTPUpgrade" >&2 ;;
    xhttp) echo "当前选择: XHTTP" >&2 ;;
    *) echo "当前选择: WebSocket" >&2 ;;
  esac
  echo -n "请选择 [1-3]（回车保持当前）: " >&2
  read -r choice

  case "$choice" in
    1) selected_network="ws" ;;
    2) selected_network="httpupgrade" ;;
    3) selected_network="xhttp" ;;
    *) selected_network="$current_network" ;;
  esac

  save_cfg "TLS_NODE_NETWORK" "$selected_network"
  echo "$selected_network"
}

mgr_prompt_reality_node_network() {
  local current_network choice selected_network
  current_network="$(mgr_get_reality_node_network)"

  echo "" >&2
  echo "Reality 受管节点传输协议：" >&2
  echo "1) TCP (RAW)" >&2
  echo "2) XHTTP" >&2
  echo "" >&2
  case "$current_network" in
    xhttp) echo "当前选择: XHTTP" >&2 ;;
    *) echo "当前选择: TCP (RAW)" >&2 ;;
  esac
  echo -n "请选择 [1-2]（回车保持当前）: " >&2
  read -r choice

  case "$choice" in
    1) selected_network="tcp" ;;
    2) selected_network="xhttp" ;;
    *) selected_network="$current_network" ;;
  esac

  save_cfg "REALITY_NODE_NETWORK" "$selected_network"
  echo "$selected_network"
}

mgr_prompt_xhttp_mode() {
  local scope_label="$1"
  local cfg_key="$2"
  local current_mode choice selected_mode

  current_mode="$(mgr_normalize_xhttp_mode "$(read_cfg "$cfg_key")")"

  echo "" >&2
  echo "${scope_label} XHTTP 模式：" >&2
  echo "1) auto（官方默认）" >&2
  echo "2) packet-up" >&2
  echo "3) stream-up" >&2
  echo "4) stream-one" >&2
  echo "" >&2
  echo "当前选择: ${current_mode}" >&2
  echo -n "请选择 [1-4]（回车保持当前）: " >&2
  read -r choice

  case "$choice" in
    2) selected_mode="packet-up" ;;
    3) selected_mode="stream-up" ;;
    4) selected_mode="stream-one" ;;
    *) selected_mode="$current_mode" ;;
  esac

  save_cfg "$cfg_key" "$selected_mode"
  echo "$selected_mode"
}

mgr_generate_reality_keypair() {
  local xray_bin output private_key public_key
  xray_bin="$(mgr_get_xray_bin)"
  if [ -z "$xray_bin" ]; then
    return 1
  fi

  output="$("$xray_bin" x25519 2>&1 || true)"
  # Xray v26.3.x prints:
  #   PrivateKey: ...
  #   Password (PublicKey): ...
  #   Hash32: ...
  # Older builds may print:
  #   Private key: ...
  #   Public key: ...
  # Parse line-by-line so label punctuation changes do not break Reality bootstrap.
  private_key="$(printf "%s\n" "$output" | while IFS= read -r line; do
    case "$line" in
      *PrivateKey:*|*Private\ key:*)
        value="${line#*:}"
        value="$(printf "%s" "$value" | tr -d '[:space:]\r')"
        if [ -n "$value" ]; then
          printf "%s" "$value"
          break
        fi
        ;;
    esac
  done)"
  public_key="$(printf "%s\n" "$output" | while IFS= read -r line; do
    case "$line" in
      *"Password (PublicKey):"*|*"Password:"*|*"PublicKey:"*|*"Public key:"*)
        value="${line#*:}"
        value="$(printf "%s" "$value" | tr -d '[:space:]\r')"
        if [ -n "$value" ]; then
          printf "%s" "$value"
          break
        fi
        ;;
    esac
  done)"
  if [ -z "$private_key" ] || [ -z "$public_key" ]; then
    return 1
  fi
  echo "${private_key}|${public_key}"
}

mgr_ensure_sqlite3() {
  if command -v sqlite3 >/dev/null 2>&1; then
    return 0
  fi

  case "$OS" in
    debian)
      apt-get update -y && apt-get install -y sqlite3
      ;;
    centos)
      yum install -y sqlite
      ;;
    *)
      return 1
      ;;
  esac

  command -v sqlite3 >/dev/null 2>&1
}

sql_escape() {
  printf "%s" "$1" | sed "s/'/''/g"
}

sqlite_uint_or_empty() {
  local value="$1"
  if [[ "$value" =~ ^[0-9]+$ ]]; then
    printf "%s" "$value"
  fi
}

mgr_get_inbound_443_owner_id() {
  local db_file="$1"
  local exclude_id="$2"
  local exclude_sql=""
  local owner_id

  exclude_id="$(sqlite_uint_or_empty "$exclude_id")"
  if [ -n "$exclude_id" ]; then
    exclude_sql=" AND id<>${exclude_id}"
  fi

  owner_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE port=443${exclude_sql} ORDER BY enable DESC, id LIMIT 1;" 2>/dev/null || true)"
  sqlite_uint_or_empty "$owner_id"
}

mgr_get_inbound_summary() {
  local db_file="$1"
  local inbound_id="$2"
  local row tag security protocol enable port

  inbound_id="$(sqlite_uint_or_empty "$inbound_id")"
  if [ -z "$inbound_id" ]; then
    printf "id=unknown"
    return 0
  fi

  row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(security,''),COALESCE(protocol,''),COALESCE(enable,0),COALESCE(port,0) FROM inbounds WHERE id=${inbound_id} LIMIT 1;" 2>/dev/null || true)"
  if [ -z "$row" ]; then
    printf "id=%s" "$inbound_id"
    return 0
  fi

  IFS='|' read -r tag security protocol enable port <<< "$row"
  printf "id=%s tag=%s security=%s protocol=%s enable=%s port=%s" "$inbound_id" "$tag" "$security" "$protocol" "$enable" "$port"
}

mgr_release_managed_443_by_tag_like_except() {
  local db_file="$1"
  local pattern="$2"
  local keep_id="$3"
  local now="$4"
  local keep_sql=""
  local changed

  if [ -z "$db_file" ] || [ -z "$pattern" ] || [ ! -f "$db_file" ]; then
    printf "0"
    return 0
  fi

  keep_id="$(sqlite_uint_or_empty "$keep_id")"
  now="$(sqlite_uint_or_empty "$now")"
  if [ -n "$keep_id" ]; then
    keep_sql=" AND id<>${keep_id}"
  fi
  if [ -z "$now" ]; then
    now="$(date +%s)"
  fi

  changed="$(sqlite3 "$db_file" "UPDATE inbounds SET enable=0, port=(-1000000000 - id), updated_at=${now} WHERE tag LIKE '$(sql_escape "$pattern")' AND port=443${keep_sql}; SELECT changes();" 2>/dev/null)" || return 1
  changed="$(sqlite_uint_or_empty "$changed")"
  if [ -n "$changed" ] && [ "$changed" -gt 0 ]; then
    printf "1"
  else
    printf "0"
  fi
}

mgr_ensure_inbound_column() {
  local db_file="$1"
  local column="$2"
  local definition="$3"
  local found

  found="$(sqlite3 -separator '|' "$db_file" "PRAGMA table_info(inbounds);" 2>/dev/null | awk -F'|' -v target="$column" '$2 == target { print $2; exit }')"
  if [ "$found" != "$column" ]; then
    sqlite3 "$db_file" "ALTER TABLE inbounds ADD COLUMN ${column} ${definition};" >/dev/null 2>&1 || true
  fi
}

mgr_ensure_vlessenc_schema() {
  local db_file="$1"
  if [ -z "$db_file" ] || [ ! -f "$db_file" ]; then
    return 0
  fi
  mgr_ensure_inbound_column "$db_file" "decryption" "TEXT DEFAULT ''"
  mgr_ensure_inbound_column "$db_file" "encryption" "TEXT DEFAULT ''"
  mgr_ensure_inbound_column "$db_file" "xhttp_padding_bytes" "TEXT DEFAULT ''"
}

mgr_ensure_reality_443_inbound() {
  local db_file="${INSTALL_DIR}/data.db"
  local now domain sni existing_id managed_id port_owner_id row released_opposite
  local tag uuid private_key public_key short_ids current_sni
  local reality_network reality_path reality_flow reality_service reality_target reality_xhttp_padding_bytes
  local reality_decryption reality_encryption
  local keypair refreshed_subscription_token refreshed_subscription_url managed_node_changed
  local current_protocol current_flow current_decryption current_encryption current_transport current_path current_service current_padding current_target current_enable current_listen

  if [ ! -f "$db_file" ]; then
    log_warn "Database not found: $db_file"
    return 1
  fi

  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 is unavailable, skip auto-creating Reality inbound."
    return 1
  fi
  mgr_ensure_vlessenc_schema "$db_file"

  now="$(date +%s)"
  managed_node_changed=0
  domain="$(mgr_get_panel_domain)"
  sni="$(mgr_get_reality_sni_domain)"
  if [ -z "$sni" ]; then
    sni="$(pick_random_camouflage_site)"
    log_warn "Reality SNI fallback is empty, temporary fallback to ${sni}."
  fi
  reality_network="$(mgr_get_reality_node_network)"
  reality_path=""
  reality_flow=""
  reality_service=""
  if [ "$reality_network" = "tcp" ]; then
    reality_flow="xtls-rprx-vision"
  else
    reality_path="$(mgr_get_reality_node_path)"
    reality_service=""
    reality_xhttp_padding_bytes=""
  fi
  reality_target="${sni}:443"
  reality_decryption="$(mgr_get_reality_node_decryption)"
  reality_encryption="$(mgr_get_reality_node_encryption)"
  if [ "$reality_decryption" = "none" ]; then
    reality_encryption="none"
  fi

  managed_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE tag LIKE 'reality-443-auto%' ORDER BY CASE WHEN port=443 THEN 0 ELSE 1 END, enable DESC, id LIMIT 1;")"
  managed_id="$(sqlite_uint_or_empty "$managed_id")"

  if ! released_opposite="$(mgr_release_managed_443_by_tag_like_except "$db_file" "tls-443-direct-auto%" "" "$now")"; then
    log_error "迁移旧 TLS 受管入站端口占位失败。"
    return 1
  fi
  if [ "$released_opposite" = "1" ]; then
    managed_node_changed=1
    log_info "已迁移旧 TLS 受管入站端口占位，释放 443 用于 Reality。"
  fi

  port_owner_id="$(mgr_get_inbound_443_owner_id "$db_file" "$managed_id")"
  if [ -n "$port_owner_id" ]; then
    log_warn "端口 443 已被非当前受管入站占用：$(mgr_get_inbound_summary "$db_file" "$port_owner_id")；为避免覆盖用户配置，已跳过自动创建 Reality 入站。"
    return 1
  elif [ -n "$managed_id" ]; then
    existing_id="$managed_id"
  else
    existing_id=""
  fi

  if [ -n "$existing_id" ]; then
    row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(uuid,''),COALESCE(private_key,''),COALESCE(public_key,''),COALESCE(short_ids,''),COALESCE(sni,''),COALESCE(protocol,''),COALESCE(flow,''),COALESCE(decryption,''),COALESCE(encryption,''),COALESCE(transport,''),COALESCE(net_path,''),COALESCE(net_service,''),COALESCE(xhttp_padding_bytes,''),COALESCE(target,''),COALESCE(enable,0),COALESCE(listen,'') FROM inbounds WHERE id=${existing_id} LIMIT 1;")"
    IFS='|' read -r tag uuid private_key public_key short_ids current_sni current_protocol current_flow current_decryption current_encryption current_transport current_path current_service current_padding current_target current_enable current_listen <<< "$row"
  else
    tag="reality-443-auto"
  fi

  if [ -z "$uuid" ]; then
    uuid="$(mgr_generate_uuid)"
  fi
  if [ -z "$uuid" ]; then
    log_warn "生成 Reality 入站 UUID 失败。"
    return 1
  fi
  if [ "$reality_network" != "xhttp" ]; then
    reality_xhttp_padding_bytes=""
  fi

  if [ -n "$existing_id" ]; then
    short_ids="$(mgr_normalize_reality_short_ids "$short_ids")"
  fi
  if [ -z "$tag" ]; then
    tag="reality-443-auto"
  fi
  current_sni="$sni"

  if [ -z "$existing_id" ]; then
    managed_node_changed=1
  elif [ -z "$private_key" ] || [ -z "$public_key" ] || [ -z "$short_ids" ] || \
       [ "$current_protocol" != "vless" ] || \
       [ "$current_flow" != "$reality_flow" ] || \
       [ "$current_decryption" != "$reality_decryption" ] || \
       [ "$current_encryption" != "$reality_encryption" ] || \
       [ "$current_transport" != "$reality_network" ] || \
       [ "$current_path" != "$reality_path" ] || \
       [ "$current_service" != "$reality_service" ] || \
       [ "$current_padding" != "$reality_xhttp_padding_bytes" ] || \
       [ "$current_listen" != "0.0.0.0" ] || \
       [ "$current_sni" != "$sni" ] || \
       [ "$current_target" != "$reality_target" ] || \
       [ "$current_enable" != "1" ]; then
    managed_node_changed=1
  fi

  if [ "$managed_node_changed" = "1" ]; then
    local base_tag="$tag"
    local suffix=1

    if [ -z "$short_ids" ]; then
      short_ids="$(mgr_generate_short_id)"
    fi
    keypair="$(mgr_generate_reality_keypair)"
    if [ -z "$keypair" ]; then
      log_warn "生成 Reality 入站 X25519 密钥失败。"
      return 1
    fi
    IFS='|' read -r private_key public_key <<< "$keypair"

    if [ -z "$existing_id" ]; then
      while [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE tag='$(sql_escape "$tag")';")" != "0" ]; do
        tag="${base_tag}-${suffix}"
        suffix=$((suffix + 1))
      done

      if ! sqlite3 "$db_file" "INSERT INTO inbounds (tag, protocol, listen, port, uuid, flow, decryption, encryption, transport, net_path, net_host, net_service, xhttp_padding_bytes, security, sni, target, public_key, private_key, short_ids, spider_x, up_time, down_time, total_quota, expire_time, enable, created_at, updated_at) VALUES ('$(sql_escape "$tag")','vless','0.0.0.0',443,'$(sql_escape "$uuid")','$(sql_escape "$reality_flow")','$(sql_escape "$reality_decryption")','$(sql_escape "$reality_encryption")','$(sql_escape "$reality_network")','$(sql_escape "$reality_path")','','$(sql_escape "$reality_service")','$(sql_escape "$reality_xhttp_padding_bytes")','reality','$(sql_escape "$current_sni")','$(sql_escape "$reality_target")','$(sql_escape "$public_key")','$(sql_escape "$private_key")','$(sql_escape "$short_ids")','/',0,0,0,0,1,${now},${now});"; then
        log_error "写入 Reality 入站失败。"
        return 1
      fi
      if [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE tag='$(sql_escape "$tag")' AND updated_at=${now};")" != "1" ]; then
        log_error "Reality 入站写库后校验失败。"
        return 1
      fi
    else
      if ! sqlite3 "$db_file" "UPDATE inbounds SET protocol='vless', listen='0.0.0.0', port=443, uuid='$(sql_escape "$uuid")', flow='$(sql_escape "$reality_flow")', decryption='$(sql_escape "$reality_decryption")', encryption='$(sql_escape "$reality_encryption")', transport='$(sql_escape "$reality_network")', net_path='$(sql_escape "$reality_path")', net_host='', net_service='$(sql_escape "$reality_service")', xhttp_padding_bytes='$(sql_escape "$reality_xhttp_padding_bytes")', security='reality', sni='$(sql_escape "$current_sni")', target='$(sql_escape "$reality_target")', public_key='$(sql_escape "$public_key")', private_key='$(sql_escape "$private_key")', short_ids='$(sql_escape "$short_ids")', spider_x='/', enable=1, updated_at=${now} WHERE id=${existing_id};"; then
        log_error "更新 Reality 入站失败。"
        return 1
      fi
      if [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE id=${existing_id} AND updated_at=${now};")" != "1" ]; then
        log_error "Reality 入站更新后校验失败。"
        return 1
      fi
    fi
  fi

  mgr_set_current_mode "reality"
  save_cfg "REALITY_NODE_NETWORK" "$reality_network"
  save_cfg "REALITY_SNI_DOMAIN" "$current_sni"
  save_cfg "REALITY_NODE_DECRYPTION" "$reality_decryption"
  save_cfg "REALITY_NODE_ENCRYPTION" "$reality_encryption"
  if [ "$reality_network" = "xhttp" ]; then
    save_cfg "REALITY_NODE_PATH" "$reality_path"
    save_cfg "REALITY_NODE_XHTTP_MODE" ""
    save_cfg "REALITY_NODE_XHTTP_PADDING_BYTES" ""
  fi
  if [ "$managed_node_changed" = "1" ]; then
    mgr_apply_firewall_for_mode "reality"
    refreshed_subscription_token="$(refresh_subscription_token_on_managed_node_change || true)"
    systemctl restart "$BACKEND_SERVICE"
    harden_runtime_permissions
    mgr_write_managed_subscription_files "$(mgr_get_managed_tls_row)" "$(mgr_get_managed_reality_row)"
    if [ "$reality_network" = "xhttp" ]; then
      log_info "已按官方最小 Reality XHTTP 形态确认 443 入站可用，并已重启后端。SNI: ${current_sni}，节点路径: ${reality_path}"
    else
      log_info "已确认 Reality 443 入站可用，并已重启后端。传输协议: TCP (RAW)，SNI: ${current_sni}"
    fi
    log_info "Reality 公私钥已重新生成；之前分发出去的旧公钥配置现已失效。"
    if [ -n "$refreshed_subscription_token" ]; then
      refreshed_subscription_url="$(build_subscription_url || true)"
      if [ -n "$refreshed_subscription_url" ]; then
        log_info "V2Ray 标准订阅链接已刷新: ${refreshed_subscription_url}"
        log_info "Mihomo 显式订阅链接已刷新: ${refreshed_subscription_url}?format=mihomo"
      else
        log_info "订阅 token 已刷新；待 TLS 证书和接入域名 / IP 就绪后再生成订阅 URL。"
      fi
    fi
  else
    log_info "Reality 节点参数未变化，保留现有订阅链接和密钥。"
  fi
  return 0
}


mgr_disable_managed_inbounds_by_tag_like() {
  local pattern="$1"
  local db_file="${INSTALL_DIR}/data.db"
  local now

  if [ -z "$pattern" ] || [ ! -f "$db_file" ]; then
    return 0
  fi
  if ! mgr_ensure_sqlite3; then
    return 0
  fi

  now="$(date +%s)"
  sqlite3 "$db_file" "UPDATE inbounds SET enable=0, updated_at=${now} WHERE tag LIKE '$(sql_escape "$pattern")' AND enable=1;" >/dev/null 2>&1 || true
}


mgr_ensure_tls_443_direct_inbound() {
  local domain="$1"
  local db_file="${INSTALL_DIR}/data.db"
  local now existing_id managed_id port_owner_id row tag uuid current_path existing_path existing_protocol
  local tls_network net_service released_opposite tls_xhttp_mode tls_xhttp_padding_bytes tls_alpn tls_host
  local refreshed_subscription_token refreshed_subscription_url managed_node_changed
  local current_decryption current_encryption current_transport current_host current_service current_padding current_security current_sni current_tls_min_version current_tls_alpn current_tls_use_file current_tls_cert_file current_tls_key_file current_tls_cert_content current_tls_key_content current_tls_ech_key current_tls_ech_config current_target current_public_key current_private_key current_short_ids current_spider_x current_enable

  if [ -z "$domain" ]; then
    log_warn "未绑定域名，跳过创建 TLS 直连入站。"
    return 1
  fi
  if [ ! -f "/etc/certs/${domain}.crt" ] || [ ! -f "/etc/certs/${domain}.key" ]; then
    log_warn "缺少 TLS 证书文件，无法创建 TLS 直连入站。"
    return 1
  fi
  if [ ! -f "$db_file" ]; then
    log_warn "未找到数据库文件: $db_file"
    return 1
  fi
  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 不可用，跳过创建 TLS 直连入站。"
    return 1
  fi
  mgr_ensure_vlessenc_schema "$db_file"

  now="$(date +%s)"
  managed_node_changed=0
  current_path="$(mgr_get_tls_node_path)"
  tls_network="$(mgr_get_tls_node_network)"
  local tls_decryption tls_encryption
  tls_decryption="$(mgr_get_tls_node_decryption)"
  tls_encryption="$(mgr_get_tls_node_encryption)"
  if [ "$tls_decryption" = "none" ]; then
    tls_encryption="none"
  fi
  net_service=""
  tls_host="$domain"
  if [ "$tls_network" = "xhttp" ]; then
    tls_xhttp_mode="$(mgr_get_tls_node_xhttp_mode)"
    tls_xhttp_padding_bytes="$(mgr_get_tls_node_xhttp_padding_bytes)"
    net_service="$tls_xhttp_mode"
    tls_host=""
  fi
  tls_alpn="$(mgr_default_tls_alpn "$tls_network")"

  managed_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE tag LIKE 'tls-443-direct-auto%' ORDER BY CASE WHEN port=443 THEN 0 ELSE 1 END, enable DESC, id LIMIT 1;")"
  managed_id="$(sqlite_uint_or_empty "$managed_id")"

  if ! released_opposite="$(mgr_release_managed_443_by_tag_like_except "$db_file" "reality-443-auto%" "" "$now")"; then
    log_error "迁移旧 Reality 受管入站端口占位失败。"
    return 1
  fi
  if [ "$released_opposite" = "1" ]; then
    managed_node_changed=1
    log_info "已迁移旧 Reality 受管入站端口占位，释放 443 用于 TLS。"
  fi

  port_owner_id="$(mgr_get_inbound_443_owner_id "$db_file" "$managed_id")"
  if [ -n "$port_owner_id" ]; then
    log_warn "端口 443 已被非当前受管入站占用：$(mgr_get_inbound_summary "$db_file" "$port_owner_id")；请先停用或迁移该入站后再创建 TLS 节点。"
    return 1
  elif [ -n "$managed_id" ]; then
    existing_id="$managed_id"
  else
    existing_id=""
  fi

  if [ -n "$existing_id" ]; then
    row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(uuid,''),COALESCE(net_path,''),COALESCE(protocol,''),COALESCE(decryption,''),COALESCE(encryption,''),COALESCE(transport,''),COALESCE(net_host,''),COALESCE(net_service,''),COALESCE(xhttp_padding_bytes,''),COALESCE(security,''),COALESCE(sni,''),COALESCE(tls_min_version,''),COALESCE(tls_alpn,''),COALESCE(tls_use_file,0),COALESCE(tls_cert_file,''),COALESCE(tls_key_file,''),COALESCE(tls_cert_content,''),COALESCE(tls_key_content,''),COALESCE(tls_ech_key,''),COALESCE(tls_ech_config,''),COALESCE(target,''),COALESCE(public_key,''),COALESCE(private_key,''),COALESCE(short_ids,''),COALESCE(spider_x,''),COALESCE(enable,0) FROM inbounds WHERE id=${existing_id} LIMIT 1;")"
    IFS='|' read -r tag uuid existing_path existing_protocol current_decryption current_encryption current_transport current_host current_service current_padding current_security current_sni current_tls_min_version current_tls_alpn current_tls_use_file current_tls_cert_file current_tls_key_file current_tls_cert_content current_tls_key_content current_tls_ech_key current_tls_ech_config current_target current_public_key current_private_key current_short_ids current_spider_x current_enable <<< "$row"
  else
    tag="tls-443-direct-auto"
    existing_path=""
    existing_protocol="vless"
  fi

  if [ -z "$uuid" ]; then
    uuid="$(mgr_generate_uuid)"
  fi
  if [ -z "$uuid" ]; then
    log_warn "生成 TLS 直连入站 UUID 失败。"
    return 1
  fi
  if [ "$tls_network" != "xhttp" ]; then
    tls_xhttp_padding_bytes=""
  fi
  if [ -z "$current_path" ]; then
    current_path="$existing_path"
  fi
  current_path="$(normalize_node_path "$current_path")"
  if [ "$existing_protocol" != "vmess" ]; then
    existing_protocol="vless"
  fi

  if [ -z "$existing_id" ]; then
    managed_node_changed=1
  elif [ "$current_decryption" != "$tls_decryption" ] || \
       [ "$current_encryption" != "$tls_encryption" ] || \
       [ "$current_transport" != "$tls_network" ] || \
       [ "$existing_path" != "$current_path" ] || \
       [ "$current_host" != "$tls_host" ] || \
       [ "$current_service" != "$net_service" ] || \
       [ "$current_padding" != "$tls_xhttp_padding_bytes" ] || \
       [ "$current_security" != "tls" ] || \
       [ "$current_sni" != "$domain" ] || \
       [ "$current_tls_min_version" != "1.3" ] || \
       [ "$current_tls_alpn" != "$tls_alpn" ] || \
       [ "$current_tls_use_file" != "1" ] || \
       [ "$current_tls_cert_file" != "/etc/certs/${domain}.crt" ] || \
       [ "$current_tls_key_file" != "/etc/certs/${domain}.key" ] || \
       [ -n "$current_tls_cert_content" ] || \
       [ -n "$current_tls_key_content" ] || \
       [ -n "$current_tls_ech_key" ] || \
       [ -n "$current_tls_ech_config" ] || \
       [ -n "$current_target" ] || \
       [ -n "$current_public_key" ] || \
       [ -n "$current_private_key" ] || \
       [ -n "$current_short_ids" ] || \
       [ "$current_spider_x" != "/" ] || \
       [ "$current_enable" != "1" ]; then
    managed_node_changed=1
  fi

  if [ "$managed_node_changed" = "1" ]; then
    if [ -z "$existing_id" ]; then
      if ! sqlite3 "$db_file" "INSERT INTO inbounds (tag, protocol, listen, port, uuid, flow, decryption, encryption, transport, net_path, net_host, net_service, xhttp_padding_bytes, security, sni, tls_min_version, tls_alpn, tls_use_file, tls_cert_file, tls_key_file, tls_cert_content, tls_key_content, tls_ech_key, tls_ech_config, target, public_key, private_key, short_ids, spider_x, up_time, down_time, total_quota, expire_time, enable, created_at, updated_at) VALUES ('$(sql_escape "$tag")','$(sql_escape "$existing_protocol")','',443,'$(sql_escape "$uuid")','','$(sql_escape "$tls_decryption")','$(sql_escape "$tls_encryption")','$(sql_escape "$tls_network")','$(sql_escape "$current_path")','$(sql_escape "$tls_host")','$(sql_escape "$net_service")','$(sql_escape "$tls_xhttp_padding_bytes")','tls','$(sql_escape "$domain")','1.3','$(sql_escape "$tls_alpn")',1,'/etc/certs/$(sql_escape "$domain").crt','/etc/certs/$(sql_escape "$domain").key','','','','','','','','','/',0,0,0,0,1,${now},${now});"; then
        log_error "写入 TLS 入站失败。"
        return 1
      fi
      if [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE tag='$(sql_escape "$tag")' AND updated_at=${now};")" != "1" ]; then
        log_error "TLS 入站写库后校验失败。"
        return 1
      fi
    else
      if ! sqlite3 "$db_file" "UPDATE inbounds SET protocol='$(sql_escape "$existing_protocol")', listen='', port=443, uuid='$(sql_escape "$uuid")', flow='', decryption='$(sql_escape "$tls_decryption")', encryption='$(sql_escape "$tls_encryption")', transport='$(sql_escape "$tls_network")', net_path='$(sql_escape "$current_path")', net_host='$(sql_escape "$tls_host")', net_service='$(sql_escape "$net_service")', xhttp_padding_bytes='$(sql_escape "$tls_xhttp_padding_bytes")', security='tls', sni='$(sql_escape "$domain")', tls_min_version='1.3', tls_alpn='$(sql_escape "$tls_alpn")', tls_use_file=1, tls_cert_file='/etc/certs/$(sql_escape "$domain").crt', tls_key_file='/etc/certs/$(sql_escape "$domain").key', tls_cert_content='', tls_key_content='', tls_ech_key='', tls_ech_config='', target='', public_key='', private_key='', short_ids='', spider_x='/', enable=1, updated_at=${now} WHERE id=${existing_id};"; then
        log_error "更新 TLS 入站失败。"
        return 1
      fi
      if [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE id=${existing_id} AND updated_at=${now};")" != "1" ]; then
        log_error "TLS 入站更新后校验失败。"
        return 1
      fi
    fi
  fi

  mgr_set_current_mode "tls"
  save_cfg "TLS_NODE_PATH" "$current_path"
  save_cfg "TLS_NODE_NETWORK" "$tls_network"
  save_cfg "TLS_NODE_DECRYPTION" "$tls_decryption"
  save_cfg "TLS_NODE_ENCRYPTION" "$tls_encryption"
  if [ "$tls_network" = "xhttp" ]; then
    save_cfg "TLS_NODE_XHTTP_MODE" "$net_service"
    save_cfg "TLS_NODE_XHTTP_PADDING_BYTES" "$tls_xhttp_padding_bytes"
  fi
  if [ "$managed_node_changed" = "1" ]; then
    mgr_apply_firewall_for_mode "tls"
    refreshed_subscription_token="$(refresh_subscription_token_on_managed_node_change || true)"
    systemctl restart "$BACKEND_SERVICE"
    harden_runtime_permissions
    mgr_write_managed_subscription_files "$(mgr_get_managed_tls_row)" "$(mgr_get_managed_reality_row)"
    if [ "$tls_network" = "xhttp" ]; then
      log_info "已确认 Xray 直连 TLS 入站可用，并已重启后端。传输协议: ${tls_network}，模式: ${net_service}，Padding: ${tls_xhttp_padding_bytes}，节点路径: ${current_path}"
    else
      log_info "已确认 Xray 直连 TLS 入站可用，并已重启后端。传输协议: ${tls_network}，节点路径: ${current_path}"
    fi
    if [ -n "$refreshed_subscription_token" ]; then
      refreshed_subscription_url="$(build_subscription_url || true)"
      if [ -n "$refreshed_subscription_url" ]; then
        log_info "V2Ray 标准订阅链接已刷新: ${refreshed_subscription_url}"
        log_info "Mihomo 显式订阅链接已刷新: ${refreshed_subscription_url}?format=mihomo"
      else
        log_info "订阅 token 已刷新；待 TLS 证书和接入域名 / IP 就绪后再生成订阅 URL。"
      fi
    fi
  else
    log_info "TLS 节点参数未变化，保留现有订阅链接。"
  fi
  return 0
}

mgr_issue_ssl_certificate() {
  local domain="$1"
  local email
  local issue_ret=1
  local is_ip_cert=0
  local acme_bin=""

  if [ -z "$domain" ]; then
    return 1
  fi

  if mgr_is_ipv4_literal "$domain"; then
    is_ip_cert=1
  fi

  email="xray$(date +%s)$RANDOM@qq.com"
  mkdir -p /etc/certs
  if ! ensure_socat; then
    return 1
  fi
  firewall_allow_port 80
  firewall_reload
  stop_http_services_for_acme

  SSL_ISSUER_TOOL="acme.sh"
  if ! ensure_modern_acme_sh "$email"; then
    restore_http_services_for_acme
    firewall_remove_port 80
    firewall_reload
    return 1
  fi

  acme_bin="${HOME}/.acme.sh/acme.sh"

  if [ "$is_ip_cert" -eq 1 ]; then
    if "$acme_bin" --issue --server letsencrypt --standalone --listen-v4 -d "$domain" --certificate-profile shortlived --days 3; then
      if "$acme_bin" --install-cert -d "$domain" --key-file "/etc/certs/${domain}.key" --fullchain-file "/etc/certs/${domain}.crt"; then
        issue_ret=0
        save_cfg "SSL_ISSUER_TOOL" "$SSL_ISSUER_TOOL"
        sync_ssl_renewal_timer
        harden_runtime_permissions
        log_info "已通过 acme.sh 安装 IP 证书。"
      else
        log_error "acme.sh 已成功签发 IP 证书，但安装证书文件失败。"
        issue_ret=1
      fi
    else
      log_error "acme.sh IP 证书申请失败。"
      issue_ret=1
    fi
  else
    if "$acme_bin" --issue --server letsencrypt --standalone -d "$domain"; then
      if "$acme_bin" --install-cert -d "$domain" --key-file "/etc/certs/${domain}.key" --fullchain-file "/etc/certs/${domain}.crt"; then
        issue_ret=0
        save_cfg "SSL_ISSUER_TOOL" "$SSL_ISSUER_TOOL"
        sync_ssl_renewal_timer
        harden_runtime_permissions
        log_info "已通过 acme.sh 安装域名 TLS 证书。"
      else
        log_error "acme.sh 已成功签发域名证书，但安装证书文件失败。"
        issue_ret=1
      fi
    else
      log_error "acme.sh 域名证书申请失败。"
      issue_ret=1
    fi
  fi

  restore_http_services_for_acme
  firewall_remove_port 80
  firewall_reload
  return "$issue_ret"
}

mgr_bind_domain() {
  clear
  echo -e "${CYAN}==== 绑定接入域名 / IP 与 TLS 证书 ====${NC}"
  echo ""

  local current_domain domain
  current_domain="$(mgr_get_panel_domain)"
  if [ -n "$current_domain" ]; then
    echo "当前接入域名 / IP: $current_domain"
  fi

  echo -n "请输入接入域名或 IP（例如 example.com / 1.2.3.4）: "
  read -r domain
  domain="$(mgr_normalize_access_host "$domain")"
  if [ -z "$domain" ]; then
    log_error "接入域名或 IP 不能为空。"
    mgr_pause_wait
    return
  fi
  if ! mgr_is_valid_access_host "$domain"; then
    log_error "接入域名或 IP 格式无效，请输入域名、IPv4 或 IPv6 地址。"
    mgr_pause_wait
    return
  fi

  if ! save_cfg "PANEL_DOMAIN" "$domain"; then
    mgr_pause_wait
    return
  fi

  echo ""
  echo "1) 自动申请 TLS 证书（统一使用 acme.sh；IP 证书依赖客户端支持）"
  echo "2) 使用已有证书文件"
  echo "3) 仅保存接入域名 / IP"
  echo ""
  echo -n "请选择: "
  read -r ssl_choice

  case "$ssl_choice" in
    1)
      if mgr_is_ipv4_literal "$domain"; then
        log_info "检测到 IPv4 接入主机，将通过 acme.sh 使用 ACME IP 证书流程申请证书。"
      else
        log_info "将通过 acme.sh 使用 ACME HTTP-01 为域名申请证书。"
      fi
      mgr_issue_ssl_certificate "$domain"
      if [ $? -eq 0 ]; then
        mkdir -p /etc/certs
        save_cfg "SSL_ISSUER_TOOL" "$SSL_ISSUER_TOOL"
        sync_ssl_renewal_timer
        harden_runtime_permissions
        log_info "已通过 ${SSL_ISSUER_TOOL} 安装 TLS 证书。"
        log_info "证书已就绪，可前往 节点管理 继续配置。"
      else
        log_error "TLS 证书申请失败。"
      fi
      ;;
    2)
      echo "请将证书放到: /etc/certs/${domain}.crt"
      echo "请将私钥放到: /etc/certs/${domain}.key"
      echo -n "证书已准备好？(y/n): "
      read -r uploaded
      if [ "$uploaded" = "y" ]; then
        if [ -f "/etc/certs/${domain}.crt" ] && [ -f "/etc/certs/${domain}.key" ]; then
          save_cfg "SSL_ISSUER_TOOL" "manual"
          sync_ssl_renewal_timer
          log_info "已检测到证书文件。"
          log_info "证书已就绪，可前往 节点管理 继续配置。"
        else
          log_error "未找到证书文件。"
        fi
      fi
      ;;
    3)
      save_cfg "SSL_ISSUER_TOOL" "manual"
      sync_ssl_renewal_timer
      log_info "域名已保存。"
      ;;
    *)
      log_warn "已取消。"
      ;;
  esac

  mgr_pause_wait
}

mgr_manage_firewall() {
  clear
  echo -e "${CYAN}==== 防火墙管理 ====${NC}"
  echo ""

  local fw_type current_ssh_port
  current_ssh_port="$(get_configured_ssh_port)"
  if command -v ufw >/dev/null 2>&1; then
    fw_type="ufw"
    echo "已检测到 UFW"
  elif command -v firewall-cmd >/dev/null 2>&1; then
    fw_type="firewalld"
    echo "已检测到 Firewalld"
  else
    log_error "未检测到受支持的防火墙工具。"
    mgr_pause_wait
    return
  fi

  echo ""
  echo "1) 开放端口"
  echo "2) 关闭端口"
  echo "3) 查看已开放端口 / 规则"
  echo "4) 修改 SSH 端口（当前: ${current_ssh_port}）"
  if is_cn_traffic_block_enabled; then
    echo "5) 禁止访问中国大陆站点（当前: 已启用）"
  else
    echo "5) 禁止访问中国大陆站点（当前: 已关闭）"
  fi
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r choice

  local ports_input normalized_ports
  local -a tokens
  local valid_ports=()
  local token

  case "$choice" in
    1)
      echo -n "请输入要开放的端口（逗号分隔，例如 80,443）: "
      read -r ports_input
      normalized_ports="$(echo "$ports_input" | sed 's/[^0-9]/,/g; s/,,*/,/g; s/^,//; s/,$//')"
      IFS=',' read -r -a tokens <<< "$normalized_ports"
      valid_ports=()
      for token in "${tokens[@]}"; do
        if [[ "$token" =~ ^[0-9]+$ ]] && [ "$token" -ge 1 ] && [ "$token" -le 65535 ]; then
          valid_ports+=("$token")
        fi
      done
      if [ "${#valid_ports[@]}" -eq 0 ]; then
        log_error "未提供有效端口。"
        mgr_pause_wait
        return
      fi

      if [ "$fw_type" = "ufw" ]; then
        ufw --force enable >/dev/null 2>&1 || true
        ufw default deny incoming >/dev/null 2>&1 || true
        ufw default allow outgoing >/dev/null 2>&1 || true
      else
        systemctl start firewalld >/dev/null 2>&1 || true
        systemctl enable firewalld >/dev/null 2>&1 || true
      fi

      firewall_apply_ssh_policy
      for token in "${valid_ports[@]}"; do
        firewall_allow_port "$token"
      done
      firewall_reload
      log_info "已开放端口: ${valid_ports[*]}（SSH $(describe_ssh_port_policy)）"
      ;;
    2)
      echo -n "请输入要关闭的端口（逗号分隔，例如 80,443）: "
      read -r ports_input
      normalized_ports="$(echo "$ports_input" | sed 's/[^0-9]/,/g; s/,,*/,/g; s/^,//; s/,$//')"
      IFS=',' read -r -a tokens <<< "$normalized_ports"
      valid_ports=()
      for token in "${tokens[@]}"; do
        if [[ "$token" =~ ^[0-9]+$ ]] && [ "$token" -ge 1 ] && [ "$token" -le 65535 ]; then
          valid_ports+=("$token")
        fi
      done
      if [ "${#valid_ports[@]}" -eq 0 ]; then
        log_error "未提供有效端口。"
        mgr_pause_wait
        return
      fi

      for token in "${valid_ports[@]}"; do
        firewall_remove_port "$token"
      done
      if [ "$fw_type" = "firewalld" ]; then
        systemctl start firewalld >/dev/null 2>&1 || true
        systemctl enable firewalld >/dev/null 2>&1 || true
      fi
      firewall_reload
      log_info "已关闭端口: ${valid_ports[*]}"
      ;;
    3)
      if [ "$fw_type" = "ufw" ]; then
        ufw status verbose
      else
        firewall-cmd --list-all
      fi
      ;;
    4)
      mgr_change_ssh_port
      return
      ;;
    5)
      if is_cn_traffic_block_enabled; then
        save_cfg "BLOCK_CN_TRAFFIC" "0"
        systemctl restart "$BACKEND_SERVICE"
        log_info "已关闭中国大陆站点访问阻断，并已重启后端刷新 Xray 路由。"
      else
        save_cfg "BLOCK_CN_TRAFFIC" "1"
        systemctl restart "$BACKEND_SERVICE"
        log_info "已启用中国大陆站点访问阻断，将通过 geosite:cn 和 geoip:cn 拦截访问。"
      fi
      ;;
    *) ;;
  esac

  mgr_pause_wait
}

mgr_change_ssh_port() {
  clear
  echo -e "${CYAN}==== 修改 SSH 端口 ====${NC}"
  echo ""

  local fw_type current_port target_port confirm
  fw_type="$(detect_firewall_tool)"
  current_port="$(get_configured_ssh_port)"

  if [ "$fw_type" = "none" ]; then
    log_error "未检测到防火墙工具，无法安全切换 SSH 端口。"
    mgr_pause_wait
    return
  fi

  echo "当前 SSH 端口: ${current_port}"
  echo "保留规则: 先开放新端口，重载 SSH 成功后再关闭旧端口。"
  echo "不可用端口: 80、443"
  echo ""
  echo -n "请输入新的 SSH 端口: "
  read -r target_port
  target_port="$(printf "%s" "$target_port" | tr -d '[:space:]')"

  if [ -z "$target_port" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi
  if ! is_valid_port_number "$target_port"; then
    log_error "端口必须是 1-65535 之间的数字。"
    mgr_pause_wait
    return
  fi
  if is_reserved_ssh_port "$target_port"; then
    log_error "端口 ${target_port} 与当前服务冲突，请换一个。"
    mgr_pause_wait
    return
  fi
  if [ "$target_port" = "$current_port" ]; then
    log_warn "目标端口与当前一致，无需修改。"
    mgr_pause_wait
    return
  fi

  echo ""
  log_warn "继续后会把 SSH 从 ${current_port} 切换到 ${target_port}。"
  log_warn "切换成功后将关闭旧 SSH 端口 ${current_port}。"
  echo -n "请输入 YES 确认: "
  read -r confirm
  if [ "$confirm" != "YES" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi

  firewall_allow_port "$target_port"
  firewall_reload

  if ! apply_ssh_runtime_config "$target_port"; then
    firewall_remove_port "$target_port"
    firewall_reload
    mgr_pause_wait
    return
  fi

  save_cfg "SSH_PORT" "$target_port"
  firewall_apply_ssh_policy
  if [ "$current_port" != "$target_port" ] && [ "$current_port" != "22" ]; then
    firewall_remove_port "$current_port"
  fi
  firewall_reload
  setup_fail2ban

  log_info "SSH 端口已切换到 ${target_port}。后续请使用: ssh -p ${target_port} <user>@<host>"
  mgr_pause_wait
}

mgr_ensure_domain_and_cert() {
  local mode_label="$1"
  local domain

  domain="$(mgr_get_panel_domain)"
  if [ -z "$domain" ]; then
    log_warn "${mode_label} 节点需要先绑定接入域名或 IP，现在进入域名与证书向导。"
    mgr_bind_domain
    domain="$(mgr_get_panel_domain)"
  fi
  if [ -z "$domain" ]; then
    log_error "未绑定接入域名或 IP，已取消 ${mode_label} 节点创建。"
    return 1
  fi

  if [ ! -f "/etc/certs/${domain}.crt" ] || [ ! -f "/etc/certs/${domain}.key" ]; then
    log_warn "${mode_label} 节点需要可用 TLS 证书，现在进入域名与证书向导。"
    mgr_bind_domain
    domain="$(mgr_get_panel_domain)"
    if [ ! -f "/etc/certs/${domain}.crt" ] || [ ! -f "/etc/certs/${domain}.key" ]; then
      log_error "未找到 ${domain} 的证书文件，已取消 ${mode_label} 节点创建。"
      return 1
    fi
  fi
}

mgr_ensure_access_host() {
  local mode_label="$1"
  local domain

  domain="$(mgr_get_panel_domain)"
  if [ -z "$domain" ]; then
    log_warn "${mode_label} 节点建议先设置接入域名或 IP，现在进入域名与证书向导。"
    mgr_bind_domain
    domain="$(mgr_get_panel_domain)"
  fi
  if [ -z "$domain" ]; then
    log_error "未设置接入域名或 IP，已取消 ${mode_label} 节点创建。"
    return 1
  fi
}

mgr_encode_link_path() {
  local value="$1"
  value="${value//\//%2F}"
  printf "%s" "$value"
}

mgr_encode_query_value() {
  local raw="$1"
  local out="" i ch

  for ((i=0; i<${#raw}; i++)); do
    ch="${raw:i:1}"
    case "$ch" in
      [a-zA-Z0-9.~_-])
        out="${out}${ch}"
        ;;
      *)
        printf -v out '%s%%%02X' "$out" "'$ch"
        ;;
    esac
  done

  printf "%s" "$out"
}

mgr_query_pair() {
  local key="$1"
  local value="$2"
  printf "%s=%s" "$key" "$(mgr_encode_query_value "$value")"
}

mgr_yaml_quote() {
  printf "'%s'" "$(printf "%s" "$1" | sed "s/'/''/g")"
}

mgr_trim_value() {
  printf "%s" "$1" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'
}

mgr_yaml_number_or_quote() {
  local value
  value="$(mgr_trim_value "$1")"
  if [[ "$value" =~ ^[0-9]+$ ]]; then
    printf "%s" "$value"
    return 0
  fi
  mgr_yaml_quote "$value"
}

mgr_optional_bool_value() {
  case "$(mgr_trim_value "$1" | tr '[:upper:]' '[:lower:]')" in
    1|true|yes|on)
      printf "true"
      ;;
    0|false|no|off)
      printf "false"
      ;;
    *)
      printf ""
      ;;
  esac
}

mgr_json_quote() {
  local value="$1"
  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  printf "\"%s\"" "$value"
}

mgr_json_number_or_string() {
  local value
  value="$(mgr_trim_value "$1")"
  if [[ "$value" =~ ^[0-9]+$ ]]; then
    printf "%s" "$value"
    return 0
  fi
  mgr_json_quote "$value"
}

mgr_json_object_or_empty() {
  local value
  value="$(mgr_trim_value "$1")"
  case "$value" in
    \{*\})
      printf "%s" "$value"
      ;;
    *)
      printf ""
      ;;
  esac
}

mgr_json_string_map_or_empty() {
  local raw normalized parsed
  raw="$(mgr_json_object_or_empty "$1")"
  if [ -z "$raw" ]; then
    return 1
  fi
  if ! command -v sqlite3 >/dev/null 2>&1; then
    printf "%s" "$raw"
    return 0
  fi

  parsed="$(sqlite3 -noheader ':memory:' "WITH entries AS (SELECT key, TRIM(CAST(value AS TEXT)) AS value FROM json_each('$(sql_escape "$raw")') ORDER BY key) SELECT COALESCE((SELECT '{' || group_concat(json_quote(key) || ':' || json_quote(value), ',') || '}' FROM entries), '{}');" 2>/dev/null || true)"
  if [ -n "$parsed" ]; then
    printf "%s" "$parsed"
    return 0
  fi

  printf "%s" "$raw"
  return 0
}

mgr_emit_mihomo_json_headers() {
  local indent="$1"
  local raw normalized emitted=0 key value

  if ! command -v sqlite3 >/dev/null 2>&1; then
    return 1
  fi
  normalized="$(mgr_json_string_map_or_empty "$2")"
  if [ -z "$normalized" ] || [ "$normalized" = "{}" ]; then
    return 1
  fi

  while IFS='|' read -r key value; do
    [ -n "$key" ] || continue
    if [ "$emitted" -eq 0 ]; then
      echo "${indent}headers:"
      emitted=1
    fi
    echo "${indent}  ${key}: $(mgr_yaml_quote "$value")"
  done < <(sqlite3 -separator '|' ':memory:' "SELECT key, TRIM(CAST(value AS TEXT)) FROM json_each('$(sql_escape "$normalized")') ORDER BY key;" 2>/dev/null || true)

  [ "$emitted" -eq 1 ]
}

mgr_build_xhttp_xmux_json() {
  local include_defaults="$1"
  local max_concurrency max_connections c_max_reuse_times h_max_request_times h_max_reusable_secs
  local parts=() joined

  max_concurrency="$(mgr_trim_value "$2")"
  max_connections="$(mgr_trim_value "$3")"
  c_max_reuse_times="$(mgr_trim_value "$4")"
  h_max_request_times="$(mgr_trim_value "$5")"
  h_max_reusable_secs="$(mgr_trim_value "$6")"

  if [ "$include_defaults" = "1" ]; then
    if [ -z "$max_concurrency" ] && [ -z "$max_connections" ]; then
      max_concurrency="$(mgr_default_xhttp_xmux_max_concurrency)"
    fi
    if [ -z "$c_max_reuse_times" ]; then
      c_max_reuse_times="$(mgr_default_xhttp_cmaxreusetimes)"
    fi
    if [ -z "$h_max_request_times" ]; then
      h_max_request_times="$(mgr_default_xhttp_xmux_hmaxrequesttimes)"
    fi
    if [ -z "$h_max_reusable_secs" ]; then
      h_max_reusable_secs="$(mgr_default_xhttp_xmux_hmaxreusablesecs)"
    fi
  fi

  if [ -n "$max_concurrency" ]; then
    parts+=("\"maxConcurrency\":$(mgr_json_quote "$max_concurrency")")
  fi
  if [ -n "$max_connections" ]; then
    parts+=("\"maxConnections\":$(mgr_json_number_or_string "$max_connections")")
  fi
  if [ -n "$c_max_reuse_times" ]; then
    parts+=("\"cMaxReuseTimes\":$(mgr_json_number_or_string "$c_max_reuse_times")")
  fi
  if [ -n "$h_max_request_times" ]; then
    parts+=("\"hMaxRequestTimes\":$(mgr_json_quote "$h_max_request_times")")
  fi
  if [ -n "$h_max_reusable_secs" ]; then
    parts+=("\"hMaxReusableSecs\":$(mgr_json_quote "$h_max_reusable_secs")")
  fi
  if [ "${#parts[@]}" -eq 0 ]; then
    return 1
  fi

  parts+=("\"hKeepAlivePeriod\":0")
  joined="$(IFS=,; printf "%s" "${parts[*]}")"
  printf "{%s}" "$joined"
}

mgr_build_xhttp_download_json() {
  local path host headers_json no_grpc_header padding_bytes sc_max_each_post_bytes
  local reuse_max_concurrency reuse_max_connections c_max_reuse_times h_max_request_times h_max_reusable_secs
  local normalized_headers no_grpc_json xmux_json
  local parts=() joined

  path="$(mgr_normalize_location_path "$1")"
  host="$(mgr_trim_value "$2")"
  headers_json="$(mgr_trim_value "$3")"
  no_grpc_header="$(mgr_trim_value "$4")"
  padding_bytes="$(mgr_normalize_xhttp_padding_bytes "$5")"
  sc_max_each_post_bytes="$(mgr_trim_value "$6")"
  reuse_max_concurrency="$(mgr_trim_value "$7")"
  reuse_max_connections="$(mgr_trim_value "$8")"
  c_max_reuse_times="$(mgr_trim_value "$9")"
  h_max_request_times="$(mgr_trim_value "${10}")"
  h_max_reusable_secs="$(mgr_trim_value "${11}")"

  if [ -n "$path" ]; then
    parts+=("\"path\":$(mgr_json_quote "$path")")
  fi
  if [ -n "$host" ]; then
    parts+=("\"host\":$(mgr_json_quote "$host")")
  fi
  normalized_headers="$(mgr_json_string_map_or_empty "$headers_json" || true)"
  if [ -n "$normalized_headers" ]; then
    parts+=("\"headers\":${normalized_headers}")
  fi
  no_grpc_json="$(mgr_optional_bool_value "$no_grpc_header")"
  if [ -n "$no_grpc_json" ]; then
    parts+=("\"noGRPCHeader\":${no_grpc_json}")
  fi
  if [ -n "$padding_bytes" ]; then
    parts+=("\"xPaddingBytes\":$(mgr_json_quote "$padding_bytes")")
  fi
  if [ -n "$sc_max_each_post_bytes" ]; then
    parts+=("\"scMaxEachPostBytes\":$(mgr_json_number_or_string "$sc_max_each_post_bytes")")
  fi
  if [ -z "$reuse_max_concurrency" ] && [ -z "$reuse_max_connections" ]; then
    reuse_max_concurrency="$(mgr_default_xhttp_xmux_max_concurrency)"
  fi
  xmux_json="$(mgr_build_xhttp_xmux_json 0 "$reuse_max_concurrency" "$reuse_max_connections" "$c_max_reuse_times" "$h_max_request_times" "$h_max_reusable_secs" || true)"
  if [ -n "$xmux_json" ]; then
    parts+=("\"xmux\":${xmux_json}")
  fi
  if [ "${#parts[@]}" -eq 0 ]; then
    return 1
  fi

  joined="$(IFS=,; printf "%s" "${parts[*]}")"
  printf "{%s}" "$joined"
}

mgr_emit_mihomo_alpn() {
  local indent="$1"
  local raw="$2"
  local found=0 value
  IFS=',' read -r -a _mihomo_alpn_parts <<< "$raw"
  for value in "${_mihomo_alpn_parts[@]}"; do
    value="$(mgr_trim_value "$value" | tr '[:upper:]' '[:lower:]')"
    case "$value" in
      h3|h2|http/1.1)
        if [ "$found" -eq 0 ]; then
          echo "${indent}alpn:"
          found=1
        fi
        echo "${indent}  - $(mgr_yaml_quote "$value")"
        ;;
    esac
  done
  return 0
}

mgr_emit_mihomo_xhttp_reuse_settings() {
  local indent="$1"
  local include_defaults="$2"
  local max_concurrency max_connections c_max_reuse_times h_max_request_times h_max_reusable_secs

  max_concurrency="$(mgr_trim_value "$3")"
  max_connections="$(mgr_trim_value "$4")"
  c_max_reuse_times="$(mgr_trim_value "$5")"
  h_max_request_times="$(mgr_trim_value "$6")"
  h_max_reusable_secs="$(mgr_trim_value "$7")"

  if [ "$include_defaults" = "1" ]; then
    if [ -z "$max_concurrency" ] && [ -z "$max_connections" ]; then
      max_concurrency="$(mgr_default_xhttp_xmux_max_concurrency)"
    fi
    if [ -z "$c_max_reuse_times" ]; then
      c_max_reuse_times="$(mgr_default_xhttp_cmaxreusetimes)"
    fi
    if [ -z "$h_max_request_times" ]; then
      h_max_request_times="$(mgr_default_xhttp_xmux_hmaxrequesttimes)"
    fi
    if [ -z "$h_max_reusable_secs" ]; then
      h_max_reusable_secs="$(mgr_default_xhttp_xmux_hmaxreusablesecs)"
    fi
  fi

  if [ -z "$max_concurrency" ] && [ -z "$max_connections" ] && [ -z "$c_max_reuse_times" ] && [ -z "$h_max_request_times" ] && [ -z "$h_max_reusable_secs" ]; then
    return 1
  fi

  echo "${indent}reuse-settings:"
  if [ -n "$max_concurrency" ]; then
    echo "${indent}  max-concurrency: $(mgr_yaml_quote "$max_concurrency")"
  fi
  if [ -n "$max_connections" ]; then
    echo "${indent}  max-connections: $(mgr_yaml_number_or_quote "$max_connections")"
  fi
  if [ -n "$c_max_reuse_times" ]; then
    echo "${indent}  c-max-reuse-times: $(mgr_yaml_number_or_quote "$c_max_reuse_times")"
  fi
  if [ -n "$h_max_request_times" ]; then
    echo "${indent}  h-max-request-times: $(mgr_yaml_quote "$h_max_request_times")"
  fi
  if [ -n "$h_max_reusable_secs" ]; then
    echo "${indent}  h-max-reusable-secs: $(mgr_yaml_quote "$h_max_reusable_secs")"
  fi
  return 0
}

mgr_emit_mihomo_xhttp_download_settings() {
  local indent="$1"
  local path host headers_json no_grpc_header padding_bytes sc_max_each_post_bytes
  local reuse_max_concurrency reuse_max_connections c_max_reuse_times h_max_request_times h_max_reusable_secs
  local no_grpc_yaml

  path="$(mgr_normalize_location_path "$2")"
  host="$(mgr_trim_value "$3")"
  headers_json="$(mgr_trim_value "$4")"
  no_grpc_header="$(mgr_trim_value "$5")"
  padding_bytes="$(mgr_normalize_xhttp_padding_bytes "$6")"
  sc_max_each_post_bytes="$(mgr_trim_value "$7")"
  reuse_max_concurrency="$(mgr_trim_value "$8")"
  reuse_max_connections="$(mgr_trim_value "$9")"
  c_max_reuse_times="$(mgr_trim_value "${10}")"
  h_max_request_times="$(mgr_trim_value "${11}")"
  h_max_reusable_secs="$(mgr_trim_value "${12}")"

  if [ -z "$path" ] && [ -z "$host" ] && [ -z "$headers_json" ] && [ -z "$no_grpc_header" ] && [ -z "$padding_bytes" ] && [ -z "$sc_max_each_post_bytes" ] && [ -z "$reuse_max_concurrency" ] && [ -z "$reuse_max_connections" ] && [ -z "$c_max_reuse_times" ] && [ -z "$h_max_request_times" ] && [ -z "$h_max_reusable_secs" ]; then
    return 1
  fi

  echo "${indent}download-settings:"
  if [ -n "$path" ]; then
    echo "${indent}  path: $(mgr_yaml_quote "$path")"
  fi
  if [ -n "$host" ]; then
    echo "${indent}  host: $(mgr_yaml_quote "$host")"
  fi
  mgr_emit_mihomo_json_headers "${indent}  " "$headers_json" || true
  no_grpc_yaml="$(mgr_optional_bool_value "$no_grpc_header")"
  if [ -n "$no_grpc_yaml" ]; then
    echo "${indent}  no-grpc-header: ${no_grpc_yaml}"
  fi
  if [ -n "$padding_bytes" ]; then
    echo "${indent}  x-padding-bytes: $(mgr_yaml_quote "$padding_bytes")"
  fi
  if [ -n "$sc_max_each_post_bytes" ]; then
    echo "${indent}  sc-max-each-post-bytes: $(mgr_yaml_number_or_quote "$sc_max_each_post_bytes")"
  fi
  mgr_emit_mihomo_xhttp_reuse_settings "${indent}  " "0" "$reuse_max_concurrency" "$reuse_max_connections" "$c_max_reuse_times" "$h_max_request_times" "$h_max_reusable_secs" || true
  return 0
}

mgr_base64_no_wrap() {
  if command -v base64 >/dev/null 2>&1; then
    base64 | tr -d '\r\n'
    return
  fi
  if command -v openssl >/dev/null 2>&1; then
    openssl base64 -A
    return
  fi
  return 1
}

mgr_subscription_dir() {
  echo "${INSTALL_DIR}/subscriptions"
}

mgr_build_xhttp_extra_query() {
  local padding_bytes host headers_json no_grpc_header sc_max_each_post_bytes
  local reuse_max_concurrency reuse_max_connections c_max_reuse_times h_max_request_times h_max_reusable_secs
  local download_path download_host download_headers_json download_no_grpc_header download_padding_bytes download_sc_max_each_post_bytes
  local download_reuse_max_concurrency download_reuse_max_connections download_c_max_reuse_times download_h_max_request_times download_h_max_reusable_secs
  local normalized normalized_headers no_grpc_json xmux_json download_json
  local parts=() extra_json joined

  padding_bytes="$1"
  host="$(mgr_trim_value "$2")"
  headers_json="$(mgr_trim_value "$3")"
  no_grpc_header="$(mgr_trim_value "$4")"
  sc_max_each_post_bytes="$(mgr_trim_value "$5")"
  reuse_max_concurrency="$(mgr_trim_value "$6")"
  reuse_max_connections="$(mgr_trim_value "$7")"
  c_max_reuse_times="$(mgr_trim_value "$8")"
  h_max_request_times="$(mgr_trim_value "$9")"
  h_max_reusable_secs="$(mgr_trim_value "${10}")"
  download_path="$(mgr_trim_value "${11}")"
  download_host="$(mgr_trim_value "${12}")"
  download_headers_json="$(mgr_trim_value "${13}")"
  download_no_grpc_header="$(mgr_trim_value "${14}")"
  download_padding_bytes="${15}"
  download_sc_max_each_post_bytes="$(mgr_trim_value "${16}")"
  download_reuse_max_concurrency="$(mgr_trim_value "${17}")"
  download_reuse_max_connections="$(mgr_trim_value "${18}")"
  download_c_max_reuse_times="$(mgr_trim_value "${19}")"
  download_h_max_request_times="$(mgr_trim_value "${20}")"
  download_h_max_reusable_secs="$(mgr_trim_value "${21}")"

  normalized="$(mgr_normalize_xhttp_padding_bytes "$padding_bytes")"
  if [ -n "$normalized" ]; then
    parts+=("\"xPaddingBytes\":$(mgr_json_quote "$normalized")")
  fi
  if [ -n "$host" ]; then
    parts+=("\"host\":$(mgr_json_quote "$host")")
  fi
  normalized_headers="$(mgr_json_string_map_or_empty "$headers_json" || true)"
  if [ -n "$normalized_headers" ]; then
    parts+=("\"headers\":${normalized_headers}")
  fi
  no_grpc_json="$(mgr_optional_bool_value "$no_grpc_header")"
  if [ -n "$no_grpc_json" ]; then
    parts+=("\"noGRPCHeader\":${no_grpc_json}")
  fi
  if [ -n "$sc_max_each_post_bytes" ]; then
    parts+=("\"scMaxEachPostBytes\":$(mgr_json_number_or_string "$sc_max_each_post_bytes")")
  fi
  xmux_json="$(mgr_build_xhttp_xmux_json 1 "$reuse_max_concurrency" "$reuse_max_connections" "$c_max_reuse_times" "$h_max_request_times" "$h_max_reusable_secs" || true)"
  if [ -n "$xmux_json" ]; then
    parts+=("\"xmux\":${xmux_json}")
  fi
  download_json="$(mgr_build_xhttp_download_json "$download_path" "$download_host" "$download_headers_json" "$download_no_grpc_header" "$download_padding_bytes" "$download_sc_max_each_post_bytes" "$download_reuse_max_concurrency" "$download_reuse_max_connections" "$download_c_max_reuse_times" "$download_h_max_request_times" "$download_h_max_reusable_secs" || true)"
  if [ -n "$download_json" ]; then
    parts+=("\"downloadSettings\":${download_json}")
  fi
  if [ "${#parts[@]}" -eq 0 ]; then
    return 0
  fi

  joined="$(IFS=,; printf "%s" "${parts[*]}")"
  extra_json="{${joined}}"
  printf "&extra=%s" "$(mgr_encode_query_value "$extra_json")"
}

mgr_get_managed_tls_row() {
  local db_file="${INSTALL_DIR}/data.db"
  if [ ! -f "$db_file" ]; then
    return 0
  fi
  mgr_ensure_vlessenc_schema "$db_file"

  sqlite3 -separator '|' "$db_file" "SELECT id,COALESCE(tag,''),COALESCE(protocol,''),COALESCE(uuid,''),COALESCE(transport,''),COALESCE(net_path,''),COALESCE(net_host,''),COALESCE(net_service,''),COALESCE(xhttp_padding_bytes,''),COALESCE(xhttp_headers_json,''),COALESCE(xhttp_no_grpc_header,''),COALESCE(xhttp_sc_max_each_post_bytes,''),COALESCE(xhttp_reuse_max_concurrency,''),COALESCE(xhttp_reuse_max_connections,''),COALESCE(xhttp_c_max_reuse_times,''),COALESCE(xhttp_h_max_request_times,''),COALESCE(xhttp_h_max_reusable_secs,''),COALESCE(xhttp_download_path,''),COALESCE(xhttp_download_host,''),COALESCE(xhttp_download_headers_json,''),COALESCE(xhttp_download_no_grpc_header,''),COALESCE(xhttp_download_padding_bytes,''),COALESCE(xhttp_download_sc_max_each_post_bytes,''),COALESCE(xhttp_download_reuse_max_concurrency,''),COALESCE(xhttp_download_reuse_max_connections,''),COALESCE(xhttp_download_c_max_reuse_times,''),COALESCE(xhttp_download_h_max_request_times,''),COALESCE(xhttp_download_h_max_reusable_secs,''),COALESCE(tls_alpn,''),COALESCE(decryption,''),COALESCE(encryption,''),COALESCE(enable,0) FROM inbounds WHERE tag LIKE 'tls-443-direct-auto%' AND enable=1 AND port=443 ORDER BY id DESC LIMIT 1;" 2>/dev/null || true
}

mgr_get_managed_reality_row() {
  local db_file="${INSTALL_DIR}/data.db"
  if [ ! -f "$db_file" ]; then
    return 0
  fi
  mgr_ensure_vlessenc_schema "$db_file"

  sqlite3 -separator '|' "$db_file" "SELECT id,COALESCE(tag,''),COALESCE(protocol,''),COALESCE(uuid,''),COALESCE(flow,''),COALESCE(transport,''),COALESCE(net_path,''),COALESCE(net_host,''),COALESCE(net_service,''),COALESCE(xhttp_padding_bytes,''),COALESCE(xhttp_headers_json,''),COALESCE(xhttp_no_grpc_header,''),COALESCE(xhttp_sc_max_each_post_bytes,''),COALESCE(xhttp_reuse_max_concurrency,''),COALESCE(xhttp_reuse_max_connections,''),COALESCE(xhttp_c_max_reuse_times,''),COALESCE(xhttp_h_max_request_times,''),COALESCE(xhttp_h_max_reusable_secs,''),COALESCE(xhttp_download_path,''),COALESCE(xhttp_download_host,''),COALESCE(xhttp_download_headers_json,''),COALESCE(xhttp_download_no_grpc_header,''),COALESCE(xhttp_download_padding_bytes,''),COALESCE(xhttp_download_sc_max_each_post_bytes,''),COALESCE(xhttp_download_reuse_max_concurrency,''),COALESCE(xhttp_download_reuse_max_connections,''),COALESCE(xhttp_download_c_max_reuse_times,''),COALESCE(xhttp_download_h_max_request_times,''),COALESCE(xhttp_download_h_max_reusable_secs,''),COALESCE(tls_alpn,''),COALESCE(sni,''),COALESCE(public_key,''),COALESCE(short_ids,''),COALESCE(decryption,''),COALESCE(encryption,''),COALESCE(enable,0) FROM inbounds WHERE tag LIKE 'reality-443-auto%' AND enable=1 AND port=443 ORDER BY id DESC LIMIT 1;" 2>/dev/null || true
}

mgr_build_managed_tls_vless_uri() {
  local row="$1"
  local public_ip domain id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn decryption encryption enabled
  local server_name host uri_host query label extra_query cf_hosts

  [ -n "$row" ] || return 1
  IFS='|' read -r id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn decryption encryption enabled <<< "$row"
  [ "${enabled}" = "1" ] || return 1

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  server_name="$(mgr_pick_access_host "$domain" "${net_host:-$public_ip}" || true)"
  [ -n "$server_name" ] && [ -n "$uuid" ] || return 1

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"
  encryption="$(mgr_normalize_vless_crypto_value "$encryption")"
  if [ "$decryption" = "none" ]; then
    encryption="none"
  fi
  cf_hosts="$(mgr_get_cf_preferred_domains)"
  if [ -z "$cf_hosts" ]; then
    cf_hosts="$server_name"
  fi

  while IFS= read -r host; do
    [ -n "$host" ] || continue
    label="managed-tls"
    if [ "$host" != "$server_name" ]; then
      label="managed-tls-${host}"
    fi
    query="$(mgr_query_pair "encryption" "$encryption")&$(mgr_query_pair "security" "tls")&$(mgr_query_pair "sni" "$server_name")&$(mgr_query_pair "type" "$transport")"

    case "$transport" in
      ws|httpupgrade)
        query="${query}&$(mgr_query_pair "host" "$server_name")&$(mgr_query_pair "path" "${net_path:-/}")"
        ;;
      xhttp)
        if [ -z "$xhttp_padding_bytes" ]; then
          xhttp_padding_bytes="$(mgr_default_xhttp_padding_bytes)"
        fi
        extra_query="$(mgr_build_xhttp_extra_query "$xhttp_padding_bytes" "${net_host:-$server_name}" "$xhttp_headers_json" "$xhttp_no_grpc_header" "$xhttp_sc_max_each_post_bytes" "$xhttp_reuse_max_concurrency" "$xhttp_reuse_max_connections" "$xhttp_c_max_reuse_times" "$xhttp_h_max_request_times" "$xhttp_h_max_reusable_secs" "$xhttp_download_path" "$xhttp_download_host" "$xhttp_download_headers_json" "$xhttp_download_no_grpc_header" "$xhttp_download_padding_bytes" "$xhttp_download_sc_max_each_post_bytes" "$xhttp_download_reuse_max_concurrency" "$xhttp_download_reuse_max_connections" "$xhttp_download_c_max_reuse_times" "$xhttp_download_h_max_request_times" "$xhttp_download_h_max_reusable_secs")"
        query="${query}&$(mgr_query_pair "path" "${net_path:-/}")&$(mgr_query_pair "mode" "${net_service:-auto}")${extra_query}"
        ;;
      *)
        query="${query}&$(mgr_query_pair "host" "$server_name")"
        ;;
    esac

    uri_host="$(mgr_format_uri_host "$host")" || continue
    echo "vless://${uuid}@${uri_host}:443?${query}#${label}"
  done <<< "$cf_hosts"
}

mgr_build_managed_reality_vless_uri() {
  local row="$1"
  local public_ip domain id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn sni public_key short_ids decryption encryption enabled
  local host uri_host query label short_id extra_query

  [ -n "$row" ] || return 1
  IFS='|' read -r id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn sni public_key short_ids decryption encryption enabled <<< "$row"
  [ "${enabled}" = "1" ] || return 1

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  host="$(mgr_pick_access_host "$domain" "$public_ip" || true)"
  short_id="$(mgr_primary_reality_short_id "$short_ids")"
  [ -n "$host" ] && [ -n "$uuid" ] && [ -n "$public_key" ] && [ -n "$short_id" ] || return 1

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"
  encryption="$(mgr_normalize_vless_crypto_value "$encryption")"
  if [ "$decryption" = "none" ]; then
    encryption="none"
  fi

  label="managed-reality"
  query="$(mgr_query_pair "encryption" "$encryption")&$(mgr_query_pair "security" "reality")&$(mgr_query_pair "sni" "$sni")&$(mgr_query_pair "fp" "chrome")&$(mgr_query_pair "pbk" "$public_key")&$(mgr_query_pair "sid" "$short_id")&$(mgr_query_pair "spx" "/")&$(mgr_query_pair "type" "$transport")"

  if [ "$transport" = "xhttp" ]; then
    if [ -z "$xhttp_padding_bytes" ]; then
      xhttp_padding_bytes="$(mgr_default_xhttp_padding_bytes)"
    fi
    extra_query="$(mgr_build_xhttp_extra_query "$xhttp_padding_bytes" "$net_host" "$xhttp_headers_json" "$xhttp_no_grpc_header" "$xhttp_sc_max_each_post_bytes" "$xhttp_reuse_max_concurrency" "$xhttp_reuse_max_connections" "$xhttp_c_max_reuse_times" "$xhttp_h_max_request_times" "$xhttp_h_max_reusable_secs" "$xhttp_download_path" "$xhttp_download_host" "$xhttp_download_headers_json" "$xhttp_download_no_grpc_header" "$xhttp_download_padding_bytes" "$xhttp_download_sc_max_each_post_bytes" "$xhttp_download_reuse_max_concurrency" "$xhttp_download_reuse_max_connections" "$xhttp_download_c_max_reuse_times" "$xhttp_download_h_max_request_times" "$xhttp_download_h_max_reusable_secs")"
    query="${query}&$(mgr_query_pair "path" "${net_path:-/}")&$(mgr_query_pair "mode" "${net_service:-auto}")${extra_query}"
  else
    query="${query}&$(mgr_query_pair "flow" "${flow:-xtls-rprx-vision}")"
  fi

  uri_host="$(mgr_format_uri_host "$host")" || return 1
  echo "vless://${uuid}@${uri_host}:443?${query}#${label}"
}

mgr_emit_mihomo_tls_proxy() {
  local row="$1"
  local public_ip domain id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn decryption encryption enabled
  local server_name cf_hosts address label xhttp_host

  [ -n "$row" ] || return 1
  IFS='|' read -r id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn decryption encryption enabled <<< "$row"
  [ "${enabled}" = "1" ] || return 1

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  server_name="$(mgr_pick_access_host "$domain" "${net_host:-$public_ip}" || true)"
  [ -n "$server_name" ] && [ -n "$uuid" ] || return 1
  case "$transport" in
    ws|httpupgrade|tcp|xhttp) ;;
    *) return 1 ;;
  esac

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"
  encryption="$(mgr_normalize_vless_crypto_value "$encryption")"
  if [ "$decryption" = "none" ]; then
    encryption="none"
  fi
  if [ -z "$xhttp_padding_bytes" ]; then
    xhttp_padding_bytes="$(mgr_default_xhttp_padding_bytes)"
  fi

  cf_hosts="$(mgr_get_cf_preferred_domains)"
  if [ -z "$cf_hosts" ]; then
    cf_hosts="$server_name"
  fi

  while IFS= read -r address; do
    [ -n "$address" ] || continue
    label="managed-tls"
    if [ "$address" != "$server_name" ]; then
      label="managed-tls-${address}"
    fi
    xhttp_host="${net_host:-$server_name}"

    echo "  - name: $(mgr_yaml_quote "$label")"
    echo "    type: vless"
    echo "    server: $(mgr_yaml_quote "$address")"
    echo "    port: 443"
    echo "    udp: true"
    echo "    packet-encoding: xudp"
    echo "    uuid: $(mgr_yaml_quote "$uuid")"
    echo "    tls: true"
    echo "    servername: $(mgr_yaml_quote "$server_name")"
    if [ "$encryption" != "none" ]; then
      echo "    encryption: $(mgr_yaml_quote "$encryption")"
    fi

    case "$transport" in
      ws)
        echo "    network: ws"
        echo "    ws-opts:"
        echo "      path: $(mgr_yaml_quote "${net_path:-/}")"
        echo "      headers:"
        echo "        Host: $(mgr_yaml_quote "$server_name")"
        ;;
      httpupgrade)
        echo "    network: ws"
        echo "    ws-opts:"
        echo "      path: $(mgr_yaml_quote "${net_path:-/}")"
        echo "      headers:"
        echo "        Host: $(mgr_yaml_quote "$server_name")"
        echo "      v2ray-http-upgrade: true"
        echo "      v2ray-http-upgrade-fast-open: false"
        ;;
      xhttp)
        echo "    network: xhttp"
        mgr_emit_mihomo_alpn "    " "$tls_alpn"
        echo "    xhttp-opts:"
        echo "      path: $(mgr_yaml_quote "${net_path:-/}")"
        echo "      host: $(mgr_yaml_quote "$xhttp_host")"
        mgr_emit_mihomo_json_headers "      " "$xhttp_headers_json" || true
        echo "      mode: $(mgr_yaml_quote "${net_service:-auto}")"
        echo "      x-padding-bytes: $(mgr_yaml_quote "$xhttp_padding_bytes")"
        if [ -n "$(mgr_optional_bool_value "$xhttp_no_grpc_header")" ]; then
          echo "      no-grpc-header: $(mgr_optional_bool_value "$xhttp_no_grpc_header")"
        fi
        if [ -n "$(mgr_trim_value "$xhttp_sc_max_each_post_bytes")" ]; then
          echo "      sc-max-each-post-bytes: $(mgr_yaml_number_or_quote "$xhttp_sc_max_each_post_bytes")"
        fi
        mgr_emit_mihomo_xhttp_reuse_settings "      " "1" "$xhttp_reuse_max_concurrency" "$xhttp_reuse_max_connections" "$xhttp_c_max_reuse_times" "$xhttp_h_max_request_times" "$xhttp_h_max_reusable_secs" || true
        mgr_emit_mihomo_xhttp_download_settings "      " "$xhttp_download_path" "$xhttp_download_host" "$xhttp_download_headers_json" "$xhttp_download_no_grpc_header" "$xhttp_download_padding_bytes" "$xhttp_download_sc_max_each_post_bytes" "$xhttp_download_reuse_max_concurrency" "$xhttp_download_reuse_max_connections" "$xhttp_download_c_max_reuse_times" "$xhttp_download_h_max_request_times" "$xhttp_download_h_max_reusable_secs" || true
        ;;
      *)
        echo "    network: tcp"
        ;;
    esac
  done <<< "$cf_hosts"
}

mgr_managed_tls_proxy_names() {
  local row="$1"
  local public_ip domain id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn decryption encryption enabled
  local server_name cf_hosts address label

  [ -n "$row" ] || return 1
  IFS='|' read -r id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn decryption encryption enabled <<< "$row"
  [ "${enabled}" = "1" ] || return 1
  case "$transport" in
    ws|httpupgrade|tcp|xhttp) ;;
    *) return 1 ;;
  esac

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  server_name="$(mgr_pick_access_host "$domain" "${net_host:-$public_ip}" || true)"
  [ -n "$server_name" ] && [ -n "$uuid" ] || return 1

  cf_hosts="$(mgr_get_cf_preferred_domains)"
  if [ -z "$cf_hosts" ]; then
    cf_hosts="$server_name"
  fi
  while IFS= read -r address; do
    [ -n "$address" ] || continue
    label="managed-tls"
    if [ "$address" != "$server_name" ]; then
      label="managed-tls-${address}"
    fi
    echo "$label"
  done <<< "$cf_hosts"
}

mgr_emit_mihomo_reality_proxy() {
  local row="$1"
  local public_ip domain id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn sni public_key short_ids decryption encryption enabled
  local host short_id

  [ -n "$row" ] || return 1
  IFS='|' read -r id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn sni public_key short_ids decryption encryption enabled <<< "$row"
  [ "${enabled}" = "1" ] || return 1

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  host="$(mgr_pick_access_host "$domain" "$public_ip" || true)"
  short_id="$(mgr_primary_reality_short_id "$short_ids")"
  [ -n "$host" ] && [ -n "$uuid" ] && [ -n "$public_key" ] && [ -n "$short_id" ] || return 1
  case "$transport" in
    tcp|xhttp) ;;
    *) return 1 ;;
  esac

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"
  encryption="$(mgr_normalize_vless_crypto_value "$encryption")"
  if [ "$decryption" = "none" ]; then
    encryption="none"
  fi
  if [ -z "$xhttp_padding_bytes" ]; then
    xhttp_padding_bytes="$(mgr_default_xhttp_padding_bytes)"
  fi

  echo "  - name: $(mgr_yaml_quote "managed-reality")"
  echo "    type: vless"
  echo "    server: $(mgr_yaml_quote "$host")"
  echo "    port: 443"
  echo "    udp: true"
  echo "    packet-encoding: xudp"
  echo "    uuid: $(mgr_yaml_quote "$uuid")"
  echo "    tls: true"
  echo "    servername: $(mgr_yaml_quote "$sni")"
  echo "    client-fingerprint: chrome"
  echo "    reality-opts:"
  echo "      public-key: $(mgr_yaml_quote "$public_key")"
  echo "      short-id: $(mgr_yaml_quote "$short_id")"
  if [ "$encryption" != "none" ]; then
    echo "    encryption: $(mgr_yaml_quote "$encryption")"
  fi

  if [ "$transport" = "xhttp" ]; then
    echo "    network: xhttp"
    mgr_emit_mihomo_alpn "    " "$tls_alpn"
    echo "    xhttp-opts:"
    echo "      path: $(mgr_yaml_quote "${net_path:-/}")"
    if [ -n "$net_host" ]; then
      echo "      host: $(mgr_yaml_quote "$net_host")"
    fi
    mgr_emit_mihomo_json_headers "      " "$xhttp_headers_json" || true
    echo "      mode: $(mgr_yaml_quote "${net_service:-auto}")"
    echo "      x-padding-bytes: $(mgr_yaml_quote "$xhttp_padding_bytes")"
    if [ -n "$(mgr_optional_bool_value "$xhttp_no_grpc_header")" ]; then
      echo "      no-grpc-header: $(mgr_optional_bool_value "$xhttp_no_grpc_header")"
    fi
    if [ -n "$(mgr_trim_value "$xhttp_sc_max_each_post_bytes")" ]; then
      echo "      sc-max-each-post-bytes: $(mgr_yaml_number_or_quote "$xhttp_sc_max_each_post_bytes")"
    fi
    mgr_emit_mihomo_xhttp_reuse_settings "      " "1" "$xhttp_reuse_max_concurrency" "$xhttp_reuse_max_connections" "$xhttp_c_max_reuse_times" "$xhttp_h_max_request_times" "$xhttp_h_max_reusable_secs" || true
    mgr_emit_mihomo_xhttp_download_settings "      " "$xhttp_download_path" "$xhttp_download_host" "$xhttp_download_headers_json" "$xhttp_download_no_grpc_header" "$xhttp_download_padding_bytes" "$xhttp_download_sc_max_each_post_bytes" "$xhttp_download_reuse_max_concurrency" "$xhttp_download_reuse_max_connections" "$xhttp_download_c_max_reuse_times" "$xhttp_download_h_max_request_times" "$xhttp_download_h_max_reusable_secs" || true
  else
    echo "    flow: $(mgr_yaml_quote "${flow:-xtls-rprx-vision}")"
    echo "    network: tcp"
  fi
}

mgr_render_managed_v2ray_subscription() {
  local tls_row="$1"
  local reality_row="$2"
  local tls_uri reality_uri first=1

  tls_uri="$(mgr_build_managed_tls_vless_uri "$tls_row" 2>/dev/null || true)"
  reality_uri="$(mgr_build_managed_reality_vless_uri "$reality_row" 2>/dev/null || true)"

  [ -n "$tls_uri" ] || [ -n "$reality_uri" ] || return 1

  if [ -n "$tls_uri" ]; then
    printf "%s" "$tls_uri"
    first=0
  fi
  if [ -n "$reality_uri" ]; then
    if [ "$first" -eq 0 ]; then
      printf "\n"
    fi
    printf "%s" "$reality_uri"
  fi
}

mgr_render_managed_mihomo_yaml() {
  local tls_row="$1"
  local reality_row="$2"
  local tls_proxy reality_proxy proxy_names

  tls_proxy="$(mgr_emit_mihomo_tls_proxy "$tls_row" || true)"
  reality_proxy="$(mgr_emit_mihomo_reality_proxy "$reality_row" || true)"

  [ -n "$tls_proxy" ] || [ -n "$reality_proxy" ] || return 1

  echo "mixed-port: 7890"
  echo "allow-lan: false"
  echo "mode: rule"
  echo "log-level: info"
  echo "proxies:"
  if [ -n "$tls_proxy" ]; then
    printf "%s\n" "$tls_proxy"
    while IFS= read -r proxy_name; do
      [ -n "$proxy_name" ] || continue
      proxy_names="${proxy_names}
${proxy_name}"
    done <<< "$(mgr_managed_tls_proxy_names "$tls_row" || true)"
  fi
  if [ -n "$reality_proxy" ]; then
    printf "%s\n" "$reality_proxy"
    proxy_names="${proxy_names}
managed-reality"
  fi
  echo "proxy-groups:"
  echo "  - name: $(mgr_yaml_quote "PROXY")"
  echo "    type: select"
  echo "    proxies:"
  while IFS= read -r proxy_name; do
    [ -n "$proxy_name" ] || continue
    echo "      - $(mgr_yaml_quote "$proxy_name")"
  done <<< "$proxy_names"
  echo "      - DIRECT"
  echo "rules:"
  echo "  - MATCH,PROXY"
}

mgr_write_secret_file() {
  local path="$1"
  local payload="$2"
  local tmp_file

  mkdir -p "$(dirname "$path")"
  tmp_file="$(mktemp "${path}.tmp.XXXXXX")" || return 1
  if ! printf "%s\n" "$payload" > "$tmp_file"; then
    rm -f "$tmp_file"
    return 1
  fi
  chmod 600 "$tmp_file" 2>/dev/null || true
  if ! mv "$tmp_file" "$path"; then
    rm -f "$tmp_file"
    return 1
  fi
  chmod 600 "$path" 2>/dev/null || true
}

mgr_write_secret_file_from_stdin() {
  local path="$1"
  local tmp_file

  mkdir -p "$(dirname "$path")"
  tmp_file="$(mktemp "${path}.tmp.XXXXXX")" || return 1
  if ! cat > "$tmp_file"; then
    rm -f "$tmp_file"
    return 1
  fi
  chmod 600 "$tmp_file" 2>/dev/null || true
  if ! mv "$tmp_file" "$path"; then
    rm -f "$tmp_file"
    return 1
  fi
  chmod 600 "$path" 2>/dev/null || true
}

mgr_write_managed_subscription_files() {
  local tls_row="$1"
  local reality_row="$2"
  local sub_dir v2ray_path v2ray_base64_path mihomo_path
  local v2ray_payload mihomo_payload

  sub_dir="$(mgr_subscription_dir)"
  v2ray_path="${sub_dir}/managed-v2ray.txt"
  v2ray_base64_path="${sub_dir}/managed-v2ray-base64.txt"
  mihomo_path="${sub_dir}/managed-mihomo.yaml"

  ensure_dir_permissions "$sub_dir" 700

  v2ray_payload="$(mgr_render_managed_v2ray_subscription "$tls_row" "$reality_row" || true)"
  if [ -n "$v2ray_payload" ]; then
    if ! mgr_write_secret_file "$v2ray_path" "$v2ray_payload"; then
      log_warn "V2Ray 订阅文件写入失败: ${v2ray_path}"
    fi
    if printf "%s" "$v2ray_payload" | mgr_base64_no_wrap | mgr_write_secret_file_from_stdin "$v2ray_base64_path"; then
      :
    else
      rm -f "$v2ray_base64_path"
      log_warn "当前系统未找到 base64 / openssl，跳过 Base64 订阅文件导出。"
    fi
  else
    rm -f "$v2ray_path" "$v2ray_base64_path"
  fi

  mihomo_payload="$(mgr_render_managed_mihomo_yaml "$tls_row" "$reality_row" || true)"
  if [ -n "$mihomo_payload" ]; then
    if ! mgr_write_secret_file "$mihomo_path" "$mihomo_payload"; then
      log_warn "Mihomo 订阅文件写入失败: ${mihomo_path}"
    fi
  else
    rm -f "$mihomo_path"
  fi
}

mgr_print_managed_tls_link() {
  local row="$1"
  local public_ip domain id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn decryption encryption enabled
  local host

  if [ -z "$row" ]; then
    log_warn "当前还没有受管 TLS 节点。"
    return 1
  fi

  IFS='|' read -r id tag protocol uuid transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn decryption encryption enabled <<< "$row"
  if [ "${enabled}" != "1" ]; then
    log_warn "受管 TLS 节点当前未启用。"
    return 1
  fi

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  host="$(mgr_pick_access_host "$domain" "${net_host:-$public_ip}" || true)"
  if [ -z "$host" ] || [ -z "$uuid" ]; then
    log_warn "TLS 节点缺少必要参数，无法导出链接。"
    return 1
  fi

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"

  echo "协议: VLESS"
  echo "地址: ${host}"
  echo "端口: 443"
  echo "传输: ${transport}"
  echo "路径: ${net_path:-/}"
  if [ "$transport" = "xhttp" ]; then
    echo "模式: ${net_service:-auto}"
    echo "Padding: ${xhttp_padding_bytes:-$(mgr_default_xhttp_padding_bytes)}"
    echo "XMUX hMaxRequestTimes: $(mgr_default_xhttp_xmux_hmaxrequesttimes)"
  fi
  echo "VLESS 加密: $(mgr_vlessenc_status_text "$decryption")"
  echo ""
  echo "分享链接:"
  mgr_build_managed_tls_vless_uri "$row" || return 1
  return 0
}

mgr_print_managed_reality_link() {
  local row="$1"
  local public_ip domain id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes
  local xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs
  local xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes
  local xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs
  local tls_alpn sni public_key short_ids decryption encryption enabled
  local host short_id

  if [ -z "$row" ]; then
    log_warn "当前还没有受管 Reality 节点。"
    return 1
  fi

  IFS='|' read -r id tag protocol uuid flow transport net_path net_host net_service xhttp_padding_bytes xhttp_headers_json xhttp_no_grpc_header xhttp_sc_max_each_post_bytes xhttp_reuse_max_concurrency xhttp_reuse_max_connections xhttp_c_max_reuse_times xhttp_h_max_request_times xhttp_h_max_reusable_secs xhttp_download_path xhttp_download_host xhttp_download_headers_json xhttp_download_no_grpc_header xhttp_download_padding_bytes xhttp_download_sc_max_each_post_bytes xhttp_download_reuse_max_concurrency xhttp_download_reuse_max_connections xhttp_download_c_max_reuse_times xhttp_download_h_max_request_times xhttp_download_h_max_reusable_secs tls_alpn sni public_key short_ids decryption encryption enabled <<< "$row"
  if [ "${enabled}" != "1" ]; then
    log_warn "受管 Reality 节点当前未启用。"
    return 1
  fi

  domain="$(mgr_normalize_access_host "$(mgr_get_panel_domain)")"
  public_ip="$(mgr_get_public_ip || true)"
  host="$(mgr_pick_access_host "$domain" "$public_ip" || true)"
  short_id="$(mgr_primary_reality_short_id "$short_ids")"
  if [ -z "$host" ] || [ -z "$uuid" ] || [ -z "$public_key" ] || [ -z "$short_id" ]; then
    log_warn "Reality 节点缺少必要参数，无法导出链接。"
    return 1
  fi

  decryption="$(mgr_normalize_vless_crypto_value "$decryption")"
  if [ "$transport" = "xhttp" ] && [ -z "$xhttp_padding_bytes" ]; then
    xhttp_padding_bytes="$(mgr_default_xhttp_padding_bytes)"
  fi

  echo "协议: VLESS"
  echo "地址: ${host}"
  echo "端口: 443"
  echo "传输: ${transport}"
  echo "SNI: ${sni}"
  echo "VLESS 加密: $(mgr_vlessenc_status_text "$decryption")"
  if [ "$transport" = "xhttp" ]; then
    echo "路径: ${net_path:-/}"
    echo "Padding: ${xhttp_padding_bytes:-$(mgr_default_xhttp_padding_bytes)}"
    echo "XMUX hMaxRequestTimes: $(mgr_default_xhttp_xmux_hmaxrequesttimes)"
  fi
  echo ""
  echo "分享链接:"
  mgr_build_managed_reality_vless_uri "$row" || return 1
  return 0
}

mgr_show_managed_nodes() {
  local tls_row reality_row
  local tls_id tls_tag tls_protocol tls_uuid tls_transport tls_path tls_host tls_service tls_padding tls_headers_json tls_no_grpc_header tls_sc_max_each_post_bytes
  local tls_reuse_max_concurrency tls_reuse_max_connections tls_c_max_reuse_times tls_h_max_request_times tls_h_max_reusable_secs
  local tls_download_path tls_download_host tls_download_headers_json tls_download_no_grpc_header tls_download_padding tls_download_sc_max_each_post_bytes
  local tls_download_reuse_max_concurrency tls_download_reuse_max_connections tls_download_c_max_reuse_times tls_download_h_max_request_times tls_download_h_max_reusable_secs
  local tls_alpn tls_decryption tls_encryption tls_enable tls_access_host
  local reality_id reality_tag reality_protocol reality_uuid reality_flow reality_transport reality_path reality_host reality_service reality_padding reality_headers_json reality_no_grpc_header reality_sc_max_each_post_bytes
  local reality_reuse_max_concurrency reality_reuse_max_connections reality_c_max_reuse_times reality_h_max_request_times reality_h_max_reusable_secs
  local reality_download_path reality_download_host reality_download_headers_json reality_download_no_grpc_header reality_download_padding reality_download_sc_max_each_post_bytes
  local reality_download_reuse_max_concurrency reality_download_reuse_max_connections reality_download_c_max_reuse_times reality_download_h_max_request_times reality_download_h_max_reusable_secs
  local reality_alpn reality_sni reality_public_key reality_short_ids reality_decryption reality_encryption reality_enable reality_access_host

  clear
  echo -e "${CYAN}==== 当前受管节点 ====${NC}"
  echo ""

  if ! mgr_ensure_sqlite3; then
    log_error "sqlite3 不可用，无法读取节点信息。"
    mgr_pause_wait
    return
  fi

  tls_row="$(mgr_get_managed_tls_row)"
  reality_row="$(mgr_get_managed_reality_row)"

  echo -e "${GREEN}TLS 节点${NC}"
  if [ -n "$tls_row" ]; then
    IFS='|' read -r tls_id tls_tag tls_protocol tls_uuid tls_transport tls_path tls_host tls_service tls_padding tls_headers_json tls_no_grpc_header tls_sc_max_each_post_bytes tls_reuse_max_concurrency tls_reuse_max_connections tls_c_max_reuse_times tls_h_max_request_times tls_h_max_reusable_secs tls_download_path tls_download_host tls_download_headers_json tls_download_no_grpc_header tls_download_padding tls_download_sc_max_each_post_bytes tls_download_reuse_max_concurrency tls_download_reuse_max_connections tls_download_c_max_reuse_times tls_download_h_max_request_times tls_download_h_max_reusable_secs tls_alpn tls_decryption tls_encryption tls_enable <<< "$tls_row"
    tls_access_host="$(mgr_pick_access_host "$(mgr_normalize_access_host "$(mgr_get_panel_domain)")" "${tls_host:-$(mgr_get_public_ip || true)}" || true)"
    echo "  标签: ${tls_tag}"
    echo "  地址: ${tls_access_host}"
    echo "  端口: 443"
    echo "  传输: ${tls_transport:-ws}"
    echo "  路径: ${tls_path:-/}"
    if [ "${tls_transport}" = "xhttp" ]; then
      echo "  模式: ${tls_service:-auto}"
      echo "  Padding: ${tls_padding:-$(mgr_default_xhttp_padding_bytes)}"
      echo "  XMUX hMaxRequestTimes: $(mgr_default_xhttp_xmux_hmaxrequesttimes)"
    fi
    echo "  VLESS 加密: $(mgr_vlessenc_status_text "$tls_decryption")"
    echo "  状态: $([ "${tls_enable}" = "1" ] && echo "已启用" || echo "已停用")"
  else
    echo "  未创建"
  fi
  echo ""

  echo -e "${GREEN}Reality 节点${NC}"
  if [ -n "$reality_row" ]; then
    IFS='|' read -r reality_id reality_tag reality_protocol reality_uuid reality_flow reality_transport reality_path reality_host reality_service reality_padding reality_headers_json reality_no_grpc_header reality_sc_max_each_post_bytes reality_reuse_max_concurrency reality_reuse_max_connections reality_c_max_reuse_times reality_h_max_request_times reality_h_max_reusable_secs reality_download_path reality_download_host reality_download_headers_json reality_download_no_grpc_header reality_download_padding reality_download_sc_max_each_post_bytes reality_download_reuse_max_concurrency reality_download_reuse_max_connections reality_download_c_max_reuse_times reality_download_h_max_request_times reality_download_h_max_reusable_secs reality_alpn reality_sni reality_public_key reality_short_ids reality_decryption reality_encryption reality_enable <<< "$reality_row"
    reality_access_host="$(mgr_pick_access_host "$(mgr_normalize_access_host "$(mgr_get_panel_domain)")" "$(mgr_get_public_ip || true)" || true)"
    echo "  标签: ${reality_tag}"
    echo "  地址: ${reality_access_host}"
    echo "  端口: 443"
    echo "  传输: ${reality_transport:-tcp}"
    if [ "${reality_transport}" = "xhttp" ]; then
      echo "  路径: ${reality_path:-/}"
      echo "  XHTTP: 官方最小配置（mode/extra/padding 未写入）"
    else
      echo "  Flow: ${reality_flow:-xtls-rprx-vision}"
    fi
    echo "  SNI: ${reality_sni}"
    echo "  VLESS 加密: $(mgr_vlessenc_status_text "$reality_decryption")"
    echo "  状态: $([ "${reality_enable}" = "1" ] && echo "已启用" || echo "已停用")"
  else
    echo "  未创建"
  fi

  mgr_pause_wait
}

mgr_export_managed_node_links() {
  local tls_row reality_row
  local sub_dir v2ray_path v2ray_base64_path mihomo_path subscription_url

  clear
  echo -e "${CYAN}==== 导出受管节点 / 订阅 ====${NC}"
  echo ""

  if ! mgr_ensure_sqlite3; then
    log_error "sqlite3 不可用，无法读取节点信息。"
    mgr_pause_wait
    return
  fi

  tls_row="$(mgr_get_managed_tls_row)"
  reality_row="$(mgr_get_managed_reality_row)"

  echo -e "${GREEN}TLS 节点链接${NC}"
  mgr_print_managed_tls_link "$tls_row" || true
  echo ""
  echo -e "${GREEN}Reality 节点链接${NC}"
  mgr_print_managed_reality_link "$reality_row" || true

  mgr_write_managed_subscription_files "$tls_row" "$reality_row"
  sub_dir="$(mgr_subscription_dir)"
  v2ray_path="${sub_dir}/managed-v2ray.txt"
  v2ray_base64_path="${sub_dir}/managed-v2ray-base64.txt"
  mihomo_path="${sub_dir}/managed-mihomo.yaml"

  if [ -f "$v2ray_path" ]; then
    echo ""
    echo -e "${GREEN}V2Ray 通用订阅（明文）${NC}"
    cat "$v2ray_path"
  fi

  if [ -f "$v2ray_base64_path" ]; then
    echo ""
    echo -e "${GREEN}V2Ray Base64 订阅${NC}"
    cat "$v2ray_base64_path"
  fi

  if [ -f "$mihomo_path" ]; then
    echo ""
    echo -e "${GREEN}Mihomo / Clash 配置${NC}"
    cat "$mihomo_path"
  fi

  echo ""
  echo "已写入文件:"
  if [ -f "$v2ray_path" ]; then
    echo "  ${v2ray_path}"
  fi
  if [ -f "$v2ray_base64_path" ]; then
    echo "  ${v2ray_base64_path}"
  fi
  if [ -f "$mihomo_path" ]; then
    echo "  ${mihomo_path}"
  fi
  echo "Mihomo 辅助内核: $(mgr_get_mihomo_version)"
  subscription_url="$(build_subscription_url || true)"
  if get_subscription_enabled; then
    if [ -n "$subscription_url" ]; then
      echo "V2Ray 标准订阅 URL: ${subscription_url}"
      echo "Mihomo 显式订阅 URL: ${subscription_url}?format=mihomo"
    else
      echo "订阅 URL: 未生成（缺少 TLS 证书或接入域名 / IP）"
    fi
  fi

  mgr_pause_wait
}

mgr_create_tls_node() {
  local domain tls_network tls_path

  clear
  echo -e "${CYAN}==== 创建 / 更新 TLS 节点 ====${NC}"
  echo ""
  log_info "将自动检查域名、证书，并创建 Xray 直连 TLS 入站。"

  tls_network="$(mgr_prompt_tls_node_network)"
  if [ "$tls_network" = "xhttp" ]; then
    tls_path="$(mgr_get_tls_node_path)"
    log_info "当前 TLS XHTTP 节点路径: ${tls_path}"
    log_info "当前 TLS XHTTP 模式: $(mgr_get_tls_node_xhttp_mode)"
    mgr_prompt_xhttp_mode "TLS" "TLS_NODE_XHTTP_MODE" >/dev/null
  fi
  if ! mgr_prompt_vlessenc_pair "TLS" "TLS_NODE_DECRYPTION" "TLS_NODE_ENCRYPTION" >/dev/null; then
    mgr_pause_wait
    return
  fi

  mgr_ensure_domain_and_cert "TLS" || {
    mgr_pause_wait
    return
  }
  domain="$(mgr_get_panel_domain)"

  if ! mgr_ensure_tls_443_direct_inbound "$domain"; then
    mgr_pause_wait
    return
  fi
  echo ""
  mgr_print_managed_tls_link "$(mgr_get_managed_tls_row)" || true
  mgr_pause_wait
}

mgr_create_reality_node() {
  local reality_network reality_path

  clear
  echo -e "${CYAN}==== 创建 / 更新 Reality 节点 ====${NC}"
  echo ""
  log_info "将创建 Xray 直连 Reality 入站，不依赖 Nginx。"

  reality_network="$(mgr_prompt_reality_node_network)"
  if [ "$reality_network" = "xhttp" ]; then
    reality_path="$(mgr_get_reality_node_path)"
    log_info "当前 Reality XHTTP 节点路径: ${reality_path}"
    log_info "Reality XHTTP 使用官方最小配置，不写入 mode / extra / padding。"
  fi
  if ! mgr_prompt_vlessenc_pair "Reality" "REALITY_NODE_DECRYPTION" "REALITY_NODE_ENCRYPTION" >/dev/null; then
    mgr_pause_wait
    return
  fi

  mgr_ensure_access_host "Reality" || {
    mgr_pause_wait
    return
  }

  if ! mgr_ensure_reality_443_inbound; then
    mgr_pause_wait
    return
  fi
  echo ""
  mgr_print_managed_reality_link "$(mgr_get_managed_reality_row)" || true
  mgr_pause_wait
}

mgr_manage_nodes() {
  clear
  echo -e "${CYAN}==== 节点管理 ====${NC}"
  echo ""
  echo "1) 创建 / 更新 TLS 节点"
  echo "2) 创建 / 更新 Reality 节点"
  echo "3) 查看当前受管节点"
  echo "4) 导出受管节点 / 订阅"
  echo "5) Cloudflare 优选地址（当前: $(read_cfg "CF_PREFERRED_DOMAINS" | sed 's/^$/未设置/')）"
  echo "6) Cloudflare 优选地址自动抓取（当前源: $(read_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" | sed 's/^$/内置中国移动源/')）"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "

  local choice
  read -r choice
  case "$choice" in
    1) mgr_create_tls_node ;;
    2) mgr_create_reality_node ;;
    3) mgr_show_managed_nodes ;;
    4) mgr_export_managed_node_links ;;
    5)
      echo "用于 TLS 订阅连接地址；SNI/Host 保持面板域名。多个 IP/域名用逗号分隔，留空清除。"
      echo -n "请输入 Cloudflare 优选地址: "
      read -r cf_domains_input
      save_cfg "CF_PREFERRED_DOMAINS" "$cf_domains_input"
      mgr_write_managed_subscription_files "$(mgr_get_managed_tls_row)" "$(mgr_get_managed_reality_row)"
      log_info "已更新 Cloudflare 优选地址并刷新本机订阅文件。"
      mgr_pause_wait
      ;;
    6)
      echo "默认使用内置中国移动 CMCC 优选 IP 源每 24 小时自动抓取；也可填自定义 URL 覆盖，多个 URL 用逗号分隔。"
      echo "支持纯文本、JSON、HTML 中提取 IP、IP:端口和域名。留空则恢复内置中国移动源。"
      echo -n "请输入自定义抓取源 URL: "
      read -r cf_source_input
      save_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" "$cf_source_input"
      install_cf_preferred_domains_refresh_timer
      /usr/local/bin/xray-cf-preferred-refresh.sh || true
      mgr_write_managed_subscription_files "$(mgr_get_managed_tls_row)" "$(mgr_get_managed_reality_row)"
      log_info "已启用 Cloudflare 优选地址 24 小时自动抓取并刷新本机订阅文件。"
      mgr_pause_wait
      ;;
    *) ;;
  esac
}

mgr_show_menu() {
  clear
  init_runtime_config

  local server_ip access_host mode tls_node_path tls_node_network reality_node_network reality_node_path
  local tls_xhttp_mode
  local reality_sni tg_enabled tg_status
  local weekly_update_status ping_block_status ping_block_effective cn_block_status ssh_port_status mihomo_version subscription_url subscription_port
  server_ip="$(mgr_get_public_ip || true)"
  access_host="$(mgr_pick_access_host "$(mgr_normalize_access_host "$(mgr_get_panel_domain)")" "$server_ip" || true)"
  mode="$(mgr_get_current_mode)"
  tls_node_path="$(read_cfg "TLS_NODE_PATH")"
  tls_node_network="$(mgr_get_tls_node_network)"
  reality_node_network="$(mgr_get_reality_node_network)"
  reality_node_path="$(read_cfg "REALITY_NODE_PATH")"
  tls_xhttp_mode="$(mgr_get_tls_node_xhttp_mode)"
  reality_sni="$(mgr_get_reality_sni_domain)"
  mihomo_version="$(mgr_get_mihomo_version)"
  subscription_url="$(build_subscription_url || true)"
  subscription_port="$(get_subscription_port)"
  tg_enabled="$(read_cfg "TG_ALERT_ENABLED")"
  tg_status="$(systemctl is-active xray-fail2ban-daily-report.timer 2>/dev/null || echo "inactive")/$(systemctl is-active xray-security-monitor.timer 2>/dev/null || echo "inactive")"
  weekly_update_status="$(systemctl is-active xray-weekly-update.timer 2>/dev/null || echo "inactive")"
  ssh_port_status="$(describe_ssh_port_policy)"
  if is_ping_block_enabled; then
    ping_block_status="已启用"
  else
    ping_block_status="已停用"
  fi
  if is_cn_traffic_block_enabled; then
    cn_block_status="已启用"
  else
    cn_block_status="已停用"
  fi
  if [ -f /proc/sys/net/ipv4/icmp_echo_ignore_all ] && [ "$(cat /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null)" = "1" ]; then
    ping_block_effective="已生效"
  else
    ping_block_effective="等待生效"
  fi

  echo -e "${CYAN}==============================${NC}"
  echo -e "${CYAN}         Xray 后端管理器      ${NC}"
  echo -e "${CYAN}==============================${NC}"
  echo ""

  echo -e "${GREEN}运行信息${NC}"
  echo "  服务器 IP: $server_ip"
  echo "  当前模式: $mode（Xray 直连）"
  if [ -n "$access_host" ]; then
    echo "  接入域名 / IP: $access_host"
  else
    echo "  接入域名 / IP: 未设置"
  fi
  if [ -n "$reality_sni" ]; then
    echo "  Reality 伪装域名: $reality_sni"
  else
    echo "  Reality 伪装域名: 未设置"
  fi
  echo "  后端服务: $(systemctl is-active "$BACKEND_SERVICE" 2>/dev/null || echo 'inactive')"
  echo "  Mihomo 辅助内核: ${mihomo_version}"
  if get_subscription_enabled; then
    echo "  订阅服务端口: ${subscription_port}"
    if [ -n "$subscription_url" ]; then
      echo "  V2Ray 标准订阅 URL: ${subscription_url}"
      echo "  Mihomo 显式订阅 URL: ${subscription_url}?format=mihomo"
    else
      echo "  订阅 URL: 未生成（缺少 TLS 证书或接入域名 / IP）"
    fi
  else
    echo "  订阅: 已禁用"
  fi
  echo "  Telegram 通知: ${tg_enabled:-0}（日报/巡检: ${tg_status}）"
  echo "  周期更新定时器: ${weekly_update_status}"
  echo "  日志保留: 最多 72 小时；Xray 访问日志不落盘"
  echo "  SSH 端口策略: ${ssh_port_status}"
  echo "  Ping 防护: ${ping_block_status}（${ping_block_effective}）"
  echo "  中国大陆站点访问阻断: ${cn_block_status}"
  if [ "$mode" = "tls" ]; then
    echo "  TLS 节点路径: ${tls_node_path:-未设置}"
    echo "  TLS 节点传输: ${tls_node_network:-ws}"
    if [ "${tls_node_network}" = "xhttp" ]; then
      echo "  TLS XHTTP 模式: ${tls_xhttp_mode:-auto}"
    fi
  elif [ "$mode" = "reality" ]; then
    echo "  Reality 节点传输: ${reality_node_network:-tcp}"
    if [ "${reality_node_network}" = "xhttp" ]; then
      echo "  Reality 节点路径: ${reality_node_path:-未设置}"
      echo "  Reality XHTTP 模式: 官方默认"
    fi
  fi
  echo ""

  echo -e "${BLUE}功能菜单${NC}"
  echo "  1) 防火墙管理"
  echo "  2) 绑定接入域名 / IP 与 TLS 证书"
  echo "  3) Reality 伪装域名"
  echo "  4) 节点管理"
  echo "  5) Telegram 通知管理"
  echo "  0) 退出"
  echo ""
  echo -n "请选择 [0-5]: "
}

manager_main() {
  require_root
  detect_os
  init_runtime_config
  install_weekly_auto_update
  install_cf_preferred_domains_refresh_timer
  configure_log_retention

  while true; do
    mgr_show_menu
    read -r choice
    case "$choice" in
      1) mgr_manage_firewall ;;
      2) mgr_bind_domain ;;
      3) mgr_manage_reality_sni ;;
      4) mgr_manage_nodes ;;
      5) mgr_manage_tg_alert ;;
      0)
        echo ""
        log_info "已退出。"
        exit 0
        ;;
      *)
        log_error "无效选项。"
        sleep 1
        ;;
    esac
  done
}

installer_main() {
  echo "=============================================="
  echo "Xray 后端一键安装脚本"
  echo "=============================================="

  require_root
  purge_existing_install_if_requested
  detect_arch
  detect_os
  check_binary
  get_server_ip
  init_runtime_config

  setup_swap

  log_step "Installing base packages"
  install_packages

  harden_ssh
  enable_bbr
  setup_firewall
  setup_fail2ban
  configure_log_retention
  set_timezone
  install_xray_core
  install_mihomo_core || true
  install_backend_service
  install_weekly_auto_update
  install_cf_preferred_domains_refresh_timer
  /usr/local/bin/xray-cf-preferred-refresh.sh || log_warn "Cloudflare 优选地址立即刷新失败，将等待定时器重试。"
  install_management_tool
  mgr_sync_tg_alert_service
  print_summary
}

is_manage_mode() {
  local arg1="${1:-}"
  if [ "$SCRIPT_NAME" = "xy" ]; then
    return 0
  fi
  if [ "$arg1" = "manage" ] || [ "$arg1" = "--manage" ]; then
    return 0
  fi
  return 1
}

main() {
  if is_manage_mode "${1:-}"; then
    manager_main
  else
    installer_main
  fi
}

main "$@"
