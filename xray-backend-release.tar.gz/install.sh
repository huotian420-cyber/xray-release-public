#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_NAME="$(basename "$0")"

INSTALL_DIR="/opt/xray-backend"
BIN_NAME="xray-backend"
CONFIG_FILE="${INSTALL_DIR}/config.conf"

PANEL_PORT=2053
FALLBACK_PORT=12345
NEZHA_DASHBOARD_PORT=8008
NEZHA_DASHBOARD_DIR="/opt/nezha/dashboard"
NEZHA_DASHBOARD_SERVICE="nezha-dashboard"
NEZHA_NGINX_CONF_NAME="xray-nezha"
BACKEND_SERVICE="xray-backend"
NGINX_SERVICE="nginx"
SSL_RENEW_SERVICE="xray-ssl-renew"
SSL_RENEW_SCRIPT="/usr/local/bin/xray-ssl-renew.sh"
NGINX_APT_CHANNEL="${NGINX_APT_CHANNEL:-stable}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

OS="unknown"
BINARY=""
XRAY_ARCH=""
SERVER_IP=""
XRAY_VERSION=""
MIHOMO_VERSION=""
SSL_ISSUER_TOOL=""
RELEASE_ASSET_URL=""
RELEASE_ASSET_DIGEST=""
RELEASE_ASSET_NAME=""

CAMOUFLAGE_SITES=(
  "www.tsinghua.edu.cn"
  "www.pku.edu.cn"
  "www.zju.edu.cn"
  "www.sjtu.edu.cn"
  "www.fudan.edu.cn"
  "www.ustc.edu.cn"
  "www.nju.edu.cn"
  "www.seu.edu.cn"
  "www.whu.edu.cn"
  "www.bit.edu.cn"
  "www.xjtu.edu.cn"
  "www.buaa.edu.cn"
  "www.scut.edu.cn"
  "www.hit.edu.cn"
  "www.csdn.net"
  "www.oschina.net"
  "www.runoob.com"
  "www.infoq.cn"
  "www.cnblogs.com"
  "juejin.cn"
)

NGINX_PANEL_CONF=""
NGINX_FALLBACK_CONF=""
NGINX_ENABLE_DIR=""

log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
  echo -e "\n${BLUE}==>${NC} $1"
}

apt_get_update_with_retry() {
  local max_attempts="${APT_UPDATE_RETRIES:-5}"
  local base_delay="${APT_UPDATE_RETRY_DELAY_SECONDS:-5}"
  local attempt delay

  for ((attempt=1; attempt<=max_attempts; attempt++)); do
    if apt-get update -o Acquire::Retries=3 -o Acquire::http::No-Cache=true -o Acquire::ForceIPv4=true; then
      return 0
    fi

    if [ "$attempt" -ge "$max_attempts" ]; then
      break
    fi

    delay=$((base_delay * attempt))
    log_warn "apt-get update 失败（第 ${attempt}/${max_attempts} 次），清理索引缓存并在 ${delay}s 后重试。"
    apt-get clean || true
    rm -rf /var/lib/apt/lists/*
    mkdir -p /var/lib/apt/lists/partial
    sleep "$delay"
  done

  log_error "apt-get update 多次失败。APT 软件源可能正在同步，请稍后重试。"
  return 1
}

apt_get_install_with_retry() {
  apt-get install -y -o Acquire::Retries=3 -o Acquire::ForceIPv4=true "$@"
}

apt_get_upgrade_only_with_retry() {
  apt-get install --only-upgrade -y -o Acquire::Retries=3 -o Acquire::ForceIPv4=true "$@"
}

configure_nginx_org_apt_repo() {
  local os_id="" os_like="" os_codename="" repo_family="" repo_base="" channel keyring key_tmp keyring_tmp

  if [ -r /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    os_id="${ID:-}"
    os_like="${ID_LIKE:-}"
    os_codename="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
  fi

  if [ -z "$os_codename" ] && command -v lsb_release >/dev/null 2>&1; then
    os_codename="$(lsb_release -sc 2>/dev/null || true)"
  fi

  case "$os_id" in
    ubuntu|debian)
      repo_family="$os_id"
      ;;
    *)
      if [[ " ${os_like} " == *" ubuntu "* ]]; then
        repo_family="ubuntu"
      elif [[ " ${os_like} " == *" debian "* ]]; then
        repo_family="debian"
      fi
      ;;
  esac

  if [ -z "$repo_family" ] || [ -z "$os_codename" ]; then
    log_error "无法识别当前 Debian/Ubuntu 发行版代号，不能配置 Nginx 官方 APT 源。"
    return 1
  fi

  channel="${NGINX_APT_CHANNEL:-stable}"
  case "$channel" in
    stable|"")
      channel="stable"
      repo_base="https://nginx.org/packages/${repo_family}"
      ;;
    mainline)
      repo_base="https://nginx.org/packages/mainline/${repo_family}"
      ;;
    *)
      log_error "不支持的 NGINX_APT_CHANNEL: ${channel}，只支持 stable 或 mainline。"
      return 1
      ;;
  esac

  if ! command -v curl >/dev/null 2>&1 || ! command -v gpg >/dev/null 2>&1; then
    log_error "配置 Nginx 官方源需要 curl 和 gpg，请先安装基础依赖。"
    return 1
  fi

  mkdir -p /usr/share/keyrings /etc/apt/sources.list.d /etc/apt/preferences.d
  keyring="/usr/share/keyrings/nginx-archive-keyring.gpg"
  key_tmp="$(mktemp)"
  keyring_tmp="$(mktemp)"

  if ! curl -fsSL https://nginx.org/keys/nginx_signing.key -o "$key_tmp"; then
    rm -f "$key_tmp" "$keyring_tmp"
    log_error "下载 Nginx 官方签名密钥失败。"
    return 1
  fi

  if ! gpg --dearmor < "$key_tmp" > "$keyring_tmp"; then
    rm -f "$key_tmp" "$keyring_tmp"
    log_error "导入 Nginx 官方签名密钥失败。"
    return 1
  fi

  install -m 644 "$keyring_tmp" "$keyring"
  rm -f "$key_tmp" "$keyring_tmp"

  cat > /etc/apt/sources.list.d/nginx.list <<EOF
deb [signed-by=${keyring}] ${repo_base} ${os_codename} nginx
EOF

  cat > /etc/apt/preferences.d/99nginx <<'EOF'
Package: *
Pin: origin nginx.org
Pin: release o=nginx
Pin-Priority: 900
EOF

  log_info "已配置 Nginx 官方 ${channel} APT 源: ${repo_base} ${os_codename}"
}

require_root() {
  if [ "$EUID" -ne 0 ]; then
    log_error "请使用 root 权限运行此脚本。"
    exit 1
  fi
}

is_valid_config_key() {
  [[ "$1" =~ ^[A-Z0-9_]+$ ]]
}

read_cfg() {
  local key="$1"
  if ! is_valid_config_key "$key"; then
    return
  fi
  if [ -f "$CONFIG_FILE" ]; then
    grep "^${key}=" "$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

save_cfg() {
  local key="$1"
  local value="$2"
  local tmp_file
  if ! is_valid_config_key "$key"; then
    log_error "配置键名非法: ${key}"
    return 1
  fi
  mkdir -p "$(dirname "$CONFIG_FILE")"
  value="$(normalize_config_value "$key" "$value")"
  tmp_file="$(mktemp "${CONFIG_FILE}.tmp.XXXXXX")"

  if [ -f "$CONFIG_FILE" ]; then
    grep -v "^${key}=" "$CONFIG_FILE" > "$tmp_file" || true
    printf '%s=%s\n' "$key" "$value" >> "$tmp_file"
  else
    printf '%s=%s\n' "$key" "$value" > "$tmp_file"
  fi
  chmod 600 "$tmp_file"
  mv -f "$tmp_file" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
}

remove_cfg() {
  local key="$1"
  local tmp_file
  if ! is_valid_config_key "$key" || [ ! -f "$CONFIG_FILE" ]; then
    return
  fi
  tmp_file="$(mktemp "${CONFIG_FILE}.tmp.XXXXXX")"
  grep -v "^${key}=" "$CONFIG_FILE" > "$tmp_file" || true
  chmod 600 "$tmp_file"
  mv -f "$tmp_file" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
}

detect_arch() {
  log_step "检测 CPU 架构"
  local arch
  arch="$(uname -m)"
  case "$arch" in
    x86_64)
      BINARY="xray-backend-linux-amd64"
      XRAY_ARCH="64"
      ;;
    aarch64|arm64)
      BINARY="xray-backend-linux-arm64"
      XRAY_ARCH="arm64-v8a"
      ;;
    *)
      log_error "暂不支持当前 CPU 架构: $arch"
      exit 1
      ;;
  esac
  log_info "CPU 架构: $arch"
  log_info "将使用二进制: $BINARY"
}

detect_os() {
  if [ -f /etc/debian_version ]; then
    OS="debian"
  elif [ -f /etc/redhat-release ]; then
    OS="centos"
  else
    OS="unknown"
  fi
  log_info "检测到系统: $OS"
}

check_binary() {
  local binary_path="${SCRIPT_DIR}/${BINARY}"
  if [ -f "$binary_path" ]; then
    return
  fi

  binary_path="${SCRIPT_DIR}/${BIN_NAME}"
  if [ -f "$binary_path" ]; then
    BINARY="${BIN_NAME}"
    return
  fi

  log_error "未找到可执行文件: ${SCRIPT_DIR}/${BINARY}"
  exit 1
}

fetch_public_ip() {
  local ip=""
  local curl_cmd=(curl -4 -fsS --connect-timeout 3 --max-time 6)

  if ! command -v curl >/dev/null 2>&1; then
    echo "unknown"
    return
  fi

  ip="$(${curl_cmd[@]} https://ifconfig.me 2>/dev/null | tr -d '[:space:]')" || true
  if [ -z "$ip" ]; then
    ip="$(${curl_cmd[@]} https://icanhazip.com 2>/dev/null | tr -d '[:space:]')" || true
  fi
  if [ -z "$ip" ]; then
    ip="$(${curl_cmd[@]} https://api.ipify.org 2>/dev/null | tr -d '[:space:]')" || true
  fi

  if [ -n "$ip" ]; then
    echo "$ip"
  else
    echo "unknown"
  fi
}

get_server_ip() {
  log_step "检测服务器公网 IP"
  SERVER_IP="$(fetch_public_ip)"
  log_info "服务器公网 IP: $SERVER_IP"
}

generate_random_suffix() {
  tr -dc 'a-z0-9' < /dev/urandom | head -c 10
}

generate_management_password() {
  tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 18
}

generate_security_alert_ingest_token() {
  local generated
  if command -v openssl >/dev/null 2>&1; then
    generated="$(openssl rand -hex 32 2>/dev/null | tr -d '\r\n ' | tr '[:upper:]' '[:lower:]')"
    if [[ "$generated" =~ ^[a-f0-9]{64}$ ]]; then
      printf "%s" "$generated"
      return
    fi
  fi
  tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 64
}

pick_random_camouflage_site() {
  local index=$((RANDOM % ${#CAMOUFLAGE_SITES[@]}))
  echo "${CAMOUFLAGE_SITES[$index]}"
}

normalize_optional_panel_path() {
  local raw="$1"
  local normalized
  normalized="$(printf "%s" "$raw" | tr -d '\r\n\t ')"
  normalized="${normalized#http://}"
  normalized="${normalized#https://}"
  normalized="$(printf "%s" "$normalized" | sed 's#[?#].*$##')"
  normalized="$(printf "%s" "$normalized" | sed 's#^/*##; s#/*$##; s#//*#/#g; s#[^A-Za-z0-9/_-]##g')"

  case "/${normalized}/" in
    /|/api/*|/ws/*|/assets/*|/api-config/*|/*/../*|/*/./*)
      normalized=""
      ;;
  esac

  echo "$normalized"
}

normalize_panel_path() {
  local normalized
  normalized="$(normalize_optional_panel_path "$1")"
  if [ -z "$normalized" ]; then
    normalized="$(generate_random_suffix)"
  fi

  echo "$normalized"
}

normalize_panel_domain() {
  local raw="$1"
  local domain
  domain="$(printf "%s" "$raw" | tr -d '\r\n\t ')"
  domain="${domain#http://}"
  domain="${domain#https://}"
  domain="${domain%%/*}"
  domain="${domain%%\?*}"
  domain="${domain%%#*}"
  domain="${domain#[}"
  domain="${domain%]}"
  domain="$(printf "%s" "$domain" | tr '[:upper:]' '[:lower:]')"

  if [[ "$domain" =~ ^localhost$ ]] || [[ "$domain" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || [[ "$domain" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
    echo "$domain"
    return
  fi

  echo ""
}

normalize_panel_domain_list() {
  local raw="$1"
  local normalized="" token domain
  raw="$(printf "%s" "$raw" | tr ';| ' ',,,')"
  IFS=',' read -r -a tokens <<< "$raw"
  for token in "${tokens[@]}"; do
    domain="$(normalize_panel_domain "$token")"
    [ -n "$domain" ] || continue
    case ",${normalized}," in
      *,"${domain}",*) ;;
      *)
        if [ -n "$normalized" ]; then
          normalized="${normalized},${domain}"
        else
          normalized="$domain"
        fi
        ;;
    esac
  done
  printf "%s" "$normalized"
}

normalize_cf_preferred_source_urls() {
  local raw="$1"
  local normalized="" token source_url
  raw="$(printf "%s" "$raw" | tr '\r\n\t ' ',,,,')"
  IFS=',' read -r -a tokens <<< "$raw"
  for token in "${tokens[@]}"; do
    source_url="$(printf "%s" "$token" | tr -d '\r\n\t ')"
    case "$source_url" in
      http://*|https://*) ;;
      *) continue ;;
    esac
    if [ "${#source_url}" -gt 2048 ] || [[ "$source_url" == *[' "'"'"'`$;|&<>\\']* ]]; then
      continue
    fi
    case ",${normalized}," in
      *,"${source_url}",*) ;;
      *)
        if [ -n "$normalized" ]; then
          normalized="${normalized},${source_url}"
        else
          normalized="$source_url"
        fi
        ;;
    esac
  done
  printf "%s" "$normalized"
}

normalize_config_value() {
  local key="$1"
  local value="$2"
  case "$key" in
    PANEL_PATH|NEZHA_DASHBOARD_PATH)
      normalize_panel_path "$value"
      ;;
    PANEL_DOMAIN|CF_PREFERRED_DOMAIN|NEZHA_DASHBOARD_DOMAIN|NEZHA_AGENT_COMMUNICATION_DOMAIN)
      normalize_panel_domain "$value"
      ;;
    CF_PREFERRED_DOMAINS)
      normalize_panel_domain_list "$value"
      ;;
    CF_PREFERRED_DOMAINS_SOURCE_URL)
      normalize_cf_preferred_source_urls "$value"
      ;;
    CAMOUFLAGE_SITE)
      mgr_normalize_camouflage_site "$value"
      ;;
    NGINX_MODE)
      case "$(printf "%s" "$value" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')" in
        http|tls|reality) printf "%s" "$(printf "%s" "$value" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')" ;;
        *) printf "%s" "tls" ;;
      esac
      ;;
    API_PREFIX)
      mgr_normalize_api_prefix "$value"
      ;;
    TLS_NODE_PATH|REALITY_NODE_PATH)
      normalize_node_path "$value"
      ;;
    TLS_NODE_NETWORK)
      mgr_normalize_tls_node_network "$value"
      ;;
    REALITY_NODE_NETWORK)
      mgr_normalize_reality_node_network "$value"
      ;;
    TLS_NODE_XHTTP_MODE|REALITY_NODE_XHTTP_MODE)
      mgr_normalize_xhttp_mode "$value"
      ;;
    TG_ALERT_ENABLED|PING_BLOCK_ENABLED|BLOCK_CN_TRAFFIC|CLOUDFLARE_PROXY_ONLY)
      case "$(printf "%s" "$value" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')" in
        1|true|yes|on) printf "%s" "1" ;;
        *) printf "%s" "0" ;;
      esac
      ;;
    TG_ALERT_COOLDOWN)
      value="$(printf "%s" "$value" | tr -d '\r\n\t ')"
      if [[ "$value" =~ ^[0-9]{1,5}$ ]] && [ "$value" -le 86400 ]; then
        printf "%s" "$value"
      else
        printf "%s" "1800"
      fi
      ;;
    TG_TRAFFIC_ALERT_MBPS)
      value="$(printf "%s" "$value" | tr -d '\r\n\t ')"
      if [[ "$value" =~ ^[0-9]{1,6}$ ]] && [ "$value" -ge 1 ]; then
        printf "%s" "$value"
      else
        printf "%s" "500"
      fi
      ;;
    SSH_PORT|NEZHA_DASHBOARD_PORT)
      value="$(printf "%s" "$value" | tr -d '\r\n\t ')"
      if is_valid_port_number "$value"; then
        printf "%s" "$value"
      elif [ "$key" = "NEZHA_DASHBOARD_PORT" ]; then
        printf "%s" "$NEZHA_DASHBOARD_PORT"
      else
        printf "%s" "22"
      fi
      ;;
    SSL_ISSUER_TOOL)
      case "$(printf "%s" "$value" | tr -d '\r\n\t ')" in
        acme.sh|certbot|manual) printf "%s" "$(printf "%s" "$value" | tr -d '\r\n\t ')" ;;
        *) printf "%s" "" ;;
      esac
      ;;
    NEZHA_DASHBOARD_AGENT_SECRET)
      value="$(printf "%s" "$value" | tr -d '\r\n\t ')"
      if [[ "$value" =~ ^[A-Za-z0-9._-]{8,128}$ ]]; then
        printf "%s" "$value"
      else
        printf "%s" ""
      fi
      ;;
    SECURITY_ALERT_INGEST_TOKEN)
      value="$(printf "%s" "$value" | tr -d '\r\n\t ')"
      if [[ "$value" =~ ^[A-Za-z0-9._-]{16,256}$ ]]; then
        printf "%s" "$value"
      else
        printf "%s" ""
      fi
      ;;
    *)
      printf "%s" "$value" | tr -d '\r\n'
      ;;
  esac
}

init_runtime_config() {
  mkdir -p "$INSTALL_DIR"

  local panel_path panel_domain cf_preferred_domain cf_preferred_domains camouflage_site nginx_mode tg_alert_enabled tg_alert_cooldown tg_traffic_alert_mbps ping_block_enabled block_cn_traffic cloudflare_proxy_only vps_display_name public_ip security_alert_ingest_token ssh_port
  local tls_node_network reality_node_network tls_xhttp_mode reality_xhttp_mode
  panel_path="$(mgr_get_panel_path)"
  panel_domain="$(read_cfg "PANEL_DOMAIN")"
  cf_preferred_domain="$(read_cfg "CF_PREFERRED_DOMAIN")"
  cf_preferred_domains="$(read_cfg "CF_PREFERRED_DOMAINS")"
  camouflage_site="$(read_cfg "CAMOUFLAGE_SITE")"
  nginx_mode="$(read_cfg "NGINX_MODE")"
  tg_alert_enabled="$(read_cfg "TG_ALERT_ENABLED")"
  tg_alert_cooldown="$(read_cfg "TG_ALERT_COOLDOWN")"
  tg_traffic_alert_mbps="$(read_cfg "TG_TRAFFIC_ALERT_MBPS")"
  ping_block_enabled="$(read_cfg "PING_BLOCK_ENABLED")"
  block_cn_traffic="$(read_cfg "BLOCK_CN_TRAFFIC")"
  cloudflare_proxy_only="$(read_cfg "CLOUDFLARE_PROXY_ONLY")"
  vps_display_name="$(read_cfg "VPS_DISPLAY_NAME")"
  public_ip="$(read_cfg "PUBLIC_IP")"
  security_alert_ingest_token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN")"
  ssh_port="$(read_cfg "SSH_PORT")"
  tls_node_network="$(read_cfg "TLS_NODE_NETWORK")"
  reality_node_network="$(read_cfg "REALITY_NODE_NETWORK")"
  tls_xhttp_mode="$(read_cfg "TLS_NODE_XHTTP_MODE")"
  reality_xhttp_mode="$(read_cfg "REALITY_NODE_XHTTP_MODE")"

  panel_path="$(normalize_panel_path "$panel_path")"
  camouflage_site="$(mgr_normalize_camouflage_site "$camouflage_site")"
  nginx_mode="$(normalize_config_value "NGINX_MODE" "$nginx_mode")"

  if [ -z "$panel_path" ]; then
    panel_path="$(generate_random_suffix)"
  fi
  if [ -z "$nginx_mode" ]; then
    nginx_mode="tls"
  fi
  if [ -z "$vps_display_name" ]; then
    vps_display_name="$(hostname 2>/dev/null || echo "Xray 节点")"
  fi

  save_cfg "PANEL_PATH" "$panel_path"
  if [ -n "$cf_preferred_domain" ] && [ -n "$panel_domain" ] && [ "$(normalize_panel_domain "$cf_preferred_domain")" = "$(normalize_panel_domain "$panel_domain")" ]; then
    save_cfg "CF_PREFERRED_DOMAIN" ""
  fi
  if [ -n "$cf_preferred_domains" ]; then
    save_cfg "CF_PREFERRED_DOMAINS" "$cf_preferred_domains"
  fi
  save_cfg "CAMOUFLAGE_SITE" "$camouflage_site"
  save_cfg "NGINX_MODE" "$nginx_mode"
  save_cfg "VPS_DISPLAY_NAME" "$vps_display_name"
  if [ -n "$SERVER_IP" ] && [ "$SERVER_IP" != "unknown" ]; then
    save_cfg "PUBLIC_IP" "$SERVER_IP"
  elif [ -z "$public_ip" ]; then
    save_cfg "PUBLIC_IP" ""
  fi
  if ! [[ "$security_alert_ingest_token" =~ ^[A-Za-z0-9._-]{16,256}$ ]]; then
    save_cfg "SECURITY_ALERT_INGEST_TOKEN" "$(generate_security_alert_ingest_token)"
  fi
  if ! [[ "$ssh_port" =~ ^[0-9]+$ ]] || [ "$ssh_port" -lt 1 ] || [ "$ssh_port" -gt 65535 ]; then
    save_cfg "SSH_PORT" "22"
  fi
  if [ -z "$tls_node_network" ]; then
    save_cfg "TLS_NODE_NETWORK" "xhttp"
  fi
  if [ -z "$reality_node_network" ]; then
    save_cfg "REALITY_NODE_NETWORK" "xhttp"
  fi
  if [ -z "$tls_xhttp_mode" ]; then
    save_cfg "TLS_NODE_XHTTP_MODE" "auto"
  fi
  if [ -z "$reality_xhttp_mode" ]; then
    save_cfg "REALITY_NODE_XHTTP_MODE" "auto"
  fi
  if [ -z "$tg_alert_enabled" ]; then
    save_cfg "TG_ALERT_ENABLED" "0"
  fi
  if ! [[ "$tg_alert_cooldown" =~ ^[0-9]+$ ]]; then
    save_cfg "TG_ALERT_COOLDOWN" "1800"
  fi
  if ! [[ "$tg_traffic_alert_mbps" =~ ^[0-9]+$ ]] || [ "$tg_traffic_alert_mbps" -lt 1 ]; then
    save_cfg "TG_TRAFFIC_ALERT_MBPS" "500"
  fi
  if [ -z "$ping_block_enabled" ]; then
    save_cfg "PING_BLOCK_ENABLED" "1"
  fi
  if [ -z "$block_cn_traffic" ]; then
    save_cfg "BLOCK_CN_TRAFFIC" "0"
  fi
  if [ -z "$cloudflare_proxy_only" ]; then
    save_cfg "CLOUDFLARE_PROXY_ONLY" "0"
  fi
}

is_ping_block_enabled() {
  local value
  value="$(read_cfg "PING_BLOCK_ENABLED" | tr '[:upper:]' '[:lower:]')"
  if [ -z "$value" ] || [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ]; then
    return 0
  fi
  return 1
}

is_cn_traffic_block_enabled() {
  local value
  value="$(read_cfg "BLOCK_CN_TRAFFIC" | tr '[:upper:]' '[:lower:]')"
  if [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ] || [ "$value" = "on" ]; then
    return 0
  fi
  return 1
}

is_cloudflare_proxy_only_enabled() {
  local value
  value="$(read_cfg "CLOUDFLARE_PROXY_ONLY" | tr '[:upper:]' '[:lower:]')"
  if [ "$value" = "1" ] || [ "$value" = "true" ] || [ "$value" = "yes" ] || [ "$value" = "on" ]; then
    return 0
  fi
  return 1
}

mgr_has_direct_nezha_agent_domain() {
  local agent_domain panel_domain
  agent_domain="$(mgr_get_nezha_agent_domain 2>/dev/null || true)"
  panel_domain="$(mgr_get_panel_domain 2>/dev/null || true)"

  [ -n "$agent_domain" ] && { [ -z "$panel_domain" ] || [ "$agent_domain" != "$panel_domain" ]; }
}

install_packages() {
  case "$OS" in
    debian)
      export DEBIAN_FRONTEND=noninteractive
      apt_get_update_with_retry
      apt_get_install_with_retry ca-certificates curl wget git unzip tar python3 openssh-server fail2ban sqlite3 gnupg
      ;;
    centos)
      yum install -y epel-release || true
      yum install -y ca-certificates curl wget git unzip tar python3 openssh-server nginx sqlite
      yum install -y fail2ban || true
      ;;
    *)
      log_warn "暂不识别当前系统，请手动安装依赖。"
      ;;
  esac
}

log_nginx_version() {
  local version
  if command -v nginx >/dev/null 2>&1; then
    version="$(nginx -v 2>&1 | sed 's/^nginx version: //')"
    log_info "当前 Nginx: ${version:-unknown}"
  else
    log_warn "当前系统未检测到 nginx 命令。"
  fi
}

mgr_install_or_update_nginx_package() {
  log_step "安装/更新 Nginx"
  case "$OS" in
    debian)
      export DEBIAN_FRONTEND=noninteractive
      apt_get_update_with_retry
      apt_get_install_with_retry ca-certificates curl gnupg
      configure_nginx_org_apt_repo
      apt_get_update_with_retry
      apt_get_install_with_retry nginx
      ;;
    centos)
      if command -v dnf >/dev/null 2>&1; then
        dnf -y install nginx
      else
        yum install -y nginx
      fi
      ;;
    *)
      log_warn "暂不识别当前系统，请使用发行版包管理器手动安装/更新 Nginx。"
      return 1
      ;;
  esac
  log_nginx_version
  log_info "Debian/Ubuntu 会优先使用 nginx.org 官方 ${NGINX_APT_CHANNEL:-stable} 源。"
}

download_file_with_fallback() {
  local url="$1"
  local output="$2"
  local label="$3"

  rm -f "$output"

  if command -v wget >/dev/null 2>&1; then
    if wget --tries=3 --timeout=30 --waitretry=2 --retry-connrefused --show-progress -O "$output" "$url"; then
      return 0
    fi
    log_warn "${label} 下载失败，准备回退到 curl。"
  fi

  if command -v curl >/dev/null 2>&1; then
    if curl -fL --connect-timeout 15 --max-time 300 --retry 3 --retry-delay 2 -o "$output" "$url"; then
      return 0
    fi
  fi

  rm -f "$output"
  return 1
}

normalize_sha256_digest() {
  local raw="$1"
  local normalized
  normalized="$(printf '%s' "$raw" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
  normalized="${normalized#sha256:}"
  if printf '%s' "$normalized" | grep -Eq '^[0-9a-f]{64}$'; then
    printf '%s' "$normalized"
    return 0
  fi
  return 1
}

compute_file_sha256() {
  local file="$1"
  if [ ! -f "$file" ]; then
    return 1
  fi

  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$file" | awk '{print tolower($1)}'
    return 0
  fi
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$file" | awk '{print tolower($1)}'
    return 0
  fi
  if command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$file" | awk '{print tolower($NF)}'
    return 0
  fi

  return 1
}

extract_release_tag_name() {
  python3 -c '
import json
import sys

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(1)

tag = payload.get("tag_name")
if not isinstance(tag, str):
    sys.exit(1)

sys.stdout.write(tag.strip())
'
}

extract_release_asset_metadata() {
  local asset_name="$1"
  python3 -c '
import json
import sys

asset_name = sys.argv[1]

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(1)

for asset in payload.get("assets") or []:
    if not isinstance(asset, dict):
        continue
    if asset.get("name") == asset_name:
        url = asset.get("browser_download_url") or ""
        digest = asset.get("digest") or ""
        if not isinstance(url, str) or not isinstance(digest, str):
            sys.exit(1)
        sys.stdout.write(url.strip() + "\n")
        sys.stdout.write(digest.strip() + "\n")
        sys.exit(0)

sys.exit(1)
' "$asset_name"
}

lookup_release_asset() {
  local release_json="$1"
  local asset_name="$2"
  local metadata asset_url asset_digest

  RELEASE_ASSET_URL=""
  RELEASE_ASSET_DIGEST=""
  RELEASE_ASSET_NAME=""

  if [ -z "$release_json" ] || [ -z "$asset_name" ]; then
    return 1
  fi

  if ! metadata="$(printf '%s' "$release_json" | extract_release_asset_metadata "$asset_name" 2>/dev/null)"; then
    return 1
  fi

  asset_url="$(printf '%s\n' "$metadata" | sed -n '1p' | tr -d '\r')"
  asset_digest="$(printf '%s\n' "$metadata" | sed -n '2p' | tr -d '\r')"
  if [ -z "$asset_url" ]; then
    return 1
  fi

  if ! RELEASE_ASSET_DIGEST="$(normalize_sha256_digest "$asset_digest")"; then
    return 1
  fi

  RELEASE_ASSET_URL="$asset_url"
  RELEASE_ASSET_NAME="$asset_name"
  return 0
}

extract_mihomo_release_asset_metadata() {
  local mihomo_arch="$1"
  local release_tag="$2"
  python3 -c '
import json
import re
import sys

arch = sys.argv[1]
release_tag = sys.argv[2]

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(1)

tag_pattern = re.escape(release_tag)
if arch == "amd64":
    patterns = [
        rf"^mihomo-linux-amd64-v1(?:-[A-Za-z0-9._]+)?-{tag_pattern}\.gz$",
        rf"^mihomo-linux-amd64-compatible-{tag_pattern}\.gz$",
        rf"^mihomo-linux-amd64-{tag_pattern}\.gz$",
    ]
elif arch == "arm64":
    patterns = [
        rf"^mihomo-linux-arm64-v8(?:-[A-Za-z0-9._]+)?-{tag_pattern}\.gz$",
        rf"^mihomo-linux-arm64(?:-[A-Za-z0-9._]+)?-{tag_pattern}\.gz$",
        rf"^mihomo-linux-aarch64(?:-[A-Za-z0-9._]+)?-{tag_pattern}\.gz$",
    ]
else:
    sys.exit(1)

assets = []
for asset in payload.get("assets") or []:
    if not isinstance(asset, dict):
        continue
    name = asset.get("name") or ""
    url = asset.get("browser_download_url") or ""
    digest = asset.get("digest") or ""
    if not isinstance(name, str) or not isinstance(url, str) or not isinstance(digest, str):
        continue
    assets.append((name.strip(), url.strip(), digest.strip()))

for pattern in patterns:
    compiled = re.compile(pattern)
    for name, url, digest in assets:
        if compiled.match(name):
            sys.stdout.write(url + "\n")
            sys.stdout.write(digest + "\n")
            sys.stdout.write(name + "\n")
            sys.exit(0)

sys.exit(1)
' "$mihomo_arch" "$release_tag"
}

lookup_mihomo_release_asset() {
  local release_json="$1"
  local mihomo_arch="$2"
  local release_tag="$3"
  local metadata asset_url asset_digest asset_name

  RELEASE_ASSET_URL=""
  RELEASE_ASSET_DIGEST=""
  RELEASE_ASSET_NAME=""

  if [ -z "$release_json" ] || [ -z "$mihomo_arch" ] || [ -z "$release_tag" ]; then
    return 1
  fi

  if ! metadata="$(printf '%s' "$release_json" | extract_mihomo_release_asset_metadata "$mihomo_arch" "$release_tag" 2>/dev/null)"; then
    return 1
  fi

  asset_url="$(printf '%s\n' "$metadata" | sed -n '1p' | tr -d '\r')"
  asset_digest="$(printf '%s\n' "$metadata" | sed -n '2p' | tr -d '\r')"
  asset_name="$(printf '%s\n' "$metadata" | sed -n '3p' | tr -d '\r')"
  if [ -z "$asset_url" ] || [ -z "$asset_name" ]; then
    return 1
  fi

  if ! RELEASE_ASSET_DIGEST="$(normalize_sha256_digest "$asset_digest")"; then
    if ! RELEASE_ASSET_DIGEST="$(fetch_release_asset_sidecar_digest "$asset_url" "$asset_name")"; then
      return 1
    fi
  fi

  RELEASE_ASSET_URL="$asset_url"
  RELEASE_ASSET_NAME="$asset_name"
  return 0
}

extract_sha256_digest_from_text() {
  local asset_name="$1"
  python3 -c '
import re
import sys

asset_name = sys.argv[1]
text = sys.stdin.read()
if not text:
    sys.exit(1)

patterns = []
if asset_name:
    escaped = re.escape(asset_name)
    patterns.extend(
        [
            rf"(?im)\b{escaped}\b[^\n]*?\b([0-9a-fA-F]{{64}})\b",
            rf"(?im)\b([0-9a-fA-F]{{64}})\b[^\n]*?\b{escaped}\b",
        ]
    )

for pattern in patterns:
    match = re.search(pattern, text)
    if match:
        sys.stdout.write(match.group(1).lower())
        sys.exit(0)

match = re.search(r"(?i)\b([0-9a-f]{64})\b", text)
if match:
    sys.stdout.write(match.group(1).lower())
    sys.exit(0)

sys.exit(1)
' "$asset_name"
}

build_github_release_asset_url() {
  local repo_slug="$1"
  local release_tag="$2"
  local asset_name="$3"

  if [ -z "$repo_slug" ] || [ -z "$release_tag" ] || [ -z "$asset_name" ]; then
    return 1
  fi

  printf 'https://github.com/%s/releases/download/%s/%s\n' "$repo_slug" "$release_tag" "$asset_name"
}

extract_release_tag_from_url() {
  local raw_url="$1"
  local cleaned

  cleaned="$(printf '%s' "$raw_url" | tr -d '\r\n')"
  cleaned="${cleaned%%\?*}"
  cleaned="${cleaned%%#*}"
  cleaned="${cleaned%/}"

  case "$cleaned" in
    *"/releases/tag/"*)
      printf '%s\n' "${cleaned##*/}"
      return 0
      ;;
  esac

  return 1
}

resolve_latest_release_url() {
  local repo_slug="$1"
  local latest_url effective_url

  if [ -z "$repo_slug" ]; then
    return 1
  fi

  latest_url="https://github.com/${repo_slug}/releases/latest"

  if command -v curl >/dev/null 2>&1; then
    effective_url="$(curl -fsSL -o /dev/null -w '%{url_effective}' "$latest_url" || true)"
    if [ -n "$effective_url" ]; then
      printf '%s\n' "$effective_url"
      return 0
    fi
  fi

  if command -v wget >/dev/null 2>&1; then
    effective_url="$(wget --max-redirect=20 --server-response --spider "$latest_url" 2>&1 | tr -d '\r' | sed -n 's/^  Location: //p' | tail -n 1)"
    if [ -n "$effective_url" ]; then
      printf '%s\n' "$effective_url"
      return 0
    fi
  fi

  return 1
}

resolve_latest_release_tag_via_redirect() {
  local repo_slug="$1"
  local effective_url release_tag

  effective_url="$(resolve_latest_release_url "$repo_slug" || true)"
  if [ -z "$effective_url" ]; then
    return 1
  fi

  release_tag="$(extract_release_tag_from_url "$effective_url" || true)"
  if [ -z "$release_tag" ] || ! printf '%s' "$release_tag" | grep -Eq '^v[0-9]'; then
    return 1
  fi

  printf '%s\n' "$release_tag"
}

fetch_release_asset_sidecar_digest() {
  local asset_url="$1"
  local asset_name="$2"
  local dgst_url dgst_file digest

  if [ -z "$asset_url" ] || [ -z "$asset_name" ]; then
    return 1
  fi

  dgst_url="${asset_url}.dgst"
  dgst_file="/tmp/release-asset-$(basename "$asset_name").dgst"
  rm -f "$dgst_file"

  if ! download_file_with_fallback "$dgst_url" "$dgst_file" "${asset_name} digest"; then
    rm -f "$dgst_file"
    return 1
  fi

  digest="$(extract_sha256_digest_from_text "$asset_name" <"$dgst_file" 2>/dev/null || true)"
  rm -f "$dgst_file"

  normalize_sha256_digest "$digest"
}

resolve_release_asset() {
  local release_json="$1"
  local repo_slug="$2"
  local release_tag="$3"
  local asset_name="$4"
  local asset_url

  RELEASE_ASSET_URL=""
  RELEASE_ASSET_DIGEST=""
  RELEASE_ASSET_NAME=""

  if lookup_release_asset "$release_json" "$asset_name"; then
    return 0
  fi

  asset_url="$(build_github_release_asset_url "$repo_slug" "$release_tag" "$asset_name" || true)"
  if [ -z "$asset_url" ]; then
    return 1
  fi

  if ! RELEASE_ASSET_DIGEST="$(fetch_release_asset_sidecar_digest "$asset_url" "$asset_name")"; then
    RELEASE_ASSET_URL=""
    RELEASE_ASSET_DIGEST=""
    return 1
  fi

  RELEASE_ASSET_URL="$asset_url"
  RELEASE_ASSET_NAME="$asset_name"
  return 0
}

resolve_mihomo_release_asset() {
  local release_json="$1"
  local release_tag="$2"
  local mihomo_arch="$3"
  local candidate

  RELEASE_ASSET_URL=""
  RELEASE_ASSET_DIGEST=""
  RELEASE_ASSET_NAME=""

  if lookup_mihomo_release_asset "$release_json" "$mihomo_arch" "$release_tag"; then
    return 0
  fi

  case "$mihomo_arch" in
    amd64)
      for candidate in \
        "mihomo-linux-amd64-v1-${release_tag}.gz" \
        "mihomo-linux-amd64-compatible-${release_tag}.gz" \
        "mihomo-linux-amd64-${release_tag}.gz"; do
        if resolve_release_asset "" "MetaCubeX/mihomo" "$release_tag" "$candidate"; then
          return 0
        fi
      done
      ;;
    arm64)
      for candidate in \
        "mihomo-linux-arm64-v8-${release_tag}.gz" \
        "mihomo-linux-arm64-${release_tag}.gz" \
        "mihomo-linux-aarch64-${release_tag}.gz"; do
        if resolve_release_asset "" "MetaCubeX/mihomo" "$release_tag" "$candidate"; then
          return 0
        fi
      done
      ;;
  esac

  return 1
}

verify_downloaded_asset_sha256() {
  local file="$1"
  local expected_digest="$2"
  local label="$3"
  local expected actual

  if ! expected="$(normalize_sha256_digest "$expected_digest")"; then
    log_error "${label} 缺少可校验的 SHA-256 摘要，已拒绝继续安装。"
    return 1
  fi

  if ! actual="$(compute_file_sha256 "$file")"; then
    log_error "无法计算 ${label} 的 SHA-256 摘要，请确认系统已安装 sha256sum/shasum/openssl。"
    return 1
  fi

  if [ "$actual" != "$expected" ]; then
    log_error "${label} SHA-256 校验失败。"
    log_error "期望值: ${expected}"
    log_error "实际值: ${actual}"
    return 1
  fi

  log_info "${label} SHA-256 校验通过。"
  return 0
}

is_valid_port_number() {
  local port="$1"
  [[ "$port" =~ ^[0-9]{1,5}$ ]] && [ "$port" -ge 1 ] && [ "$port" -le 65535 ]
}

get_configured_ssh_port() {
  local port
  port="$(read_cfg "SSH_PORT" | tr -d '\r\n ')"
  if is_valid_port_number "$port"; then
    echo "$port"
  else
    echo "22"
  fi
}

describe_ssh_port_policy() {
  local ssh_port
  ssh_port="$(get_configured_ssh_port)"
  if [ "$ssh_port" = "22" ]; then
    echo "22 保持开放"
  else
    echo "${ssh_port}（22 已关闭）"
  fi
}

is_reserved_ssh_port() {
  local port="$1"
  if [ "$port" = "80" ] || [ "$port" = "443" ]; then
    return 0
  fi
  if [ -n "${NEZHA_DASHBOARD_PORT:-}" ] && [ "$port" = "${NEZHA_DASHBOARD_PORT}" ]; then
    return 0
  fi
  if [ -n "${PANEL_PORT:-}" ] && [ "$port" = "${PANEL_PORT}" ]; then
    return 0
  fi
  if [ -n "${FALLBACK_PORT:-}" ] && [ "$port" = "${FALLBACK_PORT}" ]; then
    return 0
  fi
  return 1
}

ssh_set_option() {
  local file="$1"
  local key="$2"
  local value="$3"
  if grep -Eq "^[#[:space:]]*${key}[[:space:]]+" "$file"; then
    sed -i -E "s|^[#[:space:]]*${key}[[:space:]].*|${key} ${value}|g" "$file"
  else
    printf '\n%s %s\n' "$key" "$value" >> "$file"
  fi
}

ssh_has_authorized_keys() {
  local sudo_home=""
  local file
  shopt -s nullglob
  if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
    sudo_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
  fi

  for file in \
    /root/.ssh/authorized_keys \
    /home/*/.ssh/authorized_keys \
    /etc/ssh/authorized_keys.d/* \
    "${sudo_home}/.ssh/authorized_keys"
  do
    if [ -n "$file" ] && [ -s "$file" ]; then
      shopt -u nullglob
      return 0
    fi
  done

  shopt -u nullglob
  return 1
}

ssh_validate_config() {
  local ssh_config="$1"
  local sshd_bin=""

  if command -v sshd >/dev/null 2>&1; then
    sshd_bin="$(command -v sshd)"
  elif [ -x /usr/sbin/sshd ]; then
    sshd_bin="/usr/sbin/sshd"
  fi

  if [ -z "$sshd_bin" ]; then
    log_warn "未找到 sshd 可执行文件，跳过 SSH 配置语法校验。"
    return 0
  fi

  "$sshd_bin" -t -f "$ssh_config" >/dev/null 2>&1
}

restart_ssh_service() {
  systemctl restart sshd >/dev/null 2>&1 || systemctl restart ssh >/dev/null 2>&1
}

apply_ssh_runtime_config() {
  local target_port="$1"
  local ssh_config="/etc/ssh/sshd_config"
  local backup_path=""

  if [ ! -f "$ssh_config" ]; then
    log_warn "未找到 sshd_config，跳过 SSH 配置更新。"
    return 1
  fi

  backup_path="${ssh_config}.bak.$(date +%s)"
  cp "$ssh_config" "$backup_path"
  ssh_set_option "$ssh_config" "PermitRootLogin" "prohibit-password"
  ssh_set_option "$ssh_config" "PubkeyAuthentication" "yes"
  ssh_set_option "$ssh_config" "Port" "$target_port"

  if ssh_has_authorized_keys; then
    ssh_set_option "$ssh_config" "PasswordAuthentication" "no"
    ssh_set_option "$ssh_config" "KbdInteractiveAuthentication" "no"
    ssh_set_option "$ssh_config" "ChallengeResponseAuthentication" "no"
    log_info "已检测到 SSH 公钥，默认禁用密码登录，仅保留密钥登录。"
  else
    log_warn "未检测到可用的 authorized_keys，暂不强制关闭密码登录，避免把当前机器锁死。"
    log_warn "请先写入 SSH 公钥，再手动执行：PasswordAuthentication no。"
  fi

  if ! ssh_validate_config "$ssh_config"; then
    cp "$backup_path" "$ssh_config"
    log_error "sshd 配置校验失败，已回滚到变更前配置。"
    return 1
  fi

  if ! restart_ssh_service; then
    cp "$backup_path" "$ssh_config"
    restart_ssh_service || true
    log_error "SSH 服务重启失败，已回滚到变更前配置。"
    return 1
  fi

  return 0
}

harden_ssh() {
  log_step "加固 SSH 配置"
  if ! apply_ssh_runtime_config "$(get_configured_ssh_port)"; then
    log_warn "SSH 加固未完全生效，请检查 sshd_config。"
  fi
}

setup_swap() {
  log_step "配置交换分区"
  if [ "$(swapon --show | wc -l)" -gt 0 ]; then
    log_warn "已存在交换分区，跳过创建。"
    return
  fi

  fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  if ! grep -q '/swapfile' /etc/fstab; then
    echo '/swapfile none swap sw 0 0' >> /etc/fstab
  fi
  if ! grep -q '^vm.swappiness=10$' /etc/sysctl.conf; then
    echo 'vm.swappiness=10' >> /etc/sysctl.conf
  fi
  sysctl vm.swappiness=10 || true
}

enable_bbr() {
  log_step "启用 BBR"
  local kernel_major
  kernel_major="$(uname -r | cut -d. -f1)"

  if [ "${kernel_major:-0}" -lt 4 ]; then
    log_warn "内核版本低于 4.x，跳过 BBR。"
    return
  fi

  if ! grep -q '^net.core.default_qdisc=fq$' /etc/sysctl.conf; then
    echo 'net.core.default_qdisc=fq' >> /etc/sysctl.conf
  fi
  if ! grep -q '^net.ipv4.tcp_congestion_control=bbr$' /etc/sysctl.conf; then
    echo 'net.ipv4.tcp_congestion_control=bbr' >> /etc/sysctl.conf
  fi
  sysctl -p || true
}

setup_firewall() {
  log_step "配置防火墙"
  apply_firewall_profile_baseline
  firewall_block_external_ping
  firewall_reload
}

detect_firewall_tool() {
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi '^Status: active'; then
    echo "ufw"
    return
  fi

  if command -v firewall-cmd >/dev/null 2>&1 && { systemctl is-active --quiet firewalld >/dev/null 2>&1 || firewall-cmd --state >/dev/null 2>&1; }; then
    echo "firewalld"
    return
  fi

  if command -v ufw >/dev/null 2>&1; then
    echo "ufw"
    return
  fi

  if command -v firewall-cmd >/dev/null 2>&1; then
    echo "firewalld"
    return
  fi

  echo "none"
}

firewall_allow_port() {
  local port="$1"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw allow "${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --add-port="${port}/tcp" >/dev/null 2>&1 || true
      ;;
    *)
      ;;
  esac
}

firewall_remove_port() {
  local port="$1"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force delete allow "${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --remove-port="${port}/tcp" >/dev/null 2>&1 || true
      ;;
    *)
      ;;
  esac
}

cloudflare_builtin_edge_cidrs() {
  cat <<'EOF'
173.245.48.0/20
103.21.244.0/22
103.22.200.0/22
103.31.4.0/22
141.101.64.0/18
108.162.192.0/18
190.93.240.0/20
188.114.96.0/20
197.234.240.0/22
198.41.128.0/17
162.158.0.0/15
104.16.0.0/13
104.24.0.0/14
172.64.0.0/13
131.0.72.0/22
2400:cb00::/32
2606:4700::/32
2803:f800::/32
2405:b500::/32
2405:8100::/32
2a06:98c0::/29
2c0f:f248::/32
EOF
}

cloudflare_fetch_edge_cidrs() {
  local data
  if ! command -v curl >/dev/null 2>&1; then
    return 1
  fi

  data="$(
    {
      curl -fsSL --connect-timeout 5 --max-time 15 https://www.cloudflare.com/ips-v4 2>/dev/null || true
      curl -fsSL --connect-timeout 5 --max-time 15 https://www.cloudflare.com/ips-v6 2>/dev/null || true
    } | sed '/^[[:space:]]*$/d'
  )"
  if [ -z "$data" ]; then
    return 1
  fi

  printf "%s\n" "$data"
}

cloudflare_edge_cidrs() {
  cloudflare_fetch_edge_cidrs || cloudflare_builtin_edge_cidrs
}

cloudflare_cleanup_edge_cidrs() {
  {
    cloudflare_builtin_edge_cidrs
    cloudflare_fetch_edge_cidrs || true
  } | sort -u
}

firewall_remove_cloudflare_proxy_port() {
  local port="$1"
  local fw_type cidr family
  fw_type="$(detect_firewall_tool)"

  while IFS= read -r cidr; do
    [ -n "$cidr" ] || continue
    case "$fw_type" in
      ufw)
        ufw --force delete allow proto tcp from "$cidr" to any port "$port" >/dev/null 2>&1 || true
        ;;
      firewalld)
        family="ipv4"
        [[ "$cidr" == *:* ]] && family="ipv6"
        firewall-cmd --permanent --remove-rich-rule="rule family=\"${family}\" source address=\"${cidr}\" port protocol=\"tcp\" port=\"${port}\" accept" >/dev/null 2>&1 || true
        ;;
      *)
        ;;
    esac
  done < <(cloudflare_cleanup_edge_cidrs)
}

firewall_allow_cloudflare_proxy_port() {
  local port="$1"
  local fw_type cidr family
  fw_type="$(detect_firewall_tool)"

  firewall_remove_port "$port"
  firewall_remove_cloudflare_proxy_port "$port"

  while IFS= read -r cidr; do
    [ -n "$cidr" ] || continue
    case "$fw_type" in
      ufw)
        ufw allow proto tcp from "$cidr" to any port "$port" comment "Cloudflare ${port}" >/dev/null 2>&1 || true
        ;;
      firewalld)
        family="ipv4"
        [[ "$cidr" == *:* ]] && family="ipv6"
        firewall-cmd --permanent --add-rich-rule="rule family=\"${family}\" source address=\"${cidr}\" port protocol=\"tcp\" port=\"${port}\" accept" >/dev/null 2>&1 || true
        ;;
      *)
        ;;
    esac
  done < <(cloudflare_edge_cidrs)
}

firewall_restore_public_proxy_port() {
  local port="$1"
  firewall_remove_cloudflare_proxy_port "$port"
  firewall_allow_port "$port"
}

firewall_apply_cloudflare_proxy_policy() {
  local port="$1"

  if [ "$port" = "443" ] && mgr_has_direct_nezha_agent_domain; then
    firewall_restore_public_proxy_port "$port"
    log_warn "检测到独立 Nezha Agent 通信域名，443 保持公网放行；四层防火墙无法按域名区分面板和 Agent。"
    return
  fi

  firewall_allow_cloudflare_proxy_port "$port"
}

firewall_reload() {
  local fw_type
  fw_type="$(detect_firewall_tool)"
  case "$fw_type" in
    ufw)
      ufw --force reload >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --reload >/dev/null 2>&1 || true
      ;;
    *)
      ;;
  esac
}

restore_http_firewall_policy() {
  local mode
  mode="$(read_cfg "NGINX_MODE" | tr '[:upper:]' '[:lower:]')"

  if [ "$mode" = "http" ]; then
    if is_cloudflare_proxy_only_enabled; then
      firewall_apply_cloudflare_proxy_policy 80
    else
      firewall_restore_public_proxy_port 80
    fi
  else
    firewall_remove_port 80
    firewall_remove_cloudflare_proxy_port 80
  fi

  firewall_reload
}

firewall_apply_ssh_policy() {
  local fw_type
  local ssh_port
  fw_type="$(detect_firewall_tool)"
  ssh_port="$(get_configured_ssh_port)"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ufw allow "${ssh_port}/tcp" >/dev/null 2>&1 || true
      if [ "$ssh_port" != "22" ]; then
        ufw --force delete allow 22/tcp >/dev/null 2>&1 || true
        ufw --force delete allow proto tcp from any to any port 22 >/dev/null 2>&1 || true
      fi
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-port="${ssh_port}/tcp" >/dev/null 2>&1 || true
      if [ "$ssh_port" = "22" ]; then
        firewall-cmd --permanent --add-service=ssh >/dev/null 2>&1 || true
      else
        firewall-cmd --permanent --remove-service=ssh >/dev/null 2>&1 || true
        firewall-cmd --permanent --remove-port=22/tcp >/dev/null 2>&1 || true
      fi
      ;;
    *)
      ;;
  esac
}

firewall_block_external_ping() {
  local fw_type sysctl_file
  if ! is_ping_block_enabled; then
    return
  fi

  fw_type="$(detect_firewall_tool)"
  sysctl_file="/etc/sysctl.d/99-xray-disable-ping.conf"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-icmp-block=echo-request >/dev/null 2>&1 || true
      ;;
    *)
      ;;
  esac

  if [ -d /etc/sysctl.d ]; then
    cat > "$sysctl_file" <<'EOF'
# Managed by xray-backend installer.
net.ipv4.icmp_echo_ignore_all = 1
EOF
    if [ -f /proc/sys/net/ipv6/icmp/echo_ignore_all ]; then
      echo 'net.ipv6.icmp.echo_ignore_all = 1' >> "$sysctl_file"
    fi
  fi

  if [ -f /proc/sys/net/ipv4/icmp_echo_ignore_all ]; then
    echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null || true
  fi
  if [ -f /proc/sys/net/ipv6/icmp/echo_ignore_all ]; then
    echo 1 > /proc/sys/net/ipv6/icmp/echo_ignore_all 2>/dev/null || true
  fi
  sysctl -w net.ipv4.icmp_echo_ignore_all=1 >/dev/null 2>&1 || true
  sysctl -w net.ipv6.icmp.echo_ignore_all=1 >/dev/null 2>&1 || true
}

apply_firewall_profile_baseline() {
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force enable
      ufw default deny incoming
      ufw default allow outgoing
      ufw allow 443/tcp comment 'HTTPS'
      firewall_allow_port "${PANEL_PORT}"
      firewall_remove_port "${FALLBACK_PORT}"
      firewall_apply_ssh_policy
      ufw --force reload
      ;;
    firewalld)
      systemctl start firewalld
      systemctl enable firewalld
      firewall-cmd --permanent --add-port=443/tcp
      firewall_allow_port "${PANEL_PORT}"
      firewall_remove_port "${FALLBACK_PORT}"
      firewall_apply_ssh_policy
      firewall-cmd --reload
      ;;
    *)
      log_warn "未检测到受支持的防火墙工具。"
      ;;
  esac
}

mgr_apply_firewall_for_mode() {
  local mode="$1"
  local fw_type
  fw_type="$(detect_firewall_tool)"

  case "$fw_type" in
    ufw)
      ufw --force enable >/dev/null 2>&1 || true
      ufw default deny incoming >/dev/null 2>&1 || true
      ufw default allow outgoing >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      ;;
    *)
      log_warn "未检测到防火墙工具，跳过端口加固。"
      return
      ;;
  esac

  firewall_apply_ssh_policy

  case "$mode" in
    tls)
      if is_cloudflare_proxy_only_enabled; then
        firewall_apply_cloudflare_proxy_policy 443
      else
        firewall_restore_public_proxy_port 443
      fi
      firewall_remove_port "${FALLBACK_PORT}"
      firewall_remove_port 80
      firewall_remove_cloudflare_proxy_port 80
      firewall_remove_port "${PANEL_PORT}"
      ;;
    reality)
      if is_cloudflare_proxy_only_enabled; then
        firewall_apply_cloudflare_proxy_policy 443
      else
        firewall_restore_public_proxy_port 443
      fi
      firewall_remove_port 80
      firewall_remove_cloudflare_proxy_port 80
      firewall_remove_port "${FALLBACK_PORT}"
      firewall_remove_port "${PANEL_PORT}"
      ;;
    http)
      if is_cloudflare_proxy_only_enabled; then
        firewall_apply_cloudflare_proxy_policy 80
      else
        firewall_restore_public_proxy_port 80
      fi
      firewall_remove_port 443
      firewall_remove_cloudflare_proxy_port 443
      firewall_remove_port "${FALLBACK_PORT}"
      firewall_remove_port "${PANEL_PORT}"
      ;;
    *)
      return
      ;;
  esac

  firewall_block_external_ping

  if [ "$fw_type" = "ufw" ]; then
    ufw --force reload >/dev/null 2>&1 || true
  elif [ "$fw_type" = "firewalld" ]; then
    firewall-cmd --reload >/dev/null 2>&1 || true
  fi
}

mgr_restore_panel_direct_access() {
  local fw_type
  fw_type="$(detect_firewall_tool)"
  if [ "$fw_type" = "none" ]; then
    log_info "Nginx 停止后，面板恢复为 2053 端口直连；如有云防火墙，请同步放行 ${PANEL_PORT}/tcp。"
    return
  fi

  firewall_allow_port "${PANEL_PORT}"
  if [ "$fw_type" = "ufw" ]; then
    ufw --force reload >/dev/null 2>&1 || true
  else
    firewall-cmd --reload >/dev/null 2>&1 || true
  fi
  log_info "Nginx 停止后，已恢复面板直连端口 ${PANEL_PORT} 的公网访问。"
}

setup_fail2ban() {
  log_step "配置 Fail2ban"
  if ! command -v fail2ban-client >/dev/null 2>&1; then
    log_warn "未安装 Fail2ban，跳过配置。"
    return
  fi

  local ssh_log="/var/log/auth.log"
  local fw_type fail2ban_banaction ssh_port
  local auth_findtime=3600
  local auth_maxretry=5
  local auth_bantime=604800
  local auth_ports="http,https,${PANEL_PORT}"
  ssh_port="$(get_configured_ssh_port)"
  if [ "$OS" = "centos" ] && [ -f /var/log/secure ]; then
    ssh_log="/var/log/secure"
  fi

  mkdir -p /etc/fail2ban/filter.d
  mkdir -p /etc/fail2ban/action.d
  mkdir -p /etc/fail2ban/jail.d
  mkdir -p /var/log/nginx
  touch /var/log/nginx/access.log

  fw_type="$(detect_firewall_tool)"
  case "$fw_type" in
    ufw)
      fail2ban_banaction="ufw"
      ;;
    firewalld)
      fail2ban_banaction="firewallcmd-rich-rules"
      ;;
    *)
      fail2ban_banaction="iptables-multiport"
      ;;
  esac

  cat > /usr/local/bin/xray-fail2ban-daily-report.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
DB_FILE="${DB_FILE:-/opt/xray-backend/data.db}"
STATE_DIR="${STATE_DIR:-/var/lib/xray-backend}"
STATE_FILE="${STATE_DIR}/daily-report.state"

read_cfg() {
  local key="$1"
  [[ "$key" =~ ^[A-Z0-9_]+$ ]] || return
  if [ -f "$CONFIG_FILE" ]; then
    grep "^${key}=" "$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

escape_html() {
  local s="$1"
  s="${s//&/&amp;}"
  s="${s//</&lt;}"
  s="${s//>/&gt;}"
  printf "%s" "$s"
}

format_bytes() {
  local value="$1"
  local units=("B" "KB" "MB" "GB" "TB")
  local index=0
  local display="$value"
  while [ "$display" -ge 1024 ] && [ "$index" -lt 4 ]; do
    display=$((display / 1024))
    index=$((index + 1))
  done
  printf "%s %s" "$display" "${units[$index]}"
}

token="$(read_cfg "TG_BOT_TOKEN" | tr -d '\r\n')"
chat_id="$(read_cfg "TG_CHAT_ID" | tr -d '\r\n')"
vps_name="$(read_cfg "VPS_DISPLAY_NAME" | tr -d '\r\n')"
host_name="$(hostname 2>/dev/null | tr -d '\r\n' || true)"
public_ip="$(read_cfg "PUBLIC_IP" | tr -d '\r\n')"
if [ -z "$token" ] || [ -z "$chat_id" ]; then
  exit 0
fi
if [ -z "$vps_name" ]; then
  vps_name="${host_name:-unknown}"
fi
if [ -z "$host_name" ]; then
  host_name="unknown"
fi

mkdir -p "$STATE_DIR"

ban_lines="$(journalctl -u fail2ban --since '24 hours ago' --no-pager -o cat 2>/dev/null | grep -E '\] Ban ' || true)"
ban_events="$(printf "%s\n" "$ban_lines" | sed '/^[[:space:]]*$/d' | wc -l | tr -d ' ')"
ban_unique="$(printf "%s\n" "$ban_lines" | sed -n 's/.* Ban \([0-9A-Fa-f:.]\+\).*/\1/p' | sed '/^[[:space:]]*$/d' | sort -u | wc -l | tr -d ' ')"

if ! [[ "$ban_events" =~ ^[0-9]+$ ]]; then
  ban_events="0"
fi
if ! [[ "$ban_unique" =~ ^[0-9]+$ ]]; then
  ban_unique="0"
fi

current_total_bytes="0"
if command -v sqlite3 >/dev/null 2>&1 && [ -f "$DB_FILE" ]; then
  current_total_bytes="$(sqlite3 "$DB_FILE" 'SELECT COALESCE(SUM(up_time + down_time), 0) FROM inbounds;' 2>/dev/null | tr -d '\r\n ' || true)"
fi
if ! [[ "$current_total_bytes" =~ ^[0-9]+$ ]]; then
  current_total_bytes="0"
fi

previous_total_bytes="0"
if [ -f "$STATE_FILE" ]; then
  previous_total_bytes="$(sed -n 's/^TOTAL_BYTES=//p' "$STATE_FILE" | head -n 1 | tr -d '\r\n ' || true)"
fi
if ! [[ "$previous_total_bytes" =~ ^[0-9]+$ ]]; then
  previous_total_bytes="0"
fi

yesterday_bytes=$((current_total_bytes - previous_total_bytes))
if [ "$yesterday_bytes" -lt 0 ]; then
  yesterday_bytes=0
fi
printf 'TOTAL_BYTES=%s\n' "$current_total_bytes" > "$STATE_FILE"

safe_name="$(escape_html "$vps_name")"
safe_host="$(escape_html "$host_name")"
safe_public_ip="$(escape_html "${public_ip:-未配置}")"
safe_time="$(escape_html "$(date '+%F %T %z')")"
safe_unique="$(escape_html "$ban_unique")"
safe_events="$(escape_html "$ban_events")"
safe_traffic="$(escape_html "$(format_bytes "$yesterday_bytes")")"

msg="<b>[日报] 昨日节点摘要</b>
节点名称: <code>${safe_name}</code>
主机名: <code>${safe_host}</code>
公网 IP: <code>${safe_public_ip}</code>
昨日流量: <code>${safe_traffic}</code>
Fail2ban 封禁 IP 数: <code>${safe_unique}</code>
Fail2ban 封禁事件数: <code>${safe_events}</code>
统计时间: ${safe_time}"

curl -fsS --max-time 10 "https://api.telegram.org/bot${token}/sendMessage" \
  -d "chat_id=${chat_id}" \
  -d "disable_web_page_preview=true" \
  -d "parse_mode=HTML" \
  --data-urlencode "text=${msg}" >/dev/null || true
EOF
  chmod +x /usr/local/bin/xray-fail2ban-daily-report.sh

  cat > /etc/systemd/system/xray-fail2ban-daily-report.service <<EOF
[Unit]
Description=Xray Fail2ban Daily Telegram Summary
After=network-online.target fail2ban.service
Wants=network-online.target

[Service]
Type=oneshot
User=root
ExecStart=/usr/local/bin/xray-fail2ban-daily-report.sh
Environment=CONFIG_FILE=${CONFIG_FILE}
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=-/var/lib/xray-backend
RestrictSUIDSGID=true
LockPersonality=true
EOF

  cat > /etc/systemd/system/xray-fail2ban-daily-report.timer <<'EOF'
[Unit]
Description=Send Xray fail2ban summary once daily at random time between 05:00 and 09:00

[Timer]
OnCalendar=*-*-* 05:00:00
RandomizedDelaySec=4h
Persistent=true
Unit=xray-fail2ban-daily-report.service

[Install]
WantedBy=timers.target
EOF

  cat > /etc/fail2ban/filter.d/xray-panel-auth.conf <<'EOF'
[Definition]
# Match repeated auth failures against panel login endpoints proxied by nginx.
# Example:
# 1.2.3.4 - - [02/Mar/2026:20:10:10 +0000] "POST /<prefix>/api/login HTTP/1.1" 401 ...
failregex = ^<HOST> - .* "POST [^"]*/api/(?:login|verify-2fa)(?:\?[^"]*)? HTTP/[0-9.]+" (?:401|429) \d+.*$
ignoreregex =
EOF

  cat > /etc/fail2ban/filter.d/xray-panel-auth-backend.conf <<'EOF'
[Definition]
# Match repeated auth failures against the backend's own Gin access logs.
# Example:
# [GIN] 2026/03/19 - 01:00:00 | 401 |  1.23ms | 1.2.3.4 | POST "/<prefix>/api/login"
failregex = ^\[GIN\].*\| (?:401|429) \|.*\| <HOST> \| POST ".*\/api\/(?:login|verify-2fa)(?:\?[^"]*)?"$
ignoreregex =
EOF

  cat > /etc/fail2ban/filter.d/xray-https-probe.conf <<'EOF'
[Definition]
# Match repeated direct 443 probes that are dropped by nginx with 444.
# Example:
# 1.2.3.4 - - [02/Mar/2026:20:10:10 +0000] "GET / HTTP/1.1" 444 0 "-" "curl/8.0.0"
failregex = ^<HOST> - .* "[A-Z]+ [^"]* HTTP/[0-9.]+" 444 \d+.*$
ignoreregex =
EOF

  remove_fail2ban_jail_from_local() {
    local jail_name="$1"
    if [ ! -f /etc/fail2ban/jail.local ] || ! grep -q "^\[${jail_name}\]$" /etc/fail2ban/jail.local; then
      return
    fi

    awk -v target="$jail_name" '
      BEGIN { skip = 0 }
      $0 == "[" target "]" { skip = 1; next }
      skip && /^\[/ { skip = 0 }
      !skip { print }
    ' /etc/fail2ban/jail.local > /etc/fail2ban/jail.local.xray-backend.tmp && \
      mv /etc/fail2ban/jail.local.xray-backend.tmp /etc/fail2ban/jail.local
  }

  remove_fail2ban_jail_from_local "xray-panel-auth"
  remove_fail2ban_jail_from_local "xray-panel-auth-web"
  remove_fail2ban_jail_from_local "xray-panel-auth-backend"
  remove_fail2ban_jail_from_local "xray-https-probe"

  cat > /etc/fail2ban/jail.d/xray-panel.local <<EOF
[sshd]
enabled = true
port = ${ssh_port}
logpath = ${ssh_log}
maxretry = 5
findtime = 3600
bantime = 604800
banaction = ${fail2ban_banaction}
action = %(banaction)s[port="%(port)s", protocol=tcp]

[xray-panel-auth-web]
enabled = true
filter = xray-panel-auth
port = ${auth_ports}
logpath = /var/log/nginx/access.log
maxretry = ${auth_maxretry}
findtime = ${auth_findtime}
bantime = ${auth_bantime}
banaction = ${fail2ban_banaction}
action = %(banaction)s[port="%(port)s", protocol=tcp]

[xray-panel-auth-backend]
enabled = true
filter = xray-panel-auth-backend
backend = systemd
journalmatch = _SYSTEMD_UNIT=xray-backend.service
port = ${auth_ports}
maxretry = ${auth_maxretry}
findtime = ${auth_findtime}
bantime = ${auth_bantime}
banaction = ${fail2ban_banaction}
action = %(banaction)s[port="%(port)s", protocol=tcp]

[xray-https-probe]
enabled = true
filter = xray-https-probe
port = https,443
logpath = /var/log/nginx/access.log
maxretry = 5
findtime = 3600
bantime = 604800
banaction = ${fail2ban_banaction}
action = %(banaction)s[port="%(port)s", protocol=tcp]
EOF

  rm -f /usr/local/bin/xray-fail2ban-tg.sh
  rm -f /etc/fail2ban/action.d/xray-tg.conf

  systemctl daemon-reload || true
  systemctl enable fail2ban || true
  systemctl restart fail2ban || true
  systemctl enable xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
  systemctl restart xray-fail2ban-daily-report.timer >/dev/null 2>&1 || true
}

set_timezone() {
  log_step "Setting timezone"
  timedatectl set-timezone Asia/Shanghai || true
}

install_xray_core() {
  log_step "Installing Xray core"
  local xray_release_json=""
  local xray_asset_name=""
  local xray_url=""
  local xray_zip="/tmp/xray-core-${XRAY_ARCH}.zip"
  local unzip_log="/tmp/xray-core-unzip.log"

  if [ -z "$XRAY_ARCH" ]; then
    log_error "未识别到可用的 Xray 架构标识，无法继续安装核心。"
    return 1
  fi
  if ! command -v python3 >/dev/null 2>&1; then
    log_error "未找到 python3，无法安全解析 Xray Release 元数据。"
    return 1
  fi

  xray_asset_name="Xray-linux-${XRAY_ARCH}.zip"
  xray_release_json="$(curl -fsSL -H 'Accept: application/vnd.github+json' -H 'User-Agent: xray-backend-installer' https://api.github.com/repos/XTLS/Xray-core/releases/latest || true)"
  XRAY_VERSION="$(printf '%s' "$xray_release_json" | extract_release_tag_name 2>/dev/null || true)"
  if [ -z "$XRAY_VERSION" ] || ! printf '%s' "$XRAY_VERSION" | grep -Eq '^v[0-9]'; then
    XRAY_VERSION="$(resolve_latest_release_tag_via_redirect "XTLS/Xray-core" || true)"
    xray_release_json=""
  fi
  if [ -z "$XRAY_VERSION" ] || ! printf '%s' "$XRAY_VERSION" | grep -Eq '^v[0-9]'; then
    log_error "无法确认 Xray 最新稳定版版本号（GitHub API 与 releases/latest 重定向均失败），已停止安装。"
    return 1
  fi
  if ! resolve_release_asset "$xray_release_json" "XTLS/Xray-core" "$XRAY_VERSION" "$xray_asset_name"; then
    log_error "无法获取 Xray 最新稳定版 ${XRAY_VERSION} 的 ${xray_asset_name} 下载地址或 SHA-256 摘要，已停止安装。"
    return 1
  fi

  xray_url="$RELEASE_ASSET_URL"

  log_info "准备安装 Xray core 版本: ${XRAY_VERSION}"
  log_info "下载地址: ${xray_url}"

  if ! download_file_with_fallback "$xray_url" "$xray_zip" "Xray core"; then
    log_error "Xray core 下载失败，请检查服务器网络或稍后重试。"
    return 1
  fi
  if ! verify_downloaded_asset_sha256 "$xray_zip" "$RELEASE_ASSET_DIGEST" "Xray core"; then
    rm -f "$xray_zip" "$unzip_log"
    return 1
  fi

  if ! unzip -o "$xray_zip" -d /usr/local/bin/ >"$unzip_log" 2>&1; then
    log_error "Xray core 解压失败。"
    tail -n 20 "$unzip_log" 2>/dev/null || true
    rm -f "$xray_zip" "$unzip_log"
    return 1
  fi

  chmod +x /usr/local/bin/xray
  rm -f "$xray_zip" "$unzip_log"

  if [ ! -x /usr/local/bin/xray ]; then
    log_error "Xray core 安装失败，未找到 /usr/local/bin/xray。"
    return 1
  fi

  mkdir -p "$INSTALL_DIR"
  if [ -x /usr/local/bin/xray ]; then
    ln -sfn /usr/local/bin/xray "${INSTALL_DIR}/xray-core"
    log_info "已创建核心软链接: ${INSTALL_DIR}/xray-core -> /usr/local/bin/xray"
  fi
}

install_mihomo_core() {
  log_step "Installing Mihomo core (for Clash subscription compatibility)"

  local mihomo_arch=""
  local mihomo_url=""
  case "$XRAY_ARCH" in
    64) mihomo_arch="amd64" ;;
    arm64-v8a) mihomo_arch="arm64" ;;
    *)
      log_error "未识别到可用的 Mihomo 架构标识，无法保证安装最新稳定版。"
      return 1
      ;;
  esac

  local mihomo_release_json
  mihomo_release_json="$(curl -fsSL -H 'Accept: application/vnd.github+json' -H 'User-Agent: xray-backend-installer' https://api.github.com/repos/MetaCubeX/mihomo/releases/latest || true)"
  MIHOMO_VERSION="$(printf '%s' "$mihomo_release_json" | extract_release_tag_name 2>/dev/null || true)"
  if [ -z "$MIHOMO_VERSION" ] || ! printf '%s' "$MIHOMO_VERSION" | grep -Eq '^v[0-9]'; then
    MIHOMO_VERSION="$(resolve_latest_release_tag_via_redirect "MetaCubeX/mihomo" || true)"
    mihomo_release_json=""
  fi
  if [ -z "$MIHOMO_VERSION" ] || ! printf '%s' "$MIHOMO_VERSION" | grep -Eq '^v[0-9]'; then
    log_error "无法确认 Mihomo 最新稳定版版本号（GitHub API 与 releases/latest 重定向均失败），已停止安装。"
    return 1
  fi

  if ! resolve_mihomo_release_asset "$mihomo_release_json" "$MIHOMO_VERSION" "$mihomo_arch"; then
    log_error "无法获取 Mihomo 最新稳定版 ${MIHOMO_VERSION} 的 Linux ${mihomo_arch} 资产下载地址或 SHA-256 摘要，已停止安装。"
    return 1
  fi
  local mihomo_asset_name="$RELEASE_ASSET_NAME"
  mihomo_url="$RELEASE_ASSET_URL"

  local mihomo_gz="/tmp/mihomo-core-${mihomo_arch}.gz"
  log_info "准备安装 Mihomo 版本: ${MIHOMO_VERSION}"
  log_info "选定资产: ${mihomo_asset_name}"
  log_info "下载地址: ${mihomo_url}"
  if ! download_file_with_fallback "$mihomo_url" "$mihomo_gz" "Mihomo core"; then
    log_error "Mihomo 最新稳定版下载失败，已停止安装。"
    return 1
  fi
  if ! verify_downloaded_asset_sha256 "$mihomo_gz" "$RELEASE_ASSET_DIGEST" "Mihomo core"; then
    rm -f "$mihomo_gz"
    log_error "Mihomo 最新稳定版 SHA-256 校验失败，已停止安装。"
    return 1
  fi

  if ! gunzip -c "$mihomo_gz" >/usr/local/bin/mihomo; then
    rm -f "$mihomo_gz"
    log_error "Mihomo 最新稳定版解压失败，已停止安装。"
    return 1
  fi
  rm -f "$mihomo_gz"

  chmod +x /usr/local/bin/mihomo
  mkdir -p "$INSTALL_DIR"
  ln -sfn /usr/local/bin/mihomo "${INSTALL_DIR}/mihomo-core"
  log_info "已创建 Mihomo 软链接: ${INSTALL_DIR}/mihomo-core -> /usr/local/bin/mihomo"
}

install_nginx() {
  log_step "安装 Nginx"
  mgr_install_or_update_nginx_package

  mkdir -p /var/www/html
  cat > /var/www/html/index.html <<EOF
<!DOCTYPE html>
<html>
<head><title>Welcome</title></head>
<body><h1>Welcome to Nginx</h1><p>Server is running normally.</p></body>
</html>
EOF

  systemctl disable nginx >/dev/null 2>&1 || true
  systemctl stop nginx >/dev/null 2>&1 || true
  log_info "Nginx 已安装但尚未启动，可在管理菜单里启动并选择模式。"
}

write_backend_service_unit() {
  cat > /etc/systemd/system/xray-backend.service <<EOF
[Unit]
Description=Xray Backend Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/${BIN_NAME}
Restart=on-failure
RestartSec=5s
LimitNOFILE=65535
LimitNPROC=65535
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=${INSTALL_DIR} /etc/certs /etc/nginx /etc/systemd/system -/etc/ufw -/etc/firewalld -/etc/sysconfig -/var/www/xray-camouflage -/var/log/nginx -/var/log/xray-tg-access-local -/var/lib/xray-backend
RestrictSUIDSGID=true
LockPersonality=true

[Install]
WantedBy=multi-user.target
EOF
}

install_backend_binary() {
  local binary_path="${SCRIPT_DIR}/${BINARY}"
  local target_path="${INSTALL_DIR}/${BIN_NAME}"
  local temp_path="${target_path}.new.$$"

  mkdir -p "$INSTALL_DIR"
  install -m 755 "$binary_path" "$temp_path"
  mv -f "$temp_path" "$target_path"
}

install_backend_service() {
  log_step "安装后端服务"

  install_backend_binary

  init_runtime_config
  install_packaged_panel_site
  install_packaged_camouflage_site
  mkdir -p /etc/certs
  chmod 755 /etc/certs
  write_backend_service_unit

  systemctl daemon-reload
  systemctl enable xray-backend
  systemctl restart xray-backend
  sync_ssl_renewal_timer
  sleep 2
}

disable_acme_cron_job() {
  local current_cron filtered_cron

  if ! command -v crontab >/dev/null 2>&1; then
    return
  fi

  current_cron="$(crontab -l 2>/dev/null || true)"
  if [ -z "$current_cron" ]; then
    return
  fi

  filtered_cron="$(printf '%s\n' "$current_cron" | grep -v '[.]acme[.]sh/acme[.]sh --cron' || true)"
  if [ "$filtered_cron" = "$current_cron" ]; then
    return
  fi

  if [ -n "$filtered_cron" ]; then
    printf '%s\n' "$filtered_cron" | crontab -
  else
    crontab -r || true
  fi
}

get_ssl_issuer_tool() {
  local issuer domain key_target
  issuer="$(read_cfg "SSL_ISSUER_TOOL" | tr -d '\r\n ')"

  case "$issuer" in
    acme.sh|certbot|manual)
      echo "$issuer"
      return
      ;;
  esac

  domain="$(mgr_get_panel_domain)"
  if [ -z "$domain" ]; then
    echo ""
    return
  fi

  key_target="$(readlink "/etc/certs/${domain}.key" 2>/dev/null || true)"
  case "$key_target" in
    /etc/letsencrypt/*)
      issuer="certbot"
      ;;
  esac

  if [ -z "$issuer" ] && [ -x "$HOME/.acme.sh/acme.sh" ] && [ -f "/etc/certs/${domain}.crt" ] && [ -f "/etc/certs/${domain}.key" ]; then
    issuer="acme.sh"
  fi

  if [ -n "$issuer" ]; then
    save_cfg "SSL_ISSUER_TOOL" "$issuer"
  fi
  echo "$issuer"
}

mgr_repair_panel_certificate_links() {
  local domain="$1"
  local issuer key_target cert_target

  if [ -z "$domain" ]; then
    return 0
  fi

  mkdir -p /etc/certs
  chmod 755 /etc/certs

  issuer="$(read_cfg "SSL_ISSUER_TOOL" | tr -d '\r\n ')"
  key_target="$(readlink "/etc/certs/${domain}.key" 2>/dev/null || true)"
  cert_target="$(readlink "/etc/certs/${domain}.crt" 2>/dev/null || true)"
  if [ -f "/etc/letsencrypt/live/${domain}/privkey.pem" ] && [ -f "/etc/letsencrypt/live/${domain}/fullchain.pem" ]; then
    if [ "$issuer" = "certbot" ] ||
      [ ! -e "/etc/certs/${domain}.key" ] ||
      [ ! -e "/etc/certs/${domain}.crt" ] ||
      [[ "$key_target" == /etc/letsencrypt/* ]] ||
      [[ "$cert_target" == /etc/letsencrypt/* ]]; then
      ln -sfn "/etc/letsencrypt/live/${domain}/privkey.pem" "/etc/certs/${domain}.key"
      ln -sfn "/etc/letsencrypt/live/${domain}/fullchain.pem" "/etc/certs/${domain}.crt"
      save_cfg "SSL_ISSUER_TOOL" "certbot"
    fi
  fi

  if [ -e "/etc/certs/${domain}.crt" ] && [ ! -L "/etc/certs/${domain}.crt" ]; then
    chmod 644 "/etc/certs/${domain}.crt" >/dev/null 2>&1 || true
  fi
  if [ -e "/etc/certs/${domain}.key" ] && [ ! -L "/etc/certs/${domain}.key" ]; then
    chmod 600 "/etc/certs/${domain}.key" >/dev/null 2>&1 || true
  fi

  return 0
}

mgr_require_panel_certificate_files() {
  local domain="$1"
  local mode_label="$2"
  local cert_file="/etc/certs/${domain}.crt"
  local key_file="/etc/certs/${domain}.key"

  mgr_repair_panel_certificate_links "$domain"

  if [ ! -f "$cert_file" ] || [ ! -f "$key_file" ]; then
    log_error "${mode_label} 需要证书文件: ${cert_file} 和 ${key_file}"
    log_warn "如果使用 certbot，请确认 /etc/letsencrypt/live/${domain}/fullchain.pem 和 privkey.pem 存在。"
    log_warn "如果使用手动证书，请重新放置到 /etc/certs 后再刷新 Nginx 模式。"
    return 1
  fi

  if [ ! -r "$cert_file" ] || [ ! -r "$key_file" ]; then
    log_error "${mode_label} 证书文件存在，但当前进程不可读: ${cert_file} 或 ${key_file}"
    log_warn "请检查文件权限和符号链接目标。"
    return 1
  fi

  return 0
}

write_ssl_renewal_script() {
  cat > "${SSL_RENEW_SCRIPT}" <<EOF
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE}"
NGINX_SERVICE="${NGINX_SERVICE}"

read_cfg() {
  local key="\$1"
  [[ "\$key" =~ ^[A-Z0-9_]+$ ]] || return
  if [ -f "\$CONFIG_FILE" ]; then
    grep "^\${key}=" "\$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

detect_firewall_tool() {
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi '^Status: active'; then
    echo "ufw"
    return
  fi
  if command -v firewall-cmd >/dev/null 2>&1 && { systemctl is-active --quiet firewalld >/dev/null 2>&1 || firewall-cmd --state >/dev/null 2>&1; }; then
    echo "firewalld"
    return
  fi
  if command -v ufw >/dev/null 2>&1; then
    echo "ufw"
    return
  fi
  if command -v firewall-cmd >/dev/null 2>&1; then
    echo "firewalld"
    return
  fi
  if command -v iptables >/dev/null 2>&1; then
    echo "iptables"
    return
  fi
  echo "none"
}

firewall_allow_port() {
  local port="\$1"
  case "\$(detect_firewall_tool)" in
    ufw)
      ufw allow "\${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      systemctl start firewalld >/dev/null 2>&1 || true
      systemctl enable firewalld >/dev/null 2>&1 || true
      firewall-cmd --permanent --add-port="\${port}/tcp" >/dev/null 2>&1 || true
      ;;
    iptables)
      if ! iptables -C INPUT -p tcp --dport "\${port}" -j ACCEPT >/dev/null 2>&1; then
        iptables -I INPUT -p tcp --dport "\${port}" -j ACCEPT >/dev/null 2>&1 || true
      fi
      ;;
  esac
}

firewall_remove_port() {
  local port="\$1"
  case "\$(detect_firewall_tool)" in
    ufw)
      ufw --force delete allow "\${port}/tcp" >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --permanent --remove-port="\${port}/tcp" >/dev/null 2>&1 || true
      ;;
    iptables)
      while iptables -C INPUT -p tcp --dport "\${port}" -j ACCEPT >/dev/null 2>&1; do
        iptables -D INPUT -p tcp --dport "\${port}" -j ACCEPT >/dev/null 2>&1 || break
      done
      ;;
  esac
}

firewall_reload() {
  case "\$(detect_firewall_tool)" in
    ufw)
      ufw --force reload >/dev/null 2>&1 || true
      ;;
    firewalld)
      firewall-cmd --reload >/dev/null 2>&1 || true
      ;;
  esac
}

restore_http_policy() {
  local mode
  mode="\$(read_cfg "NGINX_MODE" | tr '[:upper:]' '[:lower:]')"
  if [ "\$mode" = "http" ]; then
    firewall_allow_port 80
  else
    firewall_remove_port 80
  fi
  firewall_reload
}

collect_certificate_domains() {
  local key domain seen=""
  for key in PANEL_DOMAIN NEZHA_DASHBOARD_DOMAIN NEZHA_AGENT_COMMUNICATION_DOMAIN; do
    domain="\$(read_cfg "\$key" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')"
    case "\$domain" in
      ""|unknown|127.0.0.1|::1|localhost)
        continue
        ;;
    esac
    if printf "%s\n" "\$seen" | grep -Fxq "\$domain"; then
      continue
    fi
    seen="\${seen}
\${domain}"
    printf "%s\n" "\$domain"
  done
}

install_domain_certificate_files() {
  local domain="\$1"
  if [ -z "\$domain" ]; then
    return 0
  fi
  mkdir -p /etc/certs
  chmod 755 /etc/certs
  if [ -f "/etc/letsencrypt/live/\${domain}/privkey.pem" ] && [ -f "/etc/letsencrypt/live/\${domain}/fullchain.pem" ]; then
    ln -sfn "/etc/letsencrypt/live/\${domain}/privkey.pem" "/etc/certs/\${domain}.key"
    ln -sfn "/etc/letsencrypt/live/\${domain}/fullchain.pem" "/etc/certs/\${domain}.crt"
  elif [ -x "\$HOME/.acme.sh/acme.sh" ]; then
    "\$HOME/.acme.sh/acme.sh" --install-cert -d "\$domain" --key-file "/etc/certs/\${domain}.key" --fullchain-file "/etc/certs/\${domain}.crt" >/dev/null 2>&1 || true
  fi
  if [ -e "/etc/certs/\${domain}.crt" ] && [ ! -L "/etc/certs/\${domain}.crt" ]; then
    chmod 644 "/etc/certs/\${domain}.crt" >/dev/null 2>&1 || true
  fi
  if [ -e "/etc/certs/\${domain}.key" ] && [ ! -L "/etc/certs/\${domain}.key" ]; then
    chmod 600 "/etc/certs/\${domain}.key" >/dev/null 2>&1 || true
  fi
}

issuer="\$(read_cfg "SSL_ISSUER_TOOL" | tr -d '\r\n ')"
domains="\$(collect_certificate_domains)"
nginx_was_active=0

cleanup() {
  restore_http_policy
  if [ "\$nginx_was_active" -eq 1 ]; then
    systemctl start "\$NGINX_SERVICE" >/dev/null 2>&1 || true
  fi
}

trap cleanup EXIT

case "\$issuer" in
  acme.sh|certbot) ;;
  *)
    exit 0
    ;;
esac

[ -n "\$domains" ] || exit 0

firewall_allow_port 80
firewall_reload

if systemctl is-active --quiet "\$NGINX_SERVICE"; then
  nginx_was_active=1
  systemctl stop "\$NGINX_SERVICE" >/dev/null 2>&1 || true
fi

case "\$issuer" in
  acme.sh)
    acme_bin="\$HOME/.acme.sh/acme.sh"
    [ -x "\$acme_bin" ] || exit 0
    "\$acme_bin" --cron --home "\$HOME/.acme.sh" >/dev/null 2>&1
    while IFS= read -r domain; do
      install_domain_certificate_files "\$domain"
    done <<DOMAINS_EOF
\$domains
DOMAINS_EOF
    ;;
  certbot)
    command -v certbot >/dev/null 2>&1 || exit 0
    certbot renew --standalone --preferred-challenges http --quiet >/dev/null 2>&1
    while IFS= read -r domain; do
      install_domain_certificate_files "\$domain"
    done <<DOMAINS_EOF
\$domains
DOMAINS_EOF
    ;;
esac

EOF

  chmod 755 "${SSL_RENEW_SCRIPT}"
}

write_ssl_renewal_service() {
  cat > "/etc/systemd/system/${SSL_RENEW_SERVICE}.service" <<EOF
[Unit]
Description=Xray SSL renew helper
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=${SSL_RENEW_SCRIPT}
EOF

  cat > "/etc/systemd/system/${SSL_RENEW_SERVICE}.timer" <<EOF
[Unit]
Description=Run Xray SSL renew helper daily

[Timer]
OnCalendar=*-*-* 03:00:00
RandomizedDelaySec=2h
Persistent=true
Unit=${SSL_RENEW_SERVICE}.service

[Install]
WantedBy=timers.target
EOF
}

sync_ssl_renewal_timer() {
  local issuer
  issuer="$(get_ssl_issuer_tool)"

  write_ssl_renewal_script
  write_ssl_renewal_service
  systemctl daemon-reload

  systemctl disable --now certbot.timer >/dev/null 2>&1 || true
  disable_acme_cron_job

  case "$issuer" in
    acme.sh|certbot)
      systemctl enable --now "${SSL_RENEW_SERVICE}.timer" >/dev/null 2>&1 || true
      ;;
    *)
      systemctl disable --now "${SSL_RENEW_SERVICE}.timer" >/dev/null 2>&1 || true
      ;;
  esac
}

install_management_tool() {
  log_step "Installing management command: xy"
  cp "${SCRIPT_DIR}/install.sh" /usr/local/bin/xy
  chmod +x /usr/local/bin/xy
  install_packaged_panel_site
  install_packaged_camouflage_site
}

require_install_child_dir() {
  local path_value="$1"
  case "$path_value" in
    "${INSTALL_DIR}/panel-site"|\
    "${INSTALL_DIR}/camouflage-site"|\
    "${INSTALL_DIR}/panel-site.stage."*|\
    "${INSTALL_DIR}/camouflage-site.stage."*)
      return 0
      ;;
    *)
      log_error "拒绝操作异常安装目录: ${path_value}"
      return 1
      ;;
  esac
}

install_packaged_panel_site() {
  local source_dir target_dir staging_dir
  source_dir="${SCRIPT_DIR}/panel-site"
  target_dir="${INSTALL_DIR}/panel-site"
  staging_dir="${target_dir}.stage.$$"

  if [ ! -d "$source_dir" ] || [ ! -f "${source_dir}/index.html" ]; then
    log_warn "未找到打包好的面板静态文件，继续使用后端内嵌面板。"
    return 0
  fi

  require_install_child_dir "$target_dir"
  require_install_child_dir "$staging_dir"
  rm -rf "$staging_dir"
  mkdir -p "$staging_dir"
  cp -R "${source_dir}/." "$staging_dir/"
  rm -rf "$target_dir"
  mv "$staging_dir" "$target_dir"
  find "$target_dir" -type d -exec chmod 755 {} \;
  find "$target_dir" -type f -exec chmod 644 {} \;
}

install_packaged_camouflage_site() {
  local source_dir target_dir staging_dir
  source_dir="${SCRIPT_DIR}/camouflage-site"
  target_dir="${INSTALL_DIR}/camouflage-site"
  staging_dir="${target_dir}.stage.$$"

  if [ ! -d "$source_dir" ] || [ ! -f "${source_dir}/index.html" ]; then
    log_warn "未找到打包好的伪装站点模板，跳过模板安装。"
    return 0
  fi

  require_install_child_dir "$target_dir"
  require_install_child_dir "$staging_dir"
  rm -rf "$staging_dir"
  mkdir -p "$staging_dir"
  cp -R "${source_dir}/." "$staging_dir/"
  rm -rf "$target_dir"
  mv "$staging_dir" "$target_dir"
  find "$target_dir" -type d -exec chmod 755 {} \;
  find "$target_dir" -type f -exec chmod 644 {} \;
}

overlay_update_main() {
  echo "=============================================="
  echo "Xray 后端覆盖更新"
  echo "=============================================="

  require_root
  detect_arch
  detect_os
  check_binary

  if [ ! -d "$INSTALL_DIR" ] || [ ! -f "${INSTALL_DIR}/data.db" ]; then
    log_error "未检测到现有安装（缺少 ${INSTALL_DIR} 或 data.db）。请改用完整安装。"
    exit 1
  fi

  local backend_target backup_dir backup_path
  backend_target="${INSTALL_DIR}/${BIN_NAME}"
  backup_dir="${INSTALL_DIR}/backups"
  backup_path=""

  init_runtime_config
  log_info "本次覆盖后端程序、管理脚本和面板静态文件。"
  log_info "将保留 data.db、config.conf、Nginx、证书、防火墙和现有博客发布内容。"
  mgr_install_or_update_nginx_package || log_warn "Nginx 官方源安装/升级失败，继续覆盖后端；稍后可在 xy 菜单中重试 Nginx 安装/更新。"

  mkdir -p /etc/certs
  chmod 755 /etc/certs
  write_backend_service_unit

  if [ -f "$backend_target" ]; then
    mkdir -p "$backup_dir"
    backup_path="${backup_dir}/${BIN_NAME}.bak.$(date +%Y%m%d%H%M%S)"
    cp -f "$backend_target" "$backup_path"
    chmod 755 "$backup_path"
  fi

  install_backend_binary
  install_management_tool
  install_weekly_auto_update
  install_cf_preferred_domains_refresh_timer
  install_packaged_panel_site
  install_packaged_camouflage_site

  systemctl daemon-reload
  systemctl enable xray-backend >/dev/null 2>&1 || true
  if ! systemctl restart xray-backend; then
    log_error "新版本后端启动失败，开始回滚旧二进制。"
    if [ -n "$backup_path" ] && [ -f "$backup_path" ]; then
      cp -f "$backup_path" "$backend_target"
      chmod 755 "$backend_target"
      systemctl daemon-reload
      systemctl restart xray-backend >/dev/null 2>&1 || true
      log_warn "已尝试恢复旧版本后端，请检查: systemctl status ${BACKEND_SERVICE}"
    fi
    exit 1
  fi

  sync_ssl_renewal_timer
  sleep 2
  mgr_refresh_active_nginx_mode || mgr_restore_panel_direct_access || true
  mgr_overlay_repair_local_blog_site_if_needed
  mgr_install_nezha_dashboard || log_warn "Nezha Dashboard 自动部署失败，可稍后在 xy 菜单中重试。"

  log_info "覆盖更新完成。"
  log_info "数据库与现有 Nginx/博客内容已保留。"
  log_info "如需确认版本和服务状态，可执行: systemctl status ${BACKEND_SERVICE}"
}

install_weekly_auto_update() {
  log_step "Installing weekly OpenSSH maintenance timer"

  cat > /usr/local/bin/xray-weekly-update.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

LOG_FILE="/var/log/xray-weekly-update.log"
LOCK_FILE="/var/lock/xray-weekly-update.lock"

exec >>"$LOG_FILE" 2>&1
echo "[$(date '+%F %T %z')] weekly OpenSSH maintenance start"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  flock -n 9 || {
    echo "[$(date '+%F %T %z')] another update is running, skip"
    exit 0
  }
fi

apt_get_update_with_retry() {
  local max_attempts="${APT_UPDATE_RETRIES:-5}"
  local base_delay="${APT_UPDATE_RETRY_DELAY_SECONDS:-5}"
  local attempt delay

  for ((attempt=1; attempt<=max_attempts; attempt++)); do
    if apt-get update -o Acquire::Retries=3 -o Acquire::http::No-Cache=true -o Acquire::ForceIPv4=true; then
      return 0
    fi

    if [ "$attempt" -ge "$max_attempts" ]; then
      break
    fi

    delay=$((base_delay * attempt))
    echo "[$(date '+%F %T %z')] apt-get update failed (attempt ${attempt}/${max_attempts}), clearing package lists and retrying in ${delay}s"
    apt-get clean || true
    rm -rf /var/lib/apt/lists/*
    mkdir -p /var/lib/apt/lists/partial
    sleep "$delay"
  done

  echo "[$(date '+%F %T %z')] apt-get update failed after ${max_attempts} attempts"
  return 1
}

update_system_packages() {
  if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    local packages=(ca-certificates)
    apt_get_update_with_retry
    dpkg-query -W -f='${Version}' openssh-server >/dev/null 2>&1 && packages+=(openssh-server)
    dpkg-query -W -f='${Version}' openssh-client >/dev/null 2>&1 && packages+=(openssh-client)
    dpkg-query -W -f='${Version}' nginx >/dev/null 2>&1 && packages+=(nginx)
    apt-get install --only-upgrade -y -o Acquire::Retries=3 -o Acquire::ForceIPv4=true "${packages[@]}" || true
  elif command -v dnf >/dev/null 2>&1; then
    local packages=(ca-certificates)
    rpm -q openssh-server >/dev/null 2>&1 && packages+=(openssh-server)
    rpm -q openssh-clients >/dev/null 2>&1 && packages+=(openssh-clients)
    rpm -q nginx >/dev/null 2>&1 && packages+=(nginx)
    dnf -y upgrade "${packages[@]}" || true
  elif command -v yum >/dev/null 2>&1; then
    local packages=(ca-certificates)
    rpm -q openssh-server >/dev/null 2>&1 && packages+=(openssh-server)
    rpm -q openssh-clients >/dev/null 2>&1 && packages+=(openssh-clients)
    rpm -q nginx >/dev/null 2>&1 && packages+=(nginx)
    yum -y update "${packages[@]}" || true
  else
    echo "No supported package manager found, skip maintenance update."
  fi
}

capture_openssh_package_state() {
  if command -v dpkg-query >/dev/null 2>&1; then
    dpkg-query -W -f='${Package}=${Version}\n' openssh-server openssh-client 2>/dev/null | sort || true
    return
  fi
  if command -v rpm >/dev/null 2>&1; then
    rpm -q --qf '%{NAME}=%{VERSION}-%{RELEASE}\n' openssh-server openssh-clients 2>/dev/null | sort || true
    return
  fi
  echo ""
}

restart_ssh_service_if_needed() {
  local before_state="$1"
  local after_state="$2"

  if [ "$before_state" = "$after_state" ]; then
    echo "[$(date '+%F %T %z')] OpenSSH packages unchanged, skip SSH restart"
    return 0
  fi

  echo "[$(date '+%F %T %z')] OpenSSH packages changed, restarting SSH service"
  systemctl try-restart sshd 2>/dev/null || systemctl try-restart ssh 2>/dev/null || true
}

before_ssh_state="$(capture_openssh_package_state)"
update_system_packages
after_ssh_state="$(capture_openssh_package_state)"
restart_ssh_service_if_needed "$before_ssh_state" "$after_ssh_state"

echo "[$(date '+%F %T %z')] weekly OpenSSH maintenance done"
EOF
  chmod +x /usr/local/bin/xray-weekly-update.sh

  cat > /etc/systemd/system/xray-weekly-update.service <<'EOF'
[Unit]
Description=Xray Weekly OpenSSH Maintenance Update
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/xray-weekly-update.sh
Nice=10
EOF

  cat > /etc/systemd/system/xray-weekly-update.timer <<'EOF'
[Unit]
Description=Run weekly OpenSSH maintenance update

[Timer]
OnBootSec=20min
OnUnitActiveSec=7d
RandomizedDelaySec=30min
Persistent=true
Unit=xray-weekly-update.service

[Install]
WantedBy=timers.target
EOF

  systemctl daemon-reload
  systemctl enable --now xray-weekly-update.timer
}

install_cf_preferred_domains_refresh_timer() {
  cat > /usr/local/bin/xray-cf-preferred-refresh.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
LOG_FILE="/var/log/xray-cf-preferred-refresh.log"
LOCK_FILE="/var/lock/xray-cf-preferred-refresh.lock"

mkdir -p "$(dirname "$LOG_FILE")" "$(dirname "$LOCK_FILE")"
exec >>"$LOG_FILE" 2>&1
echo "[$(date '+%F %T %z')] Cloudflare preferred CMCC addresses refresh start"

if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  flock -n 9 || {
    echo "[$(date '+%F %T %z')] another refresh is running, skip"
    exit 0
  }
fi

read_cfg() {
  local key="$1"
  [ -f "$CONFIG_FILE" ] || return 0
  grep -E "^${key}=" "$CONFIG_FILE" | tail -n 1 | cut -d= -f2-
}

is_valid_ipv4() {
  local ip="$1" octet
  local -a octets
  [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  IFS='.' read -r -a octets <<< "$ip"
  for octet in "${octets[@]}"; do
    [ "$octet" -le 255 ] || return 1
  done
  return 0
}

normalize_preferred_host() {
  local host="$1" maybe_port
  host="$(printf "%s" "$host" | tr -d '\r\n\t ' | tr '[:upper:]' '[:lower:]')"
  host="${host#http://}"
  host="${host#https://}"
  host="${host%%/*}"
  host="${host%%\?*}"
  host="${host%%#*}"
  if [[ "$host" =~ ^\[([0-9a-f:]+)\]:([0-9]{1,5})$ ]]; then
    maybe_port="${BASH_REMATCH[2]}"
    [ "$maybe_port" -ge 1 ] && [ "$maybe_port" -le 65535 ] || return 0
    host="${BASH_REMATCH[1]}"
  fi
  host="${host#[}"
  host="${host%]}"
  if [[ "$host" =~ ^(.+):([0-9]{1,5})$ ]] && [[ "${BASH_REMATCH[1]}" != *:* ]]; then
    maybe_port="${BASH_REMATCH[2]}"
    [ "$maybe_port" -ge 1 ] && [ "$maybe_port" -le 65535 ] || return 0
    host="${BASH_REMATCH[1]}"
  fi
  if is_valid_ipv4 "$host"; then
    printf "%s" "$host"
    return
  fi
  if [[ "$host" =~ ^[0-9a-f]{0,4}: ]] && [[ "$host" == *:* ]]; then
    python3 - "$host" <<'PY' 2>/dev/null || true
import ipaddress
import sys
try:
    ip = ipaddress.ip_address(sys.argv[1])
except ValueError:
    sys.exit(0)
print(ip.compressed)
PY
    return
  fi
  if [[ "$host" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
    printf "%s" "$host"
  fi
}

extract_preferred_hosts() {
  {
    grep -Eo '(\[[0-9A-Fa-f:]+\]|([0-9]{1,3}\.){3}[0-9]{1,3}|([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63})(:[0-9]{1,5})?' || true
  } |
    while IFS= read -r candidate; do
      normalize_preferred_host "$candidate"
      printf '\n'
    done |
    sed '/^[[:space:]]*$/d' |
    awk '!seen[$0]++' |
    head -n 50 |
    paste -sd, -
}

default_source_urls() {
  cat <<'URLS'
https://090227.pages.dev/bestcf?isp=cmcc&ips=50
URLS
}

configured_source_urls() {
  local raw
  raw="$(read_cfg CF_PREFERRED_DOMAINS_SOURCE_URL | tr '\r\n\t ' ',,,,')"
  [ -n "$raw" ] || return 0
  printf "%s" "$raw" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
}

is_valid_source_url() {
  local source_url="$1"
  case "$source_url" in
    http://*|https://*) ;;
    *) return 1 ;;
  esac
  [ "${#source_url}" -le 2048 ] || return 1
  case "$source_url" in
    *[\'\"\`\$\;\|\&\<\>\\]*)
      return 1
      ;;
  esac
  return 0
}

update_config_value() {
  local key="$1"
  local value="$2"
  local tmp_file
  mkdir -p "$(dirname "$CONFIG_FILE")"
  tmp_file="$(mktemp "${CONFIG_FILE}.tmp.XXXXXX")"
  if [ -f "$CONFIG_FILE" ]; then
    grep -v "^${key}=" "$CONFIG_FILE" > "$tmp_file" || true
  fi
  printf "%s=%s\n" "$key" "$value" >> "$tmp_file"
  chmod 600 "$tmp_file"
  mv -f "$tmp_file" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
}

if ! command -v curl >/dev/null 2>&1; then
  echo "[$(date '+%F %T %z')] curl is unavailable, skip"
  exit 0
fi

sources="$(configured_source_urls)"
if [ -z "$sources" ]; then
  sources="$(default_source_urls)"
fi

payload=""
while IFS= read -r source_url; do
  [ -n "$source_url" ] || continue
  if ! is_valid_source_url "$source_url"; then
    echo "[$(date '+%F %T %z')] skip invalid source URL: ${source_url}"
    continue
  fi
  echo "[$(date '+%F %T %z')] fetching ${source_url}"
  payload="${payload}
$(curl -fsSL --connect-timeout 10 --max-time 60 "$source_url" 2>/dev/null || true)"
done <<< "$sources"

hosts="$(printf "%s" "$payload" | extract_preferred_hosts)"
if [ -z "$hosts" ]; then
  echo "[$(date '+%F %T %z')] no valid preferred addresses found, keep existing config"
  exit 0
fi

update_config_value CF_PREFERRED_DOMAINS "$hosts"
echo "[$(date '+%F %T %z')] updated CF_PREFERRED_DOMAINS=${hosts}"
EOF
  chmod +x /usr/local/bin/xray-cf-preferred-refresh.sh

  cat > /etc/systemd/system/xray-cf-preferred-refresh.service <<'EOF'
[Unit]
Description=Refresh Xray Cloudflare Preferred CMCC Addresses
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/xray-cf-preferred-refresh.sh
Nice=10
EOF

  cat > /etc/systemd/system/xray-cf-preferred-refresh.timer <<'EOF'
[Unit]
Description=Refresh Xray Cloudflare preferred CMCC addresses every 24 hours

[Timer]
OnBootSec=10min
OnUnitActiveSec=24h
RandomizedDelaySec=20min
Persistent=true
Unit=xray-cf-preferred-refresh.service

[Install]
WantedBy=timers.target
EOF

  systemctl daemon-reload
  systemctl enable --now xray-cf-preferred-refresh.timer >/dev/null 2>&1 || true
}

print_summary() {
  local panel_path
  local panel_public_base_url
  local panel_public_url
  local panel_local_url
  local panel_domain
  local nginx_status
  local mode
  local camouflage_site
  local credentials_glob
  local credentials_path
  local ssh_port

  panel_path="$(mgr_get_panel_path)"
  panel_domain="$(mgr_get_panel_domain)"
  nginx_status="$(systemctl is-active "$NGINX_SERVICE" 2>/dev/null || echo "inactive")"
  mode="$(mgr_get_nginx_mode)"
  panel_public_base_url="$(mgr_get_panel_base_url "$panel_domain" "$SERVER_IP" "$mode" "$nginx_status")"
  panel_public_url="$(mgr_build_panel_url "$panel_public_base_url" "$panel_path")"
  panel_local_url="http://127.0.0.1:${PANEL_PORT}/${panel_path}"
  camouflage_site="$(mgr_get_camouflage_site)"
  ssh_port="$(get_configured_ssh_port)"
  credentials_glob="${INSTALL_DIR}/initial-admin-credentials"*.txt
  credentials_path=""
  for candidate in $credentials_glob; do
    if [ -f "$candidate" ]; then
      credentials_path="$candidate"
      break
    fi
  done

  echo ""
  echo "=============================================="
  echo "安装完成。"
  echo "=============================================="
  echo "服务器 IP: $SERVER_IP"
  if [ -n "$panel_public_url" ]; then
    echo "面板公网地址: ${panel_public_url}"
  else
    echo "面板公网地址: 未启用（当前仅本机 / SSH 隧道可访问）"
  fi
  echo "面板本机地址: ${panel_local_url}"
  echo "Nginx: 默认未启用"
  echo "启用路径: xy -> Nginx 管理 -> 启动 Nginx 并选择模式"
  echo "远程访问: 默认需要启用 Nginx TLS/Reality；未启用 Nginx 时请使用 SSH 隧道访问面板地址"
  echo "SSH 隧道示例: ssh -L ${PANEL_PORT}:127.0.0.1:${PANEL_PORT} root@${SERVER_IP}"
  echo "防火墙基础开放: ${ssh_port}、443（80 仅在证书申请/续签时临时开放）"
  echo "SSH 端口: $(describe_ssh_port_policy)"
  if [ -n "$camouflage_site" ]; then
    echo "Nginx/Reality 伪装域名: ${camouflage_site}"
  else
    echo "Nginx/Reality 伪装域名: 未设置"
  fi
  echo "无后缀访问: $(mgr_get_root_camouflage_label)"
  echo "回落端口: ${FALLBACK_PORT}"
  echo "Nezha Dashboard: $(mgr_get_nezha_dashboard_public_url)/dashboard"
  echo "Nezha 默认账号: admin / admin"
  echo "Nezha Agent 通信地址: $(mgr_get_nezha_agent_server)"
  echo "Nezha Dashboard 独立域名: $(mgr_get_nezha_dashboard_domain || true)"
  echo "Nezha Agent 通信域名: $(mgr_get_nezha_agent_domain || true)"
  echo "Nezha Agent 连接密钥: $(mgr_mask_secret "$(mgr_get_nezha_dashboard_secret)")"
  echo "Nezha API Token: 首次进入 Nezha Dashboard 后创建，再填入 Xray 面板的哪吒管理页。"
  echo "说明: Nezha Agent 使用 Dashboard 用户绑定的连接密钥，和 Agent 安装参数保持一致。"
  echo "Xray 版本: ${XRAY_VERSION}"
  echo "OpenSSH / CA 证书定时维护: 已启用（每 7 天检查一次，仅升级 OpenSSH / CA 证书）"
  echo ""
  if [ -n "$credentials_path" ]; then
    echo "首次管理员凭据文件: ${credentials_path}"
    echo "请使用以下命令查看，并在首次登录成功后立即删除："
    echo "  cat ${credentials_path}"
  else
    echo "未检测到首次管理员凭据文件。"
    echo "如果这是升级安装，通常表示管理员账号已存在。"
    echo "如果这是全新安装，请执行: ls -l ${INSTALL_DIR}/initial-admin-credentials*.txt"
  fi
  echo ""
  echo "管理命令: xy"
}

mgr_pause_wait() {
  echo ""
  echo -n "按回车继续..."
  read -r
}

mgr_get_panel_path() {
  local raw_panel_path panel_path
  raw_panel_path="$(read_cfg "PANEL_PATH")"
  panel_path="$(normalize_panel_path "$raw_panel_path")"
  if [ -z "$panel_path" ]; then
    panel_path="$(generate_random_suffix)"
  fi
  if [ "$panel_path" != "$raw_panel_path" ]; then
    save_cfg "PANEL_PATH" "$panel_path"
  fi
  echo "$panel_path"
}

mgr_get_panel_domain() {
  local domain
  domain="$(normalize_panel_domain "$(read_cfg "PANEL_DOMAIN")")"
  if [ -n "$domain" ] && [ "$domain" != "$(read_cfg "PANEL_DOMAIN")" ]; then
    save_cfg "PANEL_DOMAIN" "$domain"
  fi
  echo "$domain"
}

mgr_get_nginx_mode() {
  local mode
  mode="$(read_cfg "NGINX_MODE")"
  if [ -z "$mode" ]; then
    mode="tls"
  fi
  echo "$mode"
}

mgr_normalize_camouflage_site() {
  local raw="$1"
  normalize_panel_domain "$raw"
}

mgr_is_valid_camouflage_site() {
  local site="$1"
  if [ -z "$site" ]; then
    return 0
  fi

  if [[ "$site" =~ ^localhost$ ]]; then
    return 0
  fi
  if [[ "$site" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
    return 0
  fi
  if [[ "$site" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$ ]]; then
    return 0
  fi
  return 1
}

mgr_get_camouflage_site() {
  local site
  site="$(mgr_normalize_camouflage_site "$(read_cfg "CAMOUFLAGE_SITE")")"
  if ! mgr_is_valid_camouflage_site "$site"; then
    log_warn "配置中的 CAMOUFLAGE_SITE 无效，已重置为空。"
    site=""
    save_cfg "CAMOUFLAGE_SITE" ""
  fi
  echo "$site"
}

mgr_rotate_camouflage_site() {
  mgr_get_camouflage_site
}

mgr_get_root_camouflage_label() {
  local site
  site="$(mgr_get_camouflage_site)"
  if [ -n "$site" ]; then
    echo "自定义伪装站（${site}）"
    return
  fi
  echo "本地英文博客"
}

mgr_set_camouflage_site() {
  clear
  echo -e "${CYAN}==== Nginx / Reality 伪装域名设置 ====${NC}"
  echo ""

  local current input site
  current="$(mgr_get_camouflage_site)"

  if [ -n "$current" ]; then
    echo "当前 Nginx/Reality 伪装域名: $current"
  else
    echo "当前 Nginx/Reality 伪装域名: 未设置"
  fi
  echo ""
  echo "说明: 设置后，Nginx 根路径会反代这个伪装站，Reality SNI / 伪装标识也会同步使用；留空时根路径自动显示本地英文博客。"
  echo "输入格式: 仅支持域名或 IP，不要带协议头和路径。"
  echo "示例: www.python.org、1.1.1.1、localhost"
  echo -n "请输入 Nginx/Reality 伪装域名（留空表示关闭自定义伪装域名）: "
  read -r input

  site="$(mgr_normalize_camouflage_site "$input")"
  if ! mgr_is_valid_camouflage_site "$site"; then
    log_error "无效主机名，请输入域名或 IPv4 地址。"
    mgr_pause_wait
    return
  fi

  save_cfg "CAMOUFLAGE_SITE" "$site"
  if [ -n "$site" ]; then
    log_info "已保存 Nginx/Reality 伪装域名: $site"
  else
    log_info "已关闭自定义 Nginx/Reality 伪装域名。"
  fi

  if systemctl is-active --quiet "$NGINX_SERVICE"; then
    mgr_refresh_active_nginx_mode || log_warn "已保存 Nginx/Reality 伪装域名，但刷新当前 Nginx 模式失败，请稍后重新应用当前模式。"
  elif [ "$(mgr_get_nginx_mode)" = "reality" ] && [ -n "$(mgr_get_panel_domain)" ]; then
    mgr_ensure_reality_443_inbound || log_warn "同步 Reality SNI 到当前伪装域名失败，请稍后重新应用 Reality mode。"
  fi
  mgr_pause_wait
}

mgr_get_camouflage_site_root() {
  echo "/var/www/xray-camouflage"
}

mgr_get_packaged_camouflage_site_dir() {
  local installed_dir="${INSTALL_DIR}/camouflage-site"
  if [ -d "$installed_dir" ] && [ -f "${installed_dir}/index.html" ]; then
    echo "$installed_dir"
    return
  fi
  echo "${SCRIPT_DIR}/camouflage-site"
}

mgr_get_camouflage_asset_dir() {
  echo "camouflage-assets"
}

mgr_require_local_camouflage_path() {
  local path_value="$1"
  case "$path_value" in
    /var/www/xray-camouflage|/var/www/xray-camouflage.stage.*)
      return 0
      ;;
    *)
      log_error "伪装站点目录异常: ${path_value}"
      return 1
      ;;
  esac
}

mgr_rewrite_camouflage_asset_paths() {
  local site_root="$1"
  local target_dir file
  target_dir="$(mgr_get_camouflage_asset_dir)"

  if [ -d "${site_root}/assets" ] && [ ! -d "${site_root}/${target_dir}" ]; then
    mv "${site_root}/assets" "${site_root}/${target_dir}"
  fi

  find "${site_root}" -type f \( -name '*.html' -o -name '*.css' -o -name '*.js' \) | while IFS= read -r file; do
    sed -i \
      -e "s|/assets/|/${target_dir}/|g" \
      -e "s|\"assets/|\"${target_dir}/|g" \
      -e "s|'assets/|'${target_dir}/|g" \
      "$file"
  done
}

mgr_write_local_camouflage_site() {
  local site_root packaged_root staging_root
  site_root="$(mgr_get_camouflage_site_root)"
  packaged_root="$(mgr_get_packaged_camouflage_site_dir)"
  staging_root="${site_root}.stage.$$"

  mgr_require_local_camouflage_path "${site_root}"
  mgr_require_local_camouflage_path "${staging_root}"

  rm -rf "${staging_root}"
  mkdir -p "${staging_root}"

  if [ -d "${packaged_root}" ] && [ -f "${packaged_root}/index.html" ]; then
    cp -R "${packaged_root}/." "${staging_root}/"
  else
    log_warn "未找到打包好的伪装站点，写入极简兜底页"
    cat > "${staging_root}/index.html" <<'EOF'
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>平日小记</title>
  <meta name="description" content="日常维护记录与临时站点占位页。">
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, max-snippet:0, max-image-preview:none">
  <style>
    :root { color-scheme: light; }
    body { margin: 0; font: 16px/1.7 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f5fbfc; color: #17323d; }
    main { max-width: 720px; margin: 0 auto; padding: 72px 24px; }
    h1 { margin: 0 0 16px; font-size: 2.5rem; }
    p { margin: 0 0 16px; }
    a { color: #426f80; }
  </style>
</head>
<body>
  <main>
    <p>平日小记</p>
    <h1>站点正在做例行维护。</h1>
    <p>这次安装包里没有带完整的静态博客文件，所以先显示这个极简占位页，等打包文件补齐后会恢复正常内容。</p>
    <p><a href="/">刷新首页</a></p>
  </main>
</body>
</html>
EOF
    cat > "${staging_root}/404.html" <<'EOF'
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>未找到</title>
</head>
<body>
  <p>页面不存在</p>
</body>
</html>
EOF
    cat > "${staging_root}/robots.txt" <<'EOF'
User-agent: *
Disallow: /
Crawl-delay: 30
EOF
  fi

  if [ -d "${site_root}/media/blog" ] && [ ! -L "${site_root}/media/blog" ]; then
    mkdir -p "${staging_root}/media"
    rm -rf "${staging_root}/media/blog"
    cp -R "${site_root}/media/blog" "${staging_root}/media/"
  fi

  mgr_rewrite_camouflage_asset_paths "${staging_root}"

  rm -rf "${site_root}"
  mv "${staging_root}" "${site_root}"

  find "${site_root}" -type d -exec chmod 755 {} \;
  find "${site_root}" -type f -exec chmod 644 {} \;
}

mgr_ensure_local_camouflage_template() {
  local site_root packaged_root
  site_root="$(mgr_get_camouflage_site_root)"
  packaged_root="$(mgr_get_packaged_camouflage_site_dir)"

  if ! mgr_is_local_camouflage_site_incomplete; then
    return 0
  fi

  if [ -d "${packaged_root}" ] && [ -f "${packaged_root}/index.html" ]; then
    log_warn "检测到本地博客目录缺失或模板不完整，正在从安装包模板补齐。"
    mgr_write_local_camouflage_site
    return 0
  fi

  if [ -d "${site_root}" ]; then
    log_warn "本地博客目录不完整，且未找到打包模板；已保留现有目录，避免覆盖为维护页。"
    return 0
  fi

  log_warn "未找到本地博客目录和打包模板，写入极简兜底页。"
  mgr_write_local_camouflage_site
}

mgr_is_local_camouflage_site_incomplete() {
  local site_root asset_dir
  site_root="$(mgr_get_camouflage_site_root)"
  asset_dir="$(mgr_get_camouflage_asset_dir)"

  if [ ! -d "${site_root}" ]; then
    return 0
  fi
  if [ ! -f "${site_root}/index.html" ]; then
    return 0
  fi
  if [ ! -d "${site_root}/${asset_dir}" ]; then
    return 0
  fi
  if [ -z "$(find "${site_root}/${asset_dir}" -maxdepth 1 -type f -name '*.js' -print -quit 2>/dev/null)" ]; then
    return 0
  fi
  if [ -z "$(find "${site_root}/${asset_dir}" -maxdepth 1 -type f -name '*.css' -print -quit 2>/dev/null)" ]; then
    return 0
  fi

  return 1
}

mgr_overlay_repair_local_blog_site_if_needed() {
  local camouflage_site repaired
  camouflage_site="$(mgr_get_camouflage_site)"
  if [ -n "${camouflage_site}" ]; then
    return 0
  fi

  repaired=0
  if mgr_is_local_camouflage_site_incomplete; then
    log_warn "检测到本地博客目录缺失或不完整，正在自动补齐站点文件。"
    mgr_ensure_local_camouflage_template
    repaired=1
  fi

  if [ "${repaired}" = "1" ]; then
    if mgr_run_backend_command "blog-publish"; then
      log_info "本地博客目录已补齐并完成重新发布。"
    else
      log_warn "本地博客目录已补齐，但自动发布失败。可手动执行: sudo xy blog-publish"
    fi
    return 0
  fi

  if mgr_run_backend_command "blog-publish"; then
    log_info "本地博客已使用当前安装包模板重新发布。"
  else
    log_warn "本地博客自动重新发布失败。可手动执行: sudo xy blog-publish"
  fi
}

mgr_build_remote_camouflage_location() {
  local camouflage_site="$1"
  cat <<EOF
    location / {
        proxy_http_version 1.1;
        proxy_ssl_server_name on;
        proxy_set_header Host ${camouflage_site};
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header Accept-Encoding "";
        proxy_set_header Referer "";
        proxy_set_header Origin "";
        proxy_hide_header Alt-Svc;
        proxy_hide_header Content-Security-Policy;
        proxy_hide_header Content-Security-Policy-Report-Only;
        proxy_hide_header Cross-Origin-Opener-Policy;
        proxy_hide_header Cross-Origin-Resource-Policy;
        proxy_hide_header Permissions-Policy;
        proxy_hide_header Referrer-Policy;
        proxy_hide_header X-Content-Type-Options;
        proxy_hide_header X-Frame-Options;
        proxy_hide_header X-Robots-Tag;
        proxy_intercept_errors on;
        error_page 500 502 503 504 = @xray_camouflage_http_fallback;
        proxy_redirect https://${camouflage_site}/ \$scheme://\$host/;
        proxy_redirect http://${camouflage_site}/ \$scheme://\$host/;
        proxy_cookie_domain ${camouflage_site} \$host;
        sub_filter_once off;
        sub_filter_types text/css application/javascript application/json;
        sub_filter "https://${camouflage_site}" "\$scheme://\$host";
        sub_filter "http://${camouflage_site}" "\$scheme://\$host";
        proxy_pass https://${camouflage_site};
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location @xray_camouflage_http_fallback {
        internal;
        proxy_http_version 1.1;
        proxy_set_header Host ${camouflage_site};
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header Accept-Encoding "";
        proxy_set_header Referer "";
        proxy_set_header Origin "";
        proxy_hide_header Alt-Svc;
        proxy_hide_header Content-Security-Policy;
        proxy_hide_header Content-Security-Policy-Report-Only;
        proxy_hide_header Cross-Origin-Opener-Policy;
        proxy_hide_header Cross-Origin-Resource-Policy;
        proxy_hide_header Permissions-Policy;
        proxy_hide_header Referrer-Policy;
        proxy_hide_header X-Content-Type-Options;
        proxy_hide_header X-Frame-Options;
        proxy_hide_header X-Robots-Tag;
        proxy_redirect https://${camouflage_site}/ \$scheme://\$host/;
        proxy_redirect http://${camouflage_site}/ \$scheme://\$host/;
        proxy_cookie_domain ${camouflage_site} \$host;
        sub_filter_once off;
        sub_filter_types text/css application/javascript application/json;
        sub_filter "https://${camouflage_site}" "\$scheme://\$host";
        sub_filter "http://${camouflage_site}" "\$scheme://\$host";
        proxy_pass http://${camouflage_site};
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }
EOF
}

mgr_build_local_blog_root_location() {
  local site_root asset_dir
  local security_headers blog_page_guard blog_asset_guard
  site_root="$(mgr_get_camouflage_site_root)"
  asset_dir="$(mgr_get_camouflage_asset_dir)"
  security_headers="$(cat <<'EOF'
        add_header Content-Security-Policy "default-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; manifest-src 'self'; media-src 'self'; worker-src 'self'" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "DENY" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cross-Origin-Resource-Policy "same-origin" always;
        add_header Cross-Origin-Opener-Policy "same-origin" always;
        add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=(), usb=()" always;
        add_header X-Robots-Tag "noindex, nofollow, noarchive, nosnippet, noimageindex, max-snippet:0, max-image-preview:none" always;
EOF
)"
  blog_page_guard="$(cat <<'EOF'
        if ($xray_blog_block_ua) { return 444; }
        limit_req_status 429;
        limit_req zone=xray_blog_page_rate burst=10 nodelay;
        limit_conn xray_blog_conn 16;
        limit_except GET HEAD { deny all; }
EOF
)"
  blog_asset_guard="$(cat <<'EOF'
        if ($xray_blog_block_ua) { return 444; }
        limit_req_status 429;
        limit_req zone=xray_blog_asset_rate burst=40 nodelay;
        limit_conn xray_blog_conn 24;
        limit_except GET HEAD { deny all; }
EOF
)"
  cat <<EOF
    root ${site_root};
    index index.html;
    error_page 404 /404.html;

    location = / {
${security_headers}
${blog_page_guard}
        add_header Cache-Control "no-store" always;
        try_files /index.html =404;
    }

    location = /404.html {
        internal;
    }

    location = /robots.txt {
${security_headers}
${blog_page_guard}
        access_log off;
        log_not_found off;
        try_files \$uri =404;
    }

    location = /feed.xml {
${security_headers}
${blog_page_guard}
        access_log off;
        log_not_found off;
        add_header Cache-Control "no-store" always;
        try_files \$uri =404;
    }

    location = /sitemap.xml {
${security_headers}
${blog_page_guard}
        access_log off;
        log_not_found off;
        add_header Cache-Control "no-store" always;
        try_files \$uri =404;
    }

    location = /content/blog-data.json {
${security_headers}
${blog_page_guard}
        access_log off;
        log_not_found off;
        add_header Cache-Control "no-store" always;
        try_files \$uri =404;
    }

    location ^~ /content/ {
${security_headers}
${blog_asset_guard}
        access_log off;
        log_not_found off;
        expires 1d;
        add_header Cache-Control "public, max-age=86400, immutable" always;
        try_files \$uri =404;
    }

    location ^~ /media/blog/ {
${security_headers}
${blog_asset_guard}
        access_log off;
        log_not_found off;
        valid_referers none blocked server_names;
        if (\$invalid_referer) { return 403; }
        expires 1d;
        add_header Cache-Control "public, max-age=86400, immutable" always;
        try_files \$uri =404;
    }

    location ^~ /${asset_dir}/ {
${security_headers}
${blog_asset_guard}
        access_log off;
        log_not_found off;
        expires 1h;
        add_header Cache-Control "public, max-age=3600" always;
        try_files \$uri =404;
    }

    location / {
${security_headers}
${blog_page_guard}
        add_header Cache-Control "no-store" always;
        try_files \$uri \$uri/ =404;
    }
EOF
}

mgr_build_root_location() {
  local camouflage_site
  camouflage_site="$(mgr_get_camouflage_site)"
  if [ -n "$camouflage_site" ]; then
    mgr_build_remote_camouflage_location "$camouflage_site"
    return
  fi
  mgr_build_local_blog_root_location
}

mgr_mask_secret() {
  local raw="$1"
  local n
  n="${#raw}"
  if [ "$n" -le 8 ]; then
    printf "%s" "********"
    return
  fi
  printf "%s***%s" "${raw:0:4}" "${raw:$((n-4)):4}"
}

mgr_tg_alert_is_enabled() {
  [ "$(read_cfg "TG_ALERT_ENABLED")" = "1" ]
}

mgr_write_security_monitor_script() {
  cat > /usr/local/bin/xray-security-monitor.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
umask 077

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
STATE_DIR="${STATE_DIR:-/var/lib/xray-backend/security-monitor}"
DEFAULT_COOLDOWN=1800
DEFAULT_TRAFFIC_ALERT_MBPS=500
MAX_ALERT_LINES=12
MIN_PUSH_INTERVAL=60
PENDING_ALERT_FILE="${STATE_DIR}/pending-alerts.html"
GLOBAL_PUSH_STATE="${GLOBAL_PUSH_STATE:-/var/lib/xray-backend/tg-last-push.state}"
QUEUE_LOCK_DIR="${QUEUE_LOCK_DIR:-/var/lib/xray-backend/security-monitor/queue.lock.d}"
QUEUE_LOCK_HELD=0
ALERT_SECTIONS=""
ALERT_COUNT=0

read_cfg() {
  local key="$1"
  [[ "$key" =~ ^[A-Z0-9_]+$ ]] || return 0
  if [ -f "$CONFIG_FILE" ]; then
    awk -v key="$key" 'index($0, key "=") == 1 { print substr($0, length(key) + 2); exit }' "$CONFIG_FILE" 2>/dev/null || true
  fi
}

trim() {
  printf "%s" "$1" | tr -d '\r\n'
}

escape_html() {
  local s="$1"
  s="${s//&/&amp;}"
  s="${s//</&lt;}"
  s="${s//>/&gt;}"
  printf "%s" "$s"
}

hash_text() {
  if command -v sha256sum >/dev/null 2>&1; then
    printf "%s" "$1" | sha256sum | awk '{print $1}'
  else
    printf "%s" "$1" | cksum | awk '{print $1 "-" $2}'
  fi
}

send_tg() {
  local text="$1"
  curl -fsS --max-time 10 --config - \
    -d "chat_id=${TG_CHAT_ID}" \
    -d "disable_web_page_preview=true" \
    -d "parse_mode=HTML" \
    --data-urlencode "text=${text}" >/dev/null <<CURLCFG
url = "https://api.telegram.org/bot${TG_BOT_TOKEN}/sendMessage"
CURLCFG
}

acquire_queue_lock() {
  local deadline now
  mkdir -p "$(dirname "$QUEUE_LOCK_DIR")"
  deadline=$(( $(date +%s) + 10 ))
  while true; do
    if mkdir "$QUEUE_LOCK_DIR" 2>/dev/null; then
      QUEUE_LOCK_HELD=1
      printf '%s\n' "$$" > "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      trap release_queue_lock EXIT
      return 0
    fi
    if [ -d "$QUEUE_LOCK_DIR" ] && find "$QUEUE_LOCK_DIR" -maxdepth 0 -mmin +5 >/dev/null 2>&1; then
      rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    fi
    now="$(date +%s)"
    [ "$now" -ge "$deadline" ] && return 1
    sleep 0.1
  done
}

release_queue_lock() {
  if [ "${QUEUE_LOCK_HELD:-0}" = "1" ]; then
    rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
    rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    QUEUE_LOCK_HELD=0
  fi
}

cooldown_ok() {
  local key="$1"
  local now last safe_key file
  safe_key="$(printf "%s" "$key" | tr -c 'A-Za-z0-9_.-' '_')"
  file="${STATE_DIR}/cooldown-${safe_key}.state"
  now="$(date +%s)"
  last="0"
  if [ -f "$file" ]; then
    last="$(tr -dc '0-9' < "$file" || true)"
  fi
  if ! [[ "$last" =~ ^[0-9]+$ ]]; then
    last="0"
  fi
  if [ $((now - last)) -lt "$TG_COOLDOWN" ]; then
    return 1
  fi
  printf "%s\n" "$now" > "$file"
  return 0
}

append_alert_section() {
  local title="$1"
  local body="$2"
  if [ -n "$ALERT_SECTIONS" ]; then
    ALERT_SECTIONS="${ALERT_SECTIONS}

"
  fi
  ALERT_SECTIONS="${ALERT_SECTIONS}<b>${title}</b>
${body}"
  ALERT_COUNT=$((ALERT_COUNT + 1))
}

append_alert_section_throttled() {
  local key="$1"
  local title="$2"
  local body="$3"
  if ! cooldown_ok "$key"; then
    return 0
  fi
  append_alert_section "$title" "$body"
}

queue_current_alerts() {
  if [ "$ALERT_COUNT" -le 0 ]; then
    return 0
  fi
  if [ -s "$PENDING_ALERT_FILE" ]; then
    printf "\n\n" >> "$PENDING_ALERT_FILE"
  fi
  printf "%s\n" "$ALERT_SECTIONS" >> "$PENDING_ALERT_FILE"
  ALERT_SECTIONS=""
  ALERT_COUNT=0
}

machine_identity_lines() {
  local safe_name safe_host safe_public_ip
  safe_name="$(escape_html "$VPS_NAME")"
  safe_host="$(escape_html "$HOST_NAME")"
  safe_public_ip="$(escape_html "${PUBLIC_IP:-未配置}")"
  printf '机器名: <code>%s</code>\n主机名: <code>%s</code>\n公网 IP: <code>%s</code>' "$safe_name" "$safe_host" "$safe_public_ip"
}

flush_alerts() {
  local now last pending combined safe_time section_count msg
  pending=""
  if [ -s "$PENDING_ALERT_FILE" ]; then
    pending="$(cat "$PENDING_ALERT_FILE" 2>/dev/null || true)"
  fi
  combined="$pending"
  if [ -n "$ALERT_SECTIONS" ]; then
    if [ -n "$combined" ]; then
      combined="${combined}

${ALERT_SECTIONS}"
    else
      combined="$ALERT_SECTIONS"
    fi
  fi
  [ -n "$combined" ] || return 0

  now="$(date +%s)"
  last="0"
  if [ -f "$GLOBAL_PUSH_STATE" ]; then
    last="$(tr -dc '0-9' < "$GLOBAL_PUSH_STATE" || true)"
  fi
  if ! [[ "$last" =~ ^[0-9]+$ ]]; then
    last="0"
  fi
  if [ $((now - last)) -lt "$MIN_PUSH_INTERVAL" ]; then
    queue_current_alerts
    return 0
  fi

  safe_time="$(escape_html "$(date '+%F %T %z')")"
  section_count="$(printf "%s\n" "$combined" | grep -c '^<b>\[告警\]' || true)"
  msg="<b>[告警] VPS 安全事件汇总</b>
$(machine_identity_lines)
时间: ${safe_time}
汇总事件: <code>${section_count}</code>

${combined}"
  if ! send_tg "$msg"; then
    queue_current_alerts
    return 0
  fi
  printf "%s\n" "$now" > "$GLOBAL_PUSH_STATE"
  rm -f "$PENDING_ALERT_FILE"
  ALERT_SECTIONS=""
  ALERT_COUNT=0
}

format_code_lines() {
  local input="$1"
  local count=0
  local line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    count=$((count + 1))
    if [ "$count" -gt "$MAX_ALERT_LINES" ]; then
      printf "...more omitted...\n"
      break
    fi
    printf '<code>%s</code>\n' "$(escape_html "${line:0:220}")"
  done <<< "$input"
}

collect_ssh_login_lines() {
  local lines=""
  if command -v journalctl >/dev/null 2>&1; then
    lines="$(journalctl -u ssh -u sshd --since '2 hours ago' --no-pager -o short-iso 2>/dev/null | grep -E 'sshd(\[[0-9]+\])?: Accepted (publickey|password|keyboard-interactive/pam) for ' || true)"
  fi
  if [ -z "$lines" ]; then
    local log_file
    for log_file in /var/log/auth.log /var/log/secure; do
      if [ -r "$log_file" ]; then
        lines="${lines}
$(grep -E 'sshd.*Accepted (publickey|password|keyboard-interactive/pam) for ' "$log_file" 2>/dev/null | tail -n 200 || true)"
      fi
    done
  fi
  printf "%s\n" "$lines" | sed '/^[[:space:]]*$/d' | tail -n 80
}

check_ssh_logins() {
  local state_file="${STATE_DIR}/ssh-login.seen"
  local new_file="${STATE_DIR}/ssh-login.new.$$"
  local first_run=0
  local line hash
  if [ ! -f "$state_file" ]; then
    first_run=1
    : > "$state_file"
  fi
  : > "$new_file"
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    hash="$(hash_text "$line")"
    if grep -Fxq "$hash" "$state_file" 2>/dev/null; then
      continue
    fi
    printf "%s\n" "$hash" >> "$state_file"
    if [ "$first_run" -eq 0 ]; then
      printf "%s\n" "$line" >> "$new_file"
    fi
  done < <(collect_ssh_login_lines)
  tail -n 500 "$state_file" > "${state_file}.tmp" 2>/dev/null && mv -f "${state_file}.tmp" "$state_file" || true
  if [ -s "$new_file" ]; then
    local body
    body="SSH 成功登录记录:
$(format_code_lines "$(cat "$new_file")")"
    append_alert_section "[告警] SSH 登录" "$body"
  fi
  rm -f "$new_file"
}

valid_port() {
  [[ "$1" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]
}

configured_allowed_ports() {
  local value port listen
  printf "%s\n" "${EXPECTED_PUBLIC_PORTS:-80,443}" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
  port="$(trim "$(read_cfg "SSH_PORT")")"
  if valid_port "$port"; then
    printf "%s\n" "$port"
  fi
  port="$(trim "$(read_cfg "NEZHA_DASHBOARD_PORT")")"
  if valid_port "$port"; then
    printf "%s\n" "$port"
  fi
  listen="$(trim "$(read_cfg "SUBSCRIPTION_LISTEN")")"
  port="${listen##*:}"
  if valid_port "$port"; then
    printf "%s\n" "$port"
  fi
  value="$(trim "$(read_cfg "TG_EXTRA_ALLOWED_PORTS")")"
  if [ -n "$value" ]; then
    printf "%s\n" "$value" | tr ',' '\n' | sed '/^[[:space:]]*$/d'
  fi
}

is_allowed_port() {
  local port="$1"
  configured_allowed_ports | sort -u | grep -Fxq "$port"
}

host_from_addr() {
  local addr="$1"
  local host
  if [[ "$addr" =~ ^\[(.*)\]:[0-9]+$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
    return
  fi
  host="${addr%:*}"
  printf "%s" "$host"
}

port_from_addr() {
  local addr="$1"
  if [[ "$addr" =~ ^\[.*\]:([0-9]+)$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
  elif [[ "$addr" =~ :([0-9]+)$ ]]; then
    printf "%s" "${BASH_REMATCH[1]}"
  fi
}

is_loopback_addr() {
  local host
  host="$(host_from_addr "$1")"
  case "$host" in
    127.*|::1|localhost)
      return 0
      ;;
  esac
  return 1
}

collect_abnormal_listeners() {
  if command -v ss >/dev/null 2>&1; then
    ss -H -ltunp 2>/dev/null | while IFS= read -r line; do
      [ -z "$line" ] && continue
      set -- $line
      local local_addr="${4:-}"
      local port
      port="$(port_from_addr "$local_addr")"
      [ -z "$port" ] && continue
      is_loopback_addr "$local_addr" && continue
      if is_allowed_port "$port"; then
        continue
      fi
      printf 'port=%s addr=%s %s\n' "$port" "$local_addr" "$(printf "%s" "$line" | cut -c1-220)"
    done
  elif command -v netstat >/dev/null 2>&1; then
    netstat -ltunp 2>/dev/null | awk 'NR>2 {print}' | while IFS= read -r line; do
      set -- $line
      local local_addr="${4:-}"
      local port
      port="$(port_from_addr "$local_addr")"
      [ -z "$port" ] && continue
      is_loopback_addr "$local_addr" && continue
      if is_allowed_port "$port"; then
        continue
      fi
      printf 'port=%s addr=%s %s\n' "$port" "$local_addr" "$(printf "%s" "$line" | cut -c1-220)"
    done
  fi | sort -u
}

check_listening_ports() {
  local current_file="${STATE_DIR}/listeners.current"
  local previous_file="${STATE_DIR}/listeners.previous"
  local new_lines
  collect_abnormal_listeners > "$current_file" || true
  if [ ! -f "$previous_file" ]; then
    cp -f "$current_file" "$previous_file"
    new_lines="$(cat "$current_file")"
  else
    new_lines="$(comm -13 "$previous_file" "$current_file" 2>/dev/null || true)"
    cp -f "$current_file" "$previous_file"
  fi
  if [ -n "$new_lines" ]; then
    local body
    body="发现新的公网异常监听端口:
$(format_code_lines "$new_lines")
允许端口可在配置里追加 <code>TG_EXTRA_ALLOWED_PORTS=端口1,端口2</code>。"
    append_alert_section "[告警] 异常端口监听" "$body"
  fi
}

read_network_total_bytes() {
  if [ ! -r /proc/net/dev ]; then
    printf "0"
    return
  fi
  awk -F'[: ]+' 'NR > 2 { iface=$2; if (iface == "lo") next; total += $3 + $11 } END { printf "%.0f", total + 0 }' /proc/net/dev
}

check_traffic() {
  local state_file="${STATE_DIR}/traffic.state"
  local now total previous_ts previous_total interval delta mbps threshold
  threshold="$(trim "$(read_cfg "TG_TRAFFIC_ALERT_MBPS")")"
  if ! [[ "$threshold" =~ ^[0-9]+$ ]] || [ "$threshold" -lt 1 ]; then
    threshold="$DEFAULT_TRAFFIC_ALERT_MBPS"
  fi
  now="$(date +%s)"
  total="$(read_network_total_bytes)"
  if ! [[ "$total" =~ ^[0-9]+$ ]]; then
    return 0
  fi
  if [ ! -f "$state_file" ]; then
    printf 'TS=%s\nBYTES=%s\n' "$now" "$total" > "$state_file"
    return 0
  fi
  previous_ts="$(sed -n 's/^TS=//p' "$state_file" | head -n 1 | tr -dc '0-9' || true)"
  previous_total="$(sed -n 's/^BYTES=//p' "$state_file" | head -n 1 | tr -dc '0-9' || true)"
  printf 'TS=%s\nBYTES=%s\n' "$now" "$total" > "$state_file"
  if ! [[ "$previous_ts" =~ ^[0-9]+$ ]] || ! [[ "$previous_total" =~ ^[0-9]+$ ]]; then
    return 0
  fi
  interval=$((now - previous_ts))
  [ "$interval" -lt 30 ] && return 0
  if [ "$total" -lt "$previous_total" ]; then
    return 0
  fi
  delta=$((total - previous_total))
  mbps=$((delta * 8 / interval / 1000000))
  if [ "$mbps" -ge "$threshold" ]; then
    local body
    body="检测到 VPS 网卡聚合流量突增:
当前速率: <code>${mbps} Mbps</code>
阈值: <code>${threshold} Mbps</code>
采样间隔: <code>${interval}s</code>"
    append_alert_section_throttled "traffic" "[告警] 流量异常" "$body"
  fi
}

watch_paths() {
  cat <<'PATHS'
/opt/xray-backend/config.conf
/opt/xray-backend/xray-core
/opt/xray-backend/mihomo-core
/etc/ssh/sshd_config
/etc/ssh/sshd_config.d
/etc/systemd/system/xray-backend.service
/etc/systemd/system/xray-watchdog.service
/etc/systemd/system/xray-security-monitor.service
/etc/systemd/system/xray-security-monitor.timer
/etc/systemd/system/xray-tg-access-alert.service
/etc/systemd/system/xray-fail2ban-daily-report.service
/etc/systemd/system/xray-fail2ban-daily-report.timer
/etc/systemd/system/xray-cf-preferred-refresh.service
/etc/systemd/system/xray-cf-preferred-refresh.timer
/etc/systemd/system/nezha-dashboard.service
/etc/fail2ban/jail.d/xray-panel.local
/etc/fail2ban/filter.d
/etc/nginx
/etc/certs
/usr/local/bin/xray-security-monitor.sh
/usr/local/bin/xray-tg-access-alert.sh
/usr/local/bin/xray-fail2ban-daily-report.sh
/usr/local/bin/xray-cf-preferred-refresh.sh
PATHS
  local extra
  extra="$(trim "$(read_cfg "TG_FILE_WATCH_PATHS")")"
  if [ -n "$extra" ]; then
    printf "%s\n" "$extra" | tr ',' '\n'
  fi
}

snapshot_path() {
  local path="$1"
  [ -e "$path" ] || return 0
  if [ -d "$path" ]; then
    find "$path" -xdev \
      \( -path '*/backups/*' -o -name '*.log' -o -name '*.tmp' \) -prune -o \
      -type f -printf '%p|%s|%T@\n' 2>/dev/null || true
  else
    stat -Lc '%n|%s|%Y' "$path" 2>/dev/null || true
  fi
}

build_file_snapshot() {
  local path
  while IFS= read -r path; do
    [ -z "$path" ] && continue
    snapshot_path "$path"
  done < <(watch_paths) | sort -u
}

check_file_modifications() {
  local current_file="${STATE_DIR}/files.current"
  local previous_file="${STATE_DIR}/files.previous"
  local added removed body
  build_file_snapshot > "$current_file" || true
  if [ ! -f "$previous_file" ]; then
    cp -f "$current_file" "$previous_file"
    return 0
  fi
  added="$(comm -13 "$previous_file" "$current_file" 2>/dev/null | cut -d'|' -f1 | head -n "$MAX_ALERT_LINES" || true)"
  removed="$(comm -23 "$previous_file" "$current_file" 2>/dev/null | cut -d'|' -f1 | head -n "$MAX_ALERT_LINES" || true)"
  cp -f "$current_file" "$previous_file"
  if [ -n "$added" ] || [ -n "$removed" ]; then
    body="关键系统/服务文件发生变化。"
    if [ -n "$added" ]; then
      body="${body}
新增或变更:
$(format_code_lines "$added")"
    fi
    if [ -n "$removed" ]; then
      body="${body}
删除或旧版本消失:
$(format_code_lines "$removed")"
    fi
    body="${body}
如需扩大范围，可在配置里追加 <code>TG_FILE_WATCH_PATHS=/path1,/path2</code>。"
    append_alert_section "[告警] 关键文件变更" "$body"
  fi
}

TG_ENABLED="$(trim "$(read_cfg "TG_ALERT_ENABLED")")"
TG_BOT_TOKEN="$(trim "$(read_cfg "TG_BOT_TOKEN")")"
TG_CHAT_ID="$(trim "$(read_cfg "TG_CHAT_ID")")"
TG_COOLDOWN="$(trim "$(read_cfg "TG_ALERT_COOLDOWN")")"
VPS_NAME="$(trim "$(read_cfg "VPS_DISPLAY_NAME")")"
HOST_NAME="$(hostname 2>/dev/null | tr -d '\r\n' || true)"
PUBLIC_IP="$(trim "$(read_cfg "PUBLIC_IP")")"

[ "$TG_ENABLED" = "1" ] || exit 0
[ -n "$TG_BOT_TOKEN" ] || exit 0
[ -n "$TG_CHAT_ID" ] || exit 0
if ! [[ "$TG_COOLDOWN" =~ ^[0-9]+$ ]]; then
  TG_COOLDOWN="$DEFAULT_COOLDOWN"
fi
if [ -z "$VPS_NAME" ]; then
  VPS_NAME="${HOST_NAME:-Xray 节点}"
fi
if [ -z "$HOST_NAME" ]; then
  HOST_NAME="unknown"
fi

mkdir -p "$STATE_DIR"
acquire_queue_lock || exit 0
check_ssh_logins || true
check_listening_ports || true
check_traffic || true
check_file_modifications || true
flush_alerts || true
release_queue_lock
EOF
  chown root:root /usr/local/bin/xray-security-monitor.sh 2>/dev/null || true
  chmod 700 /usr/local/bin/xray-security-monitor.sh
}

mgr_write_security_monitor_service() {
  cat > /etc/systemd/system/xray-security-monitor.service <<EOF
[Unit]
Description=Xray Telegram Security Monitor
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
ExecStart=/usr/local/bin/xray-security-monitor.sh
Environment=CONFIG_FILE=${CONFIG_FILE}
Environment=STATE_DIR=/var/lib/xray-backend/security-monitor
Environment=EXPECTED_PUBLIC_PORTS=80,443,${PANEL_PORT},${FALLBACK_PORT},${NEZHA_DASHBOARD_PORT}
Environment=QUEUE_LOCK_DIR=/var/lib/xray-backend/security-monitor/queue.lock.d
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=-/var/lib/xray-backend
RestrictSUIDSGID=true
LockPersonality=true
EOF

  cat > /etc/systemd/system/xray-security-monitor.timer <<'EOF'
[Unit]
Description=Run Xray Telegram security monitor

[Timer]
OnBootSec=2min
OnUnitActiveSec=60s
AccuracySec=15s
Persistent=true
Unit=xray-security-monitor.service

[Install]
WantedBy=timers.target
EOF
}

mgr_write_tg_alert_script() {
  cat > /usr/local/bin/xray-tg-access-alert.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE:-/opt/xray-backend/config.conf}"
ACCESS_LOG="${NGINX_ACCESS_LOG:-/var/log/nginx/access.log}"
DEFAULT_COOLDOWN=1800
LOCAL_RECORD_DIR="${LOCAL_RECORD_DIR:-/var/log/xray-tg-access-local}"
LOCAL_RECORD_PREFIX="local-127"
LOCAL_RETENTION_DAYS=7
CLEANUP_INTERVAL=3600
MIN_PUSH_INTERVAL=60
MAX_BATCH_LINES=20
BATCH_FILE="${LOCAL_RECORD_DIR}/panel-auth-alert.batch"
BATCH_FIRST_FILE="${LOCAL_RECORD_DIR}/panel-auth-alert.first"
GLOBAL_PUSH_STATE="${GLOBAL_PUSH_STATE:-/var/lib/xray-backend/tg-last-push.state}"
QUEUE_LOCK_DIR="${QUEUE_LOCK_DIR:-/var/lib/xray-backend/security-monitor/queue.lock.d}"
QUEUE_LOCK_HELD=0

read_cfg() {
  local key="$1"
  [[ "$key" =~ ^[A-Z0-9_]+$ ]] || return
  if [ -f "$CONFIG_FILE" ]; then
    grep "^${key}=" "$CONFIG_FILE" | head -n 1 | cut -d'=' -f2-
  fi
}

trim() {
  local raw="$1"
  echo "$raw" | tr -d '\r\n'
}

normalize_prefix() {
  local prefix
  prefix="$(trim "$1")"
  if [ -z "$prefix" ]; then
    echo ""
    return
  fi
  case "$prefix" in
    /*) ;;
    *) prefix="/$prefix" ;;
  esac
  while [ "${#prefix}" -gt 1 ] && [ "${prefix%/}" != "$prefix" ]; do
    prefix="${prefix%/}"
  done
  if [ "$prefix" = "/" ]; then
    echo ""
    return
  fi
  echo "$prefix"
}

escape_html() {
  local s="$1"
  s="${s//&/&amp;}"
  s="${s//</&lt;}"
  s="${s//>/&gt;}"
  printf "%s" "$s"
}

send_tg() {
  local token="$1"
  local chat_id="$2"
  local text="$3"
  curl -fsS --max-time 10 "https://api.telegram.org/bot${token}/sendMessage" \
    -d "chat_id=${chat_id}" \
    -d "disable_web_page_preview=true" \
    -d "parse_mode=HTML" \
    --data-urlencode "text=${text}" >/dev/null
}

acquire_queue_lock() {
  local deadline now
  mkdir -p "$(dirname "$QUEUE_LOCK_DIR")"
  deadline=$(( $(date +%s) + 10 ))
  while true; do
    if mkdir "$QUEUE_LOCK_DIR" 2>/dev/null; then
      QUEUE_LOCK_HELD=1
      printf '%s\n' "$$" > "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      trap release_queue_lock EXIT
      return 0
    fi
    if [ -d "$QUEUE_LOCK_DIR" ] && find "$QUEUE_LOCK_DIR" -maxdepth 0 -mmin +5 >/dev/null 2>&1; then
      rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
      rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    fi
    now="$(date +%s)"
    [ "$now" -ge "$deadline" ] && return 1
    sleep 0.1
  done
}

release_queue_lock() {
  if [ "${QUEUE_LOCK_HELD:-0}" = "1" ]; then
    rm -f "${QUEUE_LOCK_DIR}/owner" 2>/dev/null || true
    rmdir "$QUEUE_LOCK_DIR" 2>/dev/null || true
    QUEUE_LOCK_HELD=0
  fi
}

write_local_record() {
  local rec_ip="$1"
  local rec_kind="$2"
  local rec_method="$3"
  local rec_path="$4"
  local rec_status="$5"
  local rec_req_time="$6"
  local rec_ua="$7"
  local rec_file
  rec_file="${LOCAL_RECORD_DIR}/${LOCAL_RECORD_PREFIX}-$(date +%F).log"
  printf '[%s] ip=%s kind=%s method=%s path=%s status=%s req_time="%s" ua="%s"\n' \
    "$(date '+%F %T %z')" \
    "$rec_ip" \
    "$rec_kind" \
    "$rec_method" \
    "${rec_path:0:200}" \
    "$rec_status" \
    "$rec_req_time" \
    "${rec_ua:0:180}" >> "$rec_file"
}

cleanup_local_records() {
  find "$LOCAL_RECORD_DIR" -type f -name "${LOCAL_RECORD_PREFIX}-*.log" -mtime +"$LOCAL_RETENTION_DAYS" -delete 2>/dev/null || true
}

append_batch_alert() {
  local rec_ip="$1"
  local rec_method="$2"
  local rec_path="$3"
  local rec_status="$4"
  local rec_req_time="$5"
  local rec_ua="$6"
  if [ ! -s "$BATCH_FILE" ]; then
    date +%s > "$BATCH_FIRST_FILE"
  fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$rec_req_time" \
    "$rec_ip" \
    "$rec_method" \
    "${rec_path:0:200}" \
    "$rec_status" \
    "${rec_ua:0:180}" >> "$BATCH_FILE"
}

format_batch_details() {
  local line count=0 rec_time rec_ip rec_method rec_path rec_status rec_ua
  tail -n "$MAX_BATCH_LINES" "$BATCH_FILE" 2>/dev/null | while IFS=$'\t' read -r rec_time rec_ip rec_method rec_path rec_status rec_ua; do
    count=$((count + 1))
    printf '<code>%s</code> <code>%s</code> %s <code>%s %s</code> UA:<code>%s</code>\n' \
      "$(escape_html "$rec_time")" \
      "$(escape_html "$rec_ip")" \
      "$(escape_html "$rec_status")" \
      "$(escape_html "$rec_method")" \
      "$(escape_html "$rec_path")" \
      "$(escape_html "$rec_ua")"
  done
}

format_batch_top_ips() {
  awk -F '\t' '
    NF >= 2 { count[$2]++ }
    END {
      for (ip in count) {
        print count[ip] "\t" ip
      }
    }
  ' "$BATCH_FILE" 2>/dev/null | sort -rn | head -n 8 | while IFS=$'\t' read -r ip_count ip_value; do
    [ -z "$ip_value" ] && continue
    printf '<code>%s</code> 次数:<code>%s</code>\n' "$(escape_html "$ip_value")" "$(escape_html "$ip_count")"
  done
}

machine_identity_lines() {
  local safe_name safe_host safe_public_ip
  safe_name="$(escape_html "$vps_name")"
  safe_host="$(escape_html "$host_name")"
  safe_public_ip="$(escape_html "${public_ip:-未配置}")"
  printf '机器名: <code>%s</code>\n主机名: <code>%s</code>\n公网 IP: <code>%s</code>' "$safe_name" "$safe_host" "$safe_public_ip"
}

flush_batch_alerts() {
  local now first last total safe_time top_ips details msg
  [ -s "$BATCH_FILE" ] || return 0
  acquire_queue_lock || return 0
  now="$(date +%s)"
  first="$(tr -dc '0-9' < "$BATCH_FIRST_FILE" 2>/dev/null || true)"
  if ! [[ "$first" =~ ^[0-9]+$ ]]; then
    first="$now"
    printf "%s\n" "$first" > "$BATCH_FIRST_FILE"
  fi
  if [ $((now - first)) -lt "$MIN_PUSH_INTERVAL" ]; then
    release_queue_lock
    return 0
  fi
  last="0"
  if [ -f "$GLOBAL_PUSH_STATE" ]; then
    last="$(tr -dc '0-9' < "$GLOBAL_PUSH_STATE" || true)"
  fi
  if ! [[ "$last" =~ ^[0-9]+$ ]]; then
    last="0"
  fi
  if [ $((now - last)) -lt "$MIN_PUSH_INTERVAL" ]; then
    release_queue_lock
    return 0
  fi
  total="$(wc -l < "$BATCH_FILE" | tr -d ' ')"
  safe_time="$(escape_html "$(date '+%F %T %z')")"
  top_ips="$(format_batch_top_ips)"
  details="$(format_batch_details)"
  msg="<b>[告警] 面板登录异常汇总</b>
$(machine_identity_lines)
时间: ${safe_time}
事件数: <code>${total}</code>

来源统计:
${top_ips:-无}

最近记录:
${details:-无}"
  if ! send_tg "$bot_token" "$chat_id" "$msg"; then
    release_queue_lock
    return 0
  fi
  printf "%s\n" "$now" > "$GLOBAL_PUSH_STATE"
  rm -f "$BATCH_FILE" "$BATCH_FIRST_FILE"
  release_queue_lock
}

panel_path="$(trim "$(read_cfg "PANEL_PATH")")"
bot_token="$(trim "$(read_cfg "TG_BOT_TOKEN")")"
chat_id="$(trim "$(read_cfg "TG_CHAT_ID")")"
enabled="$(trim "$(read_cfg "TG_ALERT_ENABLED")")"
cooldown="$(trim "$(read_cfg "TG_ALERT_COOLDOWN")")"
vps_name="$(trim "$(read_cfg "VPS_DISPLAY_NAME")")"
host_name="$(hostname 2>/dev/null | tr -d '\r\n' || true)"
public_ip="$(trim "$(read_cfg "PUBLIC_IP")")"

if [ "$enabled" != "1" ]; then
  exit 0
fi
if [ -z "$bot_token" ] || [ -z "$chat_id" ]; then
  echo "已启用 Telegram 通知，但 TG_BOT_TOKEN 或 TG_CHAT_ID 为空。" >&2
  exit 1
fi
if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
  cooldown="$DEFAULT_COOLDOWN"
fi
if [ -z "$panel_path" ]; then
  panel_path="panel"
fi
if [ -z "$vps_name" ]; then
  vps_name="${host_name:-Xray 节点}"
fi
if [ -z "$host_name" ]; then
  host_name="unknown"
fi
if [ ! -f "$ACCESS_LOG" ]; then
  touch "$ACCESS_LOG"
fi
mkdir -p "$LOCAL_RECORD_DIR" "$(dirname "$GLOBAL_PUSH_STATE")"
cleanup_local_records

api_json="$(curl -s --connect-timeout 2 --max-time 3 "http://127.0.0.1:2053/api-config" 2>/dev/null || true)"
api_prefix="$(echo "$api_json" | sed -n 's/.*"apiPrefix"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
api_prefix="$(normalize_prefix "$api_prefix")"

last_cleanup=0

exec 3< <(tail -n 0 -F "$ACCESS_LOG" 2>/dev/null)
while true; do
  if ! IFS= read -r -t 1 line <&3; then
    flush_batch_alerts
    continue
  fi
  [ -z "$line" ] && continue

  IFS='"' read -r p1 request p3 _ p5 ua _ <<< "$line"
  ip="$(echo "$p1" | awk '{print $1}')"
  req_time="$(echo "$p1" | sed -n 's/.*\[\([^]]*\)\].*/\1/p')"
  method="$(echo "$request" | awk '{print $1}')"
  req_path="$(echo "$request" | awk '{print $2}')"
  status="$(echo "$p3" | awk '{print $1}')"

  [ -z "$ip" ] && continue
  [ -z "$method" ] && continue
  [ -z "$req_path" ] && continue

  kind="auth-fail"
  is_panel_auth=0
  case "$req_path" in
    */api/login|*/api/login\?*|*/api/verify-2fa|*/api/verify-2fa\?*)
      is_panel_auth=1
      ;;
  esac
  if [ -n "$api_prefix" ] && { [[ "$req_path" == "${api_prefix}/api/login"* ]] || [[ "$req_path" == "${api_prefix}/api/verify-2fa"* ]]; }; then
    is_panel_auth=1
  fi
  if [ "$is_panel_auth" -ne 1 ]; then
    continue
  fi
  case "$status" in
    401|403|429) ;;
    *) continue ;;
  esac

  now="$(date +%s)"
  if [ $((now - last_cleanup)) -ge "$CLEANUP_INTERVAL" ]; then
    cleanup_local_records
    last_cleanup="$now"
  fi

  if [ "$ip" = "127.0.0.1" ] || [ "$ip" = "::1" ]; then
    write_local_record "$ip" "$kind" "$method" "$req_path" "$status" "$req_time" "$ua"
    continue
  fi

  append_batch_alert "$ip" "$method" "$req_path" "$status" "$req_time" "$ua"
  flush_batch_alerts
done
EOF
  chmod +x /usr/local/bin/xray-tg-access-alert.sh
}

mgr_write_tg_alert_service() {
  cat > /etc/systemd/system/xray-tg-access-alert.service <<EOF
[Unit]
Description=Xray Nginx Telegram Access Alert
After=network-online.target nginx.service
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/xray-tg-access-alert.sh
Restart=always
RestartSec=5s
Environment=CONFIG_FILE=${CONFIG_FILE}
Environment=QUEUE_LOCK_DIR=/var/lib/xray-backend/security-monitor/queue.lock.d
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=/var/log/nginx -/var/log/xray-tg-access-local -/var/lib/xray-backend
RestrictSUIDSGID=true
LockPersonality=true

[Install]
WantedBy=multi-user.target
EOF
}

mgr_sync_tg_alert_service() {
  local token chat_id
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"

  mgr_write_tg_alert_script
  mgr_write_tg_alert_service
  mgr_write_security_monitor_script
  mgr_write_security_monitor_service
  systemctl daemon-reload

  if mgr_tg_alert_is_enabled && [ -n "$token" ] && [ -n "$chat_id" ]; then
    systemctl enable xray-tg-access-alert >/dev/null 2>&1 || true
    systemctl restart xray-tg-access-alert
    systemctl enable xray-security-monitor.timer >/dev/null 2>&1 || true
    systemctl restart xray-security-monitor.timer >/dev/null 2>&1 || true
    log_info "Telegram 访问告警和安全巡检已启动。"
  else
    systemctl stop xray-tg-access-alert >/dev/null 2>&1 || true
    systemctl disable xray-tg-access-alert >/dev/null 2>&1 || true
    systemctl stop xray-security-monitor.timer >/dev/null 2>&1 || true
    systemctl disable xray-security-monitor.timer >/dev/null 2>&1 || true
    log_info "Telegram 访问告警和安全巡检已关闭。"
  fi
}

mgr_send_tg_test_message() {
  local token chat_id panel_path mode vps_name host_name public_ip
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"
  panel_path="$(mgr_get_panel_path)"
  mode="$(mgr_get_nginx_mode)"
  vps_name="$(read_cfg "VPS_DISPLAY_NAME")"
  host_name="$(hostname 2>/dev/null || echo "unknown")"
  public_ip="$(read_cfg "PUBLIC_IP")"
  if [ -z "$vps_name" ]; then
    vps_name="$host_name"
  fi

  if [ -z "$token" ] || [ -z "$chat_id" ]; then
    log_error "请先配置 TG_BOT_TOKEN 和 TG_CHAT_ID。"
    return 1
  fi

  if curl -fsS --max-time 10 "https://api.telegram.org/bot${token}/sendMessage" \
    -d "chat_id=${chat_id}" \
    -d "disable_web_page_preview=true" \
    --data-urlencode "text=[测试成功] Xray Telegram 通知
节点名称: ${vps_name}
主机名: ${host_name}
公网 IP: ${public_ip:-未配置}
时间: $(date '+%F %T %z')
模式: ${mode}
面板后缀: /${panel_path}
说明: 如果你收到这条消息，说明 Telegram 配置可用。" >/dev/null; then
    log_info "测试消息发送成功。"
    return 0
  fi

  log_error "测试消息发送失败，请检查 Bot Token、Chat ID 或网络连通性。"
  return 1
}

mgr_get_security_alert_ingest_token() {
  local token
  token="$(read_cfg "SECURITY_ALERT_INGEST_TOKEN" | tr -d '\r\n ')"
  if ! [[ "$token" =~ ^[A-Za-z0-9._-]{16,256}$ ]]; then
    token="$(generate_security_alert_ingest_token)"
    save_cfg "SECURITY_ALERT_INGEST_TOKEN" "$token"
  fi
  printf "%s" "$token"
}

mgr_get_security_alert_ingest_url() {
  local panel_domain mode nginx_status server_ip base_url api_prefix
  panel_domain="$(mgr_get_panel_domain)"
  mode="$(mgr_get_nginx_mode)"
  nginx_status="$(systemctl is-active "$NGINX_SERVICE" 2>/dev/null || echo "inactive")"
  server_ip="$(read_cfg "PUBLIC_IP")"
  if [ -z "$server_ip" ] || [ "$server_ip" = "unknown" ]; then
    server_ip="$SERVER_IP"
  fi
  if [ -z "$server_ip" ] || [ "$server_ip" = "unknown" ]; then
    server_ip="$(fetch_public_ip)"
  fi
  base_url="$(mgr_get_panel_base_url "$panel_domain" "$server_ip" "$mode" "$nginx_status")"
  api_prefix="$(mgr_get_panel_api_prefix)"
  if [ -z "$base_url" ]; then
    return 1
  fi
  printf "%s%s/api/system/security-alerts/ingest" "$base_url" "$api_prefix"
}

mgr_manage_tg_alert() {
  clear
  echo -e "${CYAN}==== Telegram 通知管理 ====${NC}"
  echo ""

  local enabled token chat_id cooldown traffic_threshold service_status security_status token_masked vps_name ingest_url ingest_token ingest_token_masked
  enabled="$(read_cfg "TG_ALERT_ENABLED")"
  token="$(read_cfg "TG_BOT_TOKEN")"
  chat_id="$(read_cfg "TG_CHAT_ID")"
  cooldown="$(read_cfg "TG_ALERT_COOLDOWN")"
  traffic_threshold="$(read_cfg "TG_TRAFFIC_ALERT_MBPS")"
  vps_name="$(read_cfg "VPS_DISPLAY_NAME")"
  ingest_url="$(mgr_get_security_alert_ingest_url || true)"
  ingest_token="$(mgr_get_security_alert_ingest_token)"
  service_status="$(systemctl is-active xray-tg-access-alert 2>/dev/null || echo "inactive")"
  security_status="$(systemctl is-active xray-security-monitor.timer 2>/dev/null || echo "inactive")"

  if [ -n "$token" ]; then
    token_masked="$(mgr_mask_secret "$token")"
  else
    token_masked="未设置"
  fi
  ingest_token_masked="$(mgr_mask_secret "$ingest_token")"
  if [ -z "$chat_id" ]; then
    chat_id="未设置"
  fi
  if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
    cooldown="1800"
  fi
  if ! [[ "$traffic_threshold" =~ ^[0-9]+$ ]] || [ "$traffic_threshold" -lt 1 ]; then
    traffic_threshold="500"
  fi
  if [ -z "$vps_name" ]; then
    vps_name="$(hostname 2>/dev/null || echo "Xray 节点")"
  fi

  echo "状态: ${enabled:-0} (1=启用, 0=关闭)"
  echo "访问告警服务: ${service_status}"
  echo "安全巡检定时器: ${security_status}"
  echo "节点名称: ${vps_name}"
  echo "Bot Token: ${token_masked}"
  echo "Chat ID: ${chat_id}"
  echo "告警冷却时间: ${cooldown} 秒"
  echo "流量异常阈值: ${traffic_threshold} Mbps"
  echo "中央上报地址: ${ingest_url:-未生成（请先确认面板公网地址）}"
  echo "中央上报 Token: ${ingest_token_masked}"
  echo ""
  echo "1) 配置节点名称、Token、Chat ID 并启用"
  echo "2) 关闭通知"
  echo "3) 发送测试消息"
  echo "4) 查看服务日志"
  echo "5) 显示无前端接入参数"
  echo "6) 重新生成中央上报 Token"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r tg_choice

  case "$tg_choice" in
    1)
      echo -n "请输入节点名称 / VPS 名称（支持中文）: "
      read -r vps_name
      if [ -z "$vps_name" ]; then
        vps_name="$(hostname 2>/dev/null || echo "Xray 节点")"
      fi
      echo -n "请输入 Telegram Bot Token: "
      read -r token
      if [ -z "$token" ]; then
        log_error "Telegram Bot Token 不能为空。"
        mgr_pause_wait
        return
      fi
      echo -n "请输入 Telegram Chat ID: "
      read -r chat_id
      if [ -z "$chat_id" ]; then
        log_error "Telegram Chat ID 不能为空。"
        mgr_pause_wait
        return
      fi
      echo -n "请输入告警冷却秒数（默认 1800）: "
      read -r cooldown
      if ! [[ "$cooldown" =~ ^[0-9]+$ ]]; then
        cooldown="1800"
      fi
      echo -n "请输入流量异常阈值 Mbps（默认 500）: "
      read -r traffic_threshold
      if ! [[ "$traffic_threshold" =~ ^[0-9]+$ ]] || [ "$traffic_threshold" -lt 1 ]; then
        traffic_threshold="500"
      fi
      save_cfg "VPS_DISPLAY_NAME" "$vps_name"
      save_cfg "TG_BOT_TOKEN" "$token"
      save_cfg "TG_CHAT_ID" "$chat_id"
      save_cfg "TG_ALERT_COOLDOWN" "$cooldown"
      save_cfg "TG_TRAFFIC_ALERT_MBPS" "$traffic_threshold"
      save_cfg "TG_ALERT_ENABLED" "1"
      mgr_sync_tg_alert_service
      mgr_send_tg_test_message || true
      ;;
    2)
      save_cfg "TG_ALERT_ENABLED" "0"
      mgr_sync_tg_alert_service
      ;;
    3)
      mgr_send_tg_test_message || true
      ;;
    4)
      journalctl -u xray-tg-access-alert -u xray-security-monitor.service -n 100 --no-pager || true
      ;;
    5)
      echo ""
      echo "无前端机器接入参数:"
      echo "上报地址: ${ingest_url:-未生成}"
      echo "上报 Token: ${ingest_token}"
      echo "说明: 无前端机器进入 Telegram 通知管理，选择“配置中央面板上报并启用”。"
      ;;
    6)
      ingest_token="$(generate_security_alert_ingest_token)"
      save_cfg "SECURITY_ALERT_INGEST_TOKEN" "$ingest_token"
      echo ""
      echo "新的中央上报 Token: ${ingest_token}"
      echo "注意: 已接入的无前端机器需要同步更新这个 Token。"
      ;;
    *)
      ;;
  esac

  mgr_pause_wait
}

mgr_get_xray_bin() {
  if command -v xray >/dev/null 2>&1; then
    command -v xray
    return
  fi
  if [ -x /usr/local/bin/xray ]; then
    echo "/usr/local/bin/xray"
    return
  fi
  echo ""
}

mgr_generate_uuid() {
  local xray_bin
  xray_bin="$(mgr_get_xray_bin)"
  if [ -n "$xray_bin" ]; then
    "$xray_bin" uuid 2>/dev/null | tr -d '\r\n '
    return
  fi
  cat /proc/sys/kernel/random/uuid 2>/dev/null || echo ""
}

mgr_generate_short_id() {
  local generated
  if command -v openssl >/dev/null 2>&1; then
    generated="$(openssl rand -hex 8 2>/dev/null | tr -d '\r\n ' | tr '[:upper:]' '[:lower:]')"
    if [[ "$generated" =~ ^[a-f0-9]{16}$ ]]; then
      printf "%s" "$generated"
      return
    fi
  fi
  generated="$(tr -dc 'a-f0-9' < /dev/urandom | head -c 16)"
  printf "%s" "$generated"
}

mgr_restart_backend_service() {
  if [ "${MGR_SKIP_BACKEND_RESTART:-0}" = "1" ]; then
    return 0
  fi
  systemctl restart "$BACKEND_SERVICE"
}

mgr_run_backend_command() {
  local command="$1"
  local backend_binary="${INSTALL_DIR}/${BIN_NAME}"

  if [ ! -x "$backend_binary" ]; then
    log_error "未找到后端二进制: $backend_binary"
    return 1
  fi

  (
    cd "$INSTALL_DIR" &&
    "./${BIN_NAME}" "$command"
  )
}

mgr_normalize_reality_short_id() {
  local raw normalized
  raw="$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')"
  normalized="$(printf "%s" "$raw" | tr -cd 'a-f0-9')"
  if [ "${#normalized}" -gt 16 ]; then
    normalized="${normalized:0:16}"
  fi
  if [ $(( ${#normalized} % 2 )) -ne 0 ]; then
    normalized="${normalized%?}"
  fi
  printf "%s" "$normalized"
}

mgr_normalize_reality_short_ids() {
  local raw="$1"
  local normalized output seen part
  local parts=()

  IFS=',' read -r -a parts <<< "$raw"
  output=""
  seen="|"

  for part in "${parts[@]}"; do
    normalized="$(mgr_normalize_reality_short_id "$part")"
    if [ -z "$normalized" ]; then
      continue
    fi
    case "$seen" in
      *"|${normalized}|"*) continue ;;
    esac
    seen="${seen}${normalized}|"
    if [ -n "$output" ]; then
      output="${output},${normalized}"
    else
      output="${normalized}"
    fi
  done

  printf "%s" "$output"
}

mgr_normalize_xhttp_mode() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]' | tr -d ' ')" in
    packet-up|packetup) echo "packet-up" ;;
    stream-up|streamup) echo "stream-up" ;;
    stream-one|streamone) echo "stream-one" ;;
    *) echo "auto" ;;
  esac
}

normalize_node_path() {
  local raw="$1"
  local trimmed
  trimmed="$(echo "$raw" | tr -d '\r\n\t ')"
  trimmed="$(echo "$trimmed" | sed 's#[?#].*$##')"
  trimmed="$(echo "$trimmed" | sed 's#^/*##' | sed 's#/*$##')"
  trimmed="$(echo "$trimmed" | sed 's#[^a-zA-Z0-9/_-]##g')"
  trimmed="$(echo "$trimmed" | sed 's#//*#/#g')"
  if [ -z "$trimmed" ]; then
    trimmed="$(generate_random_suffix)"
  fi
  echo "/${trimmed}"
}

mgr_normalize_location_path() {
  local raw="$1"
  local trimmed
  trimmed="$(echo "$raw" | tr -d '\r\n\t ')"
  trimmed="$(echo "$trimmed" | sed 's#[?#].*$##')"
  trimmed="$(echo "$trimmed" | sed 's#^/*##' | sed 's#/*$##')"
  trimmed="$(echo "$trimmed" | sed 's#//*#/#g')"
  if [ -z "$trimmed" ]; then
    echo ""
    return
  fi
  echo "/${trimmed}"
}

mgr_paths_overlap() {
  local left right
  left="$(mgr_normalize_location_path "$1")"
  right="$(mgr_normalize_location_path "$2")"

  if [ -z "$left" ] || [ -z "$right" ]; then
    return 1
  fi
  if [ "$left" = "$right" ]; then
    return 0
  fi
  case "${left}/" in
    "${right}/"*) return 0 ;;
  esac
  case "${right}/" in
    "${left}/"*) return 0 ;;
  esac
  return 1
}

mgr_resolve_unique_tls_node_path() {
  local raw="$1"
  local panel_path="$2"
  local api_prefix="$3"
  local node_path attempts
  node_path="$(normalize_node_path "$raw")"
  attempts=0

  while mgr_paths_overlap "$node_path" "$panel_path" || \
        mgr_paths_overlap "$node_path" "$api_prefix" || \
        mgr_paths_overlap "$node_path" "/api-config" || \
        mgr_paths_overlap "$node_path" "/assets"; do
    attempts=$((attempts + 1))
    node_path="/$(generate_random_suffix)"
    if [ "$attempts" -ge 32 ]; then
      break
    fi
  done

  echo "$node_path"
}

mgr_get_tls_node_path() {
  local node_path panel_path api_prefix
  panel_path="/$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  node_path="$(read_cfg "TLS_NODE_PATH")"
  node_path="$(mgr_resolve_unique_tls_node_path "$node_path" "$panel_path" "$api_prefix")"
  save_cfg "TLS_NODE_PATH" "$node_path"
  echo "$node_path"
}

mgr_normalize_tls_node_network() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')" in
    xhttp) echo "xhttp" ;;
    *) echo "xhttp" ;;
  esac
}

mgr_get_tls_node_network() {
  local node_network
  node_network="$(mgr_normalize_tls_node_network "$(read_cfg "TLS_NODE_NETWORK")")"
  save_cfg "TLS_NODE_NETWORK" "$node_network"
  echo "$node_network"
}

mgr_normalize_reality_node_network() {
  case "$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')" in
    xhttp) echo "xhttp" ;;
    *) echo "xhttp" ;;
  esac
}

mgr_get_reality_node_network() {
  local node_network
  node_network="$(mgr_normalize_reality_node_network "$(read_cfg "REALITY_NODE_NETWORK")")"
  save_cfg "REALITY_NODE_NETWORK" "$node_network"
  echo "$node_network"
}

mgr_get_reality_node_path() {
  local node_path panel_path api_prefix
  panel_path="/$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  node_path="$(read_cfg "REALITY_NODE_PATH")"
  node_path="$(mgr_resolve_unique_tls_node_path "$node_path" "$panel_path" "$api_prefix")"
  save_cfg "REALITY_NODE_PATH" "$node_path"
  echo "$node_path"
}

mgr_get_tls_node_xhttp_mode() {
  local value
  value="$(mgr_normalize_xhttp_mode "$(read_cfg "TLS_NODE_XHTTP_MODE")")"
  save_cfg "TLS_NODE_XHTTP_MODE" "$value"
  echo "$value"
}

mgr_get_reality_node_xhttp_mode() {
  local value
  value="$(mgr_normalize_xhttp_mode "$(read_cfg "REALITY_NODE_XHTTP_MODE")")"
  save_cfg "REALITY_NODE_XHTTP_MODE" "$value"
  echo "$value"
}

mgr_prompt_xhttp_mode() {
  local scope_label="$1"
  local cfg_key="$2"
  local current_mode choice selected_mode

  current_mode="$(mgr_normalize_xhttp_mode "$(read_cfg "$cfg_key")")"

  echo ""
  echo "${scope_label} XHTTP 模式："
  echo "1) auto（官方默认）"
  echo "2) packet-up"
  echo "3) stream-up"
  echo "4) stream-one"
  echo ""
  echo "当前选择: ${current_mode}"
  echo -n "请选择 [1-4]（回车保持当前）: "
  read -r choice

  case "$choice" in
    2) selected_mode="packet-up" ;;
    3) selected_mode="stream-up" ;;
    4) selected_mode="stream-one" ;;
    *) selected_mode="$current_mode" ;;
  esac

  save_cfg "$cfg_key" "$selected_mode"
  echo "$selected_mode"
}

mgr_generate_reality_keypair() {
  local xray_bin output private_key public_key
  xray_bin="$(mgr_get_xray_bin)"
  if [ -z "$xray_bin" ]; then
    return 1
  fi

  output="$("$xray_bin" x25519 2>&1 || true)"
  private_key="$(printf "%s\n" "$output" | while IFS= read -r line; do
    case "$line" in
      *PrivateKey:*|*Private\ key:*)
        value="${line#*:}"
        value="$(printf "%s" "$value" | tr -d '[:space:]\r')"
        if [ -n "$value" ]; then
          printf "%s" "$value"
          break
        fi
        ;;
    esac
  done)"
  public_key="$(printf "%s\n" "$output" | while IFS= read -r line; do
    case "$line" in
      *"Password (PublicKey):"*|*"Password:"*|*"PublicKey:"*|*"Public key:"*)
        value="${line#*:}"
        value="$(printf "%s" "$value" | tr -d '[:space:]\r')"
        if [ -n "$value" ]; then
          printf "%s" "$value"
          break
        fi
        ;;
    esac
  done)"
  if [ -z "$private_key" ] || [ -z "$public_key" ]; then
    return 1
  fi
  echo "${private_key}|${public_key}"
}

mgr_ensure_sqlite3() {
  if command -v sqlite3 >/dev/null 2>&1; then
    return 0
  fi

  case "$OS" in
    debian)
      apt_get_update_with_retry && apt_get_install_with_retry sqlite3
      ;;
    centos)
      yum install -y sqlite
      ;;
    *)
      return 1
      ;;
  esac

  command -v sqlite3 >/dev/null 2>&1
}

sql_escape() {
  printf "%s" "$1" | sed "s/'/''/g"
}

mgr_generate_nezha_secret() {
  local generated
  if command -v openssl >/dev/null 2>&1; then
    generated="$(openssl rand -hex 24 2>/dev/null | tr -d '\r\n ' | tr '[:upper:]' '[:lower:]')"
    if [[ "$generated" =~ ^[a-f0-9]{48}$ ]]; then
      printf "%s" "$generated"
      return
    fi
  fi
  tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 48
}

mgr_get_nezha_dashboard_secret() {
  local secret
  secret="$(read_cfg "NEZHA_DASHBOARD_AGENT_SECRET" | tr -d '\r\n ')"
  if ! [[ "$secret" =~ ^[A-Za-z0-9._-]{8,128}$ ]]; then
    secret=""
  fi
  if [ -z "$secret" ]; then
    secret="$(mgr_generate_nezha_secret)"
    save_cfg "NEZHA_DASHBOARD_AGENT_SECRET" "$secret"
  fi
  printf "%s" "$secret"
}

mgr_get_nezha_dashboard_port() {
  local port
  port="$(read_cfg "NEZHA_DASHBOARD_PORT" | tr -d '\r\n ')"
  if ! is_valid_port_number "$port"; then
    port="${NEZHA_DASHBOARD_PORT}"
    save_cfg "NEZHA_DASHBOARD_PORT" "$port"
  fi
  printf "%s" "$port"
}

mgr_get_nezha_domain_cfg() {
  local key="$1"
  local raw raw_clean domain
  raw="$(read_cfg "$key")"
  raw_clean="$(printf "%s" "$raw" | tr -d '\r\n\t ')"
  domain="$(normalize_panel_domain "$raw")"

  if [ -n "$raw_clean" ] && [ -z "$domain" ]; then
    save_cfg "$key" ""
  elif [ -n "$domain" ] && [ "$raw_clean" != "$domain" ]; then
    save_cfg "$key" "$domain"
  fi

  printf "%s" "$domain"
}

mgr_get_nezha_dashboard_domain() {
  mgr_get_nezha_domain_cfg "NEZHA_DASHBOARD_DOMAIN"
}

mgr_get_nezha_agent_domain() {
  mgr_get_nezha_domain_cfg "NEZHA_AGENT_COMMUNICATION_DOMAIN"
}

mgr_get_nezha_dashboard_path() {
  local raw_path dashboard_path panel_path
  raw_path="$(read_cfg "NEZHA_DASHBOARD_PATH")"
  dashboard_path="$(normalize_optional_panel_path "$raw_path")"
  panel_path="$(mgr_get_panel_path)"
  if [ -z "$dashboard_path" ] || [ "$dashboard_path" = "$panel_path" ]; then
    dashboard_path="nz$(generate_random_suffix)"
  elif [[ "$dashboard_path" =~ ^[a-z0-9]{10}$ ]]; then
    dashboard_path="nz${dashboard_path}"
  fi
  if [ "$dashboard_path" != "$raw_path" ]; then
    save_cfg "NEZHA_DASHBOARD_PATH" "$dashboard_path"
  fi
  printf "%s" "$dashboard_path"
}

mgr_get_nezha_agent_server() {
  local port host configured_agent_domain
  port="$(mgr_get_nezha_dashboard_port)"
  configured_agent_domain="$(mgr_get_nezha_agent_domain)"
  host="$configured_agent_domain"
  if [ -z "$host" ] || [ "$host" = "127.0.0.1" ] || [ "$host" = "::1" ] || [ "$host" = "localhost" ]; then
    host="$(mgr_get_panel_domain)"
  fi
  if [ -z "$host" ] || [ "$host" = "unknown" ]; then
    host="$(hostname -I 2>/dev/null | awk '{print $1}')"
  fi
  if [ -n "$configured_agent_domain" ]; then
    printf "%s" "${host:-127.0.0.1}"
  else
    printf "%s:%s" "${host:-127.0.0.1}" "$port"
  fi
}

mgr_get_nezha_dashboard_public_url() {
  local port host configured_dashboard_domain dashboard_path panel_domain mode
  port="$(mgr_get_nezha_dashboard_port)"
  configured_dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  dashboard_path="$(mgr_get_nezha_dashboard_path)"
  panel_domain="$(mgr_get_panel_domain)"
  mode="$(mgr_get_nginx_mode)"
  host="$configured_dashboard_domain"
  if [ -z "$host" ] || [ "$host" = "127.0.0.1" ] || [ "$host" = "::1" ]; then
    host="$panel_domain"
  fi
  if [ -z "$host" ] || [ "$host" = "unknown" ]; then
    host="127.0.0.1"
  fi
  if [ -n "$configured_dashboard_domain" ]; then
    printf "https://%s/%s" "$host" "$dashboard_path"
  elif [ -n "$panel_domain" ]; then
    case "$mode" in
      tls|reality)
        printf "https://%s/%s" "$panel_domain" "$dashboard_path"
        ;;
      http)
        printf "http://%s/%s" "$panel_domain" "$dashboard_path"
        ;;
      *)
        printf "http://%s:%s" "$host" "$port"
        ;;
    esac
  else
    printf "http://%s:%s" "$host" "$port"
  fi
}

mgr_nezha_dashboard_uses_panel_domain() {
  local dashboard_domain panel_domain
  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  panel_domain="$(mgr_get_panel_domain)"
  [ -n "$panel_domain" ] && { [ -z "$dashboard_domain" ] || [ "$dashboard_domain" = "$panel_domain" ] || [ "$dashboard_domain" = "127.0.0.1" ] || [ "$dashboard_domain" = "::1" ] || [ "$dashboard_domain" = "localhost" ]; }
}

mgr_nezha_agent_uses_panel_domain() {
  local agent_domain panel_domain
  agent_domain="$(mgr_get_nezha_agent_domain)"
  panel_domain="$(mgr_get_panel_domain)"
  [ -n "$agent_domain" ] && [ -n "$panel_domain" ] && [ "$agent_domain" = "$panel_domain" ]
}

mgr_detect_nezha_dashboard_asset_arch() {
  case "$(uname -m)" in
    x86_64|amd64) echo "amd64" ;;
    aarch64|arm64) echo "arm64" ;;
    armv7l|armv6l) echo "arm" ;;
    *) echo "" ;;
  esac
}

mgr_install_nezha_dashboard_binary() {
  local arch archive_url temp_dir archive_path extract_dir binary_source target_path temp_target
  arch="$(mgr_detect_nezha_dashboard_asset_arch)"
  if [ -z "$arch" ]; then
    log_error "未识别到可用的 Nezha Dashboard 架构。"
    return 1
  fi

  log_info "正在下载 Nezha Dashboard 官方 latest 版本。"
  archive_url="https://github.com/nezhahq/nezha/releases/latest/download/dashboard-linux-${arch}.zip"
  temp_dir="$(mktemp -d "${TMPDIR:-/tmp}/nezha-dashboard.XXXXXX")" || return 1
  archive_path="${temp_dir}/dashboard.zip"
  extract_dir="${temp_dir}/extract"
  mkdir -p "$extract_dir" "$NEZHA_DASHBOARD_DIR"

  if ! download_file_with_fallback "$archive_url" "$archive_path" "Nezha Dashboard"; then
    log_error "Nezha Dashboard 下载失败，请检查服务器网络后重试。"
    rm -rf "$temp_dir"
    return 1
  fi

  if ! unzip -oq "$archive_path" -d "$extract_dir"; then
    log_error "Nezha Dashboard 解压失败。"
    rm -rf "$temp_dir"
    return 1
  fi

  binary_source="$(find "$extract_dir" -type f \( -name "dashboard-linux-${arch}" -o -name 'dashboard' -o -name 'nezha-dashboard' -o -name 'nezha' \) | head -n 1)"
  if [ -z "$binary_source" ] || [ ! -f "$binary_source" ]; then
    log_error "未在 Nezha Dashboard 压缩包中找到可执行文件。"
    rm -rf "$temp_dir"
    return 1
  fi

  target_path="${NEZHA_DASHBOARD_DIR}/app"
  temp_target="${NEZHA_DASHBOARD_DIR}/.app.new.$$"
  rm -f "$temp_target"
  if ! install -m 755 "$binary_source" "$temp_target"; then
    log_error "Nezha Dashboard 写入临时文件失败。"
    rm -f "$temp_target"
    rm -rf "$temp_dir"
    return 1
  fi
  if ! mv -f "$temp_target" "$target_path"; then
    log_error "Nezha Dashboard 替换失败。"
    rm -f "$temp_target"
    rm -rf "$temp_dir"
    return 1
  fi
  rm -rf "$temp_dir"
  log_info "已安装 / 更新 Nezha Dashboard: ${NEZHA_DASHBOARD_DIR}/app"
}

mgr_write_nezha_dashboard_config() {
  local port secret
  port="$(mgr_get_nezha_dashboard_port)"
  secret="$(mgr_get_nezha_dashboard_secret)"
  mkdir -p "${NEZHA_DASHBOARD_DIR}/data"
  cat > "${NEZHA_DASHBOARD_DIR}/data/config.yaml" <<EOF
debug: false
listen_port: ${port}
language: zh_CN
site_name: "Xray Nezha"
install_host: "$(mgr_get_nezha_agent_server | sed 's/"/\\"/g')"
tls: false
agent_secret_key: "$(printf "%s" "$secret" | sed 's/"/\\"/g')"
EOF
  chmod 600 "${NEZHA_DASHBOARD_DIR}/data/config.yaml"
}

mgr_write_nezha_dashboard_service() {
  cat > "/etc/systemd/system/${NEZHA_DASHBOARD_SERVICE}.service" <<EOF
[Unit]
Description=Nezha Dashboard
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${NEZHA_DASHBOARD_DIR}
ExecStart=${NEZHA_DASHBOARD_DIR}/app
Restart=always
RestartSec=5s
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF
}

mgr_build_nezha_dashboard_locations() {
  local dashboard_path dashboard_port api_prefix panel_path panel_domain dashboard_domain login_url auth_endpoint
  dashboard_path="$(mgr_get_nezha_dashboard_path)"
  dashboard_port="$(mgr_get_nezha_dashboard_port)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  panel_path="$(mgr_get_panel_path)"
  panel_domain="$(mgr_get_panel_domain)"
  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  auth_endpoint="${api_prefix}/api/nezha/access/check"
  login_url="/${panel_path}"
  if [ -n "$panel_domain" ] && [ -n "$dashboard_domain" ] && [ "$panel_domain" != "$dashboard_domain" ]; then
    login_url="https://${panel_domain}/${panel_path}"
  fi
  cat <<EOF
    location = /__xray_nezha_auth {
        internal;
        proxy_pass http://127.0.0.1:${PANEL_PORT}${auth_endpoint};
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header X-Requested-With "XMLHttpRequest";
        proxy_set_header Cookie \$http_cookie;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
    }

    location @xray_nezha_login_redirect {
        return 302 ${login_url};
    }

    location @xray_nezha_dashboard_redirect {
        return 302 /${dashboard_path}/dashboard;
    }

    location @xray_nezha_dashboard_prefix_redirect {
        return 302 /${dashboard_path}\$request_uri;
    }

    # Hidden Nezha Dashboard entry.
    location = /${dashboard_path} {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_redirect;
    }

    location = /${dashboard_path}/ {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_redirect;
    }

    # Nezha can still emit root-relative dashboard redirects; keep them under the hidden prefix.
    location = /dashboard {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_prefix_redirect;
    }

    location ^~ /dashboard/ {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_prefix_redirect;
    }

    location = /login {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_prefix_redirect;
    }

    location ^~ /login/ {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        try_files /__xray_nezha_dashboard_redirect_never_exists @xray_nezha_dashboard_prefix_redirect;
    }

    location = /api/v1 {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        proxy_set_header Host \$host;
        proxy_set_header nz-realip \$remote_addr;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
        proxy_pass http://127.0.0.1:${dashboard_port};
    }

    location ^~ /api/v1/ {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        proxy_set_header Host \$host;
        proxy_set_header nz-realip \$remote_addr;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
        proxy_pass http://127.0.0.1:${dashboard_port};
    }

    location ^~ /${dashboard_path}/ {
        auth_request /__xray_nezha_auth;
        error_page 401 403 = @xray_nezha_login_redirect;
        proxy_set_header Host \$host;
        proxy_set_header nz-realip \$remote_addr;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header Origin https://\$host;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
        proxy_buffer_size 128k;
        proxy_buffers 4 256k;
        proxy_busy_buffers_size 256k;
        proxy_max_temp_file_size 0;
        proxy_set_header Accept-Encoding "";
        proxy_redirect http://127.0.0.1:${dashboard_port}/ /${dashboard_path}/;
        proxy_redirect ~^(/.*)$ /${dashboard_path}\$1;
        proxy_cookie_path / /${dashboard_path}/;
        sub_filter_once off;
        sub_filter_types text/css application/javascript text/javascript application/json;
        sub_filter 'href="/' 'href="/${dashboard_path}/';
        sub_filter 'src="/' 'src="/${dashboard_path}/';
        sub_filter 'action="/' 'action="/${dashboard_path}/';
        sub_filter 'url(/' 'url(/${dashboard_path}/';
        sub_filter '"/api/v1' '"/${dashboard_path}/api/v1';
        sub_filter "'/api/v1" "'/${dashboard_path}/api/v1";
        sub_filter '"/dashboard' '"/${dashboard_path}/dashboard';
        sub_filter "'/dashboard" "'/${dashboard_path}/dashboard";
        proxy_pass http://127.0.0.1:${dashboard_port}/;
    }
EOF
}

mgr_build_nezha_agent_grpc_location() {
  cat <<EOF
    # Nezha Agent gRPC Communication
    location ^~ /proto.NezhaService/ {
        grpc_set_header Host \$host;
        grpc_set_header nz-realip \$remote_addr;
        grpc_set_header client_secret \$http_client_secret;
        grpc_set_header client_uuid \$http_client_uuid;
        grpc_read_timeout 600s;
        grpc_send_timeout 600s;
        grpc_socket_keepalive on;
        client_max_body_size 10m;
        grpc_buffer_size 4m;
        grpc_pass grpc://127.0.0.1:$(mgr_get_nezha_dashboard_port);
    }
EOF
}

mgr_build_nezha_shared_upstream() {
  return 0
}

mgr_build_nezha_panel_upstream() {
  if mgr_nezha_dashboard_uses_panel_domain || mgr_nezha_agent_uses_panel_domain; then
    mgr_build_nezha_shared_upstream
  fi
}

mgr_build_nezha_panel_domain_locations() {
  local locations=""
  if mgr_nezha_dashboard_uses_panel_domain; then
    locations="${locations}
$(mgr_build_nezha_dashboard_locations)"
  fi
  if mgr_nezha_agent_uses_panel_domain; then
    locations="${locations}
$(mgr_build_nezha_agent_grpc_location)"
  fi
  printf "%s" "$locations"
}

mgr_write_nezha_nginx_config() {
  local dashboard_domain agent_domain panel_domain conf_path enable_path
  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  agent_domain="$(mgr_get_nezha_agent_domain)"
  panel_domain="$(mgr_get_panel_domain)"
  if [ -z "$dashboard_domain" ] && [ -z "$agent_domain" ]; then
    return 0
  fi

  mgr_get_nginx_conf_paths
  if [ -n "$NGINX_ENABLE_DIR" ]; then
    conf_path="/etc/nginx/sites-available/${NEZHA_NGINX_CONF_NAME}"
    enable_path="${NGINX_ENABLE_DIR}/${NEZHA_NGINX_CONF_NAME}"
  else
    conf_path="/etc/nginx/conf.d/${NEZHA_NGINX_CONF_NAME}.conf"
    enable_path=""
  fi
  mkdir -p "$(dirname "$conf_path")"

  {
    mgr_build_nezha_shared_upstream
    if [ -n "$dashboard_domain" ] && [ "$dashboard_domain" != "$panel_domain" ]; then
      cat <<EOF
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name ${dashboard_domain};
    server_tokens off;
    access_log /var/log/nginx/access.log;
    error_log /dev/null crit;

    ssl_certificate /etc/certs/${dashboard_domain}.crt;
    ssl_certificate_key /etc/certs/${dashboard_domain}.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_timeout 1d;
    underscores_in_headers on;
    ignore_invalid_headers off;

EOF
      if [ -n "$agent_domain" ] && [ "$agent_domain" = "$dashboard_domain" ]; then
        mgr_build_nezha_agent_grpc_location
      fi
      mgr_build_nezha_dashboard_locations
      cat <<EOF

    location / {
        return 404;
    }
}

EOF
    fi
    if [ -n "$agent_domain" ] && [ "$agent_domain" != "$dashboard_domain" ] && [ "$agent_domain" != "$panel_domain" ]; then
      cat <<EOF
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name ${agent_domain};
    server_tokens off;
    access_log /var/log/nginx/access.log;
    error_log /dev/null crit;

    ssl_certificate /etc/certs/${agent_domain}.crt;
    ssl_certificate_key /etc/certs/${agent_domain}.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_timeout 1d;
    underscores_in_headers on;
    ignore_invalid_headers off;

EOF
      mgr_build_nezha_agent_grpc_location
      cat <<EOF
    location / {
        return 404;
    }
}
EOF
    fi
  } > "$conf_path"

  if [ -n "$enable_path" ]; then
    mkdir -p "$NGINX_ENABLE_DIR"
    ln -sf "$conf_path" "$enable_path"
  fi
}

mgr_sync_nezha_panel_settings() {
  local db_file="${INSTALL_DIR}/data.db"
  local now dashboard_url dashboard_domain agent_domain dashboard_path
  if [ ! -f "$db_file" ]; then
    log_warn "未找到面板数据库，暂不能自动写入 Nezha 监控源。"
    return 1
  fi
  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 不可用，暂不能自动写入 Nezha 监控源。"
    return 1
  fi

  now="$(date +%s)"
  dashboard_url="$(mgr_get_nezha_dashboard_public_url)"
  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  agent_domain="$(mgr_get_nezha_agent_domain)"
  dashboard_path="$(mgr_get_nezha_dashboard_path)"
  sqlite3 "$db_file" "INSERT INTO app_settings (\`key\`, value, created_at, updated_at) VALUES ('nezha_enabled','true',${now},${now}) ON CONFLICT(\`key\`) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;"
  sqlite3 "$db_file" "INSERT INTO app_settings (\`key\`, value, created_at, updated_at) VALUES ('nezha_dashboard_url','$(sql_escape "$dashboard_url")',${now},${now}) ON CONFLICT(\`key\`) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;"
  sqlite3 "$db_file" "INSERT INTO app_settings (\`key\`, value, created_at, updated_at) VALUES ('nezha_dashboard_domain','$(sql_escape "$dashboard_domain")',${now},${now}) ON CONFLICT(\`key\`) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;"
  sqlite3 "$db_file" "INSERT INTO app_settings (\`key\`, value, created_at, updated_at) VALUES ('nezha_dashboard_path','$(sql_escape "$dashboard_path")',${now},${now}) ON CONFLICT(\`key\`) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;"
  sqlite3 "$db_file" "INSERT INTO app_settings (\`key\`, value, created_at, updated_at) VALUES ('nezha_agent_communication_domain','$(sql_escape "$agent_domain")',${now},${now}) ON CONFLICT(\`key\`) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;"
}

mgr_install_nezha_dashboard() {
  log_step "安装 / 更新 Nezha Dashboard"
  mgr_write_nezha_dashboard_config
  if [ -n "$(mgr_get_nezha_dashboard_domain)" ] || [ -n "$(mgr_get_nezha_agent_domain)" ]; then
    mgr_ensure_nezha_certificates || log_warn "Nezha 独立域名证书申请失败，仍会继续更新 Dashboard；Nginx 配置可能暂不能启用。"
  fi
  mgr_write_nezha_nginx_config
  mgr_install_nezha_dashboard_binary || return 1
  mgr_write_nezha_dashboard_service
  systemctl daemon-reload
  systemctl enable --now "$NEZHA_DASHBOARD_SERVICE" >/dev/null 2>&1 || true
  systemctl restart "$NEZHA_DASHBOARD_SERVICE"
  if [ -z "$(mgr_get_nezha_dashboard_domain)" ] && [ -z "$(mgr_get_nezha_agent_domain)" ]; then
    firewall_allow_port "$(mgr_get_nezha_dashboard_port)"
  else
    firewall_remove_port "$(mgr_get_nezha_dashboard_port)"
  fi
  firewall_reload
  if [ -n "$(mgr_get_nezha_dashboard_domain)" ] || [ -n "$(mgr_get_nezha_agent_domain)" ]; then
    if mgr_validate_nginx_config; then
      mgr_apply_nginx_service || true
    else
      log_warn "Nezha Nginx 配置校验失败，请检查域名证书是否存在。"
    fi
  fi
  if mgr_nezha_dashboard_uses_panel_domain || mgr_nezha_agent_uses_panel_domain; then
    mgr_refresh_active_nginx_mode || log_warn "刷新面板 Nginx 配置失败，哪吒随机路径可能暂未生效。"
  fi
  mgr_sync_nezha_panel_settings || true
  log_info "Nezha Dashboard 已启动。"
}

mgr_refresh_nezha_dashboard_runtime() {
  log_step "刷新 Nezha Dashboard / Agent 域名配置"
  mgr_write_nezha_dashboard_config
  if [ -n "$(mgr_get_nezha_dashboard_domain)" ] || [ -n "$(mgr_get_nezha_agent_domain)" ]; then
    mgr_ensure_nezha_certificates || {
      log_error "Nezha 独立域名证书申请失败，请确认 DNS 已解析到本机且 80 端口可访问。"
      return 1
    }
    firewall_remove_port "$(mgr_get_nezha_dashboard_port)"
  else
    firewall_allow_port "$(mgr_get_nezha_dashboard_port)"
  fi
  mgr_write_nezha_nginx_config
  if [ -x "${NEZHA_DASHBOARD_DIR}/app" ]; then
    mgr_write_nezha_dashboard_service
    systemctl daemon-reload
    systemctl enable --now "$NEZHA_DASHBOARD_SERVICE" >/dev/null 2>&1 || true
    systemctl restart "$NEZHA_DASHBOARD_SERVICE" || true
  fi
  firewall_reload
  if [ -n "$(mgr_get_nezha_dashboard_domain)" ] || [ -n "$(mgr_get_nezha_agent_domain)" ]; then
    if mgr_validate_nginx_config; then
      mgr_apply_nginx_service || return 1
    else
      log_error "Nezha Nginx 配置校验失败，请检查域名证书是否存在。"
      return 1
    fi
  fi
  if mgr_nezha_dashboard_uses_panel_domain || mgr_nezha_agent_uses_panel_domain; then
    mgr_refresh_active_nginx_mode || {
      log_error "刷新面板 Nginx 配置失败，哪吒随机路径不会生效。"
      return 1
    }
  fi
  mgr_sync_nezha_panel_settings || true
  log_info "已刷新 Nezha Dashboard / Agent 域名配置。"
}

mgr_manage_nezha_dashboard() {
  clear
  echo -e "${CYAN}==== Nezha Dashboard 管理 ====${NC}"
  echo ""

  local status public_url local_url agent_server secret secret_masked choice dashboard_domain agent_domain
  status="$(systemctl is-active "$NEZHA_DASHBOARD_SERVICE" 2>/dev/null || echo "inactive")"
  public_url="$(mgr_get_nezha_dashboard_public_url)"
  local_url="http://127.0.0.1:$(mgr_get_nezha_dashboard_port)"
  agent_server="$(mgr_get_nezha_agent_server)"
  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  agent_domain="$(mgr_get_nezha_agent_domain)"
  secret="$(mgr_get_nezha_dashboard_secret)"
  secret_masked="$(printf "%s" "$secret" | sed 's/^\(.\{6\}\).*\(.\{6\}\)$/\1...\2/')"

  echo "服务状态: ${status}"
  echo "Dashboard 公网地址: ${public_url}"
  echo "Dashboard 本机 API 地址: ${local_url}"
  echo "Dashboard 独立域名: ${dashboard_domain:-未设置}"
  echo "Agent 通信域名: ${agent_domain:-未设置}"
  echo "默认后台: ${public_url}/dashboard"
  echo "默认账号: admin / admin"
  echo "Agent 通信地址: ${agent_server}"
  echo "Agent 连接密钥: ${secret_masked}"
  echo ""
  echo "说明: 首次进入 Nezha 后台后，请创建 API Token，并填到 Xray 面板的哪吒管理页。"
  echo "说明: Nezha Agent 使用 Dashboard 用户绑定的连接密钥，和 Agent 安装参数保持一致。"
  echo ""
  echo "1) 设置 Dashboard / Agent 独立域名"
  echo "2) 安装 / 更新 Dashboard、Nginx 并写入 Xray 面板监控源"
  echo "3) 重新生成 Agent 连接密钥并重启 Dashboard"
  echo "4) 同步 Xray 面板监控源"
  echo "5) 查看服务状态"
  echo "6) 查看最近日志"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r choice

  case "$choice" in
    1)
      echo -n "Dashboard 访问域名（例 nezha.example.com，留空保留当前）: "
      read -r dashboard_domain
      if [ -n "$dashboard_domain" ]; then
        save_cfg "NEZHA_DASHBOARD_DOMAIN" "$dashboard_domain"
      fi
      echo -n "Agent 通信域名（例 nezha-agent.example.com，留空保留当前）: "
      read -r agent_domain
      if [ -n "$agent_domain" ]; then
        save_cfg "NEZHA_AGENT_COMMUNICATION_DOMAIN" "$agent_domain"
      fi
      mgr_write_nezha_dashboard_config
      if [ -n "$(mgr_get_nezha_dashboard_domain)" ] || [ -n "$(mgr_get_nezha_agent_domain)" ]; then
        mgr_ensure_nezha_certificates || log_warn "Nezha 独立域名证书申请失败，请确认 DNS 已解析到本机且 80 端口可访问。"
      fi
      mgr_write_nezha_nginx_config
      if mgr_validate_nginx_config; then
        mgr_apply_nginx_service || true
      else
        log_warn "Nezha Nginx 配置校验失败，请检查域名证书是否存在。"
      fi
      if mgr_nezha_dashboard_uses_panel_domain || mgr_nezha_agent_uses_panel_domain; then
        mgr_refresh_active_nginx_mode || log_warn "刷新面板 Nginx 配置失败，哪吒随机路径可能暂未生效。"
      fi
      mgr_sync_nezha_panel_settings || true
      log_info "已保存 Nezha 独立域名配置并尝试自动申请证书。"
      ;;
    2)
      mgr_install_nezha_dashboard
      ;;
    3)
      save_cfg "NEZHA_DASHBOARD_AGENT_SECRET" "$(mgr_generate_nezha_secret)"
      mgr_write_nezha_dashboard_config
      mgr_write_nezha_nginx_config
      systemctl restart "$NEZHA_DASHBOARD_SERVICE" || true
      mgr_sync_nezha_panel_settings || true
      log_info "已重新生成 Agent 连接密钥。无前端机器需要重新同步 Agent 配置。"
      ;;
    4)
      mgr_sync_nezha_panel_settings && log_info "已同步 Xray 面板监控源。"
      ;;
    5)
      systemctl status "$NEZHA_DASHBOARD_SERVICE" --no-pager || true
      ;;
    6)
      journalctl -u "$NEZHA_DASHBOARD_SERVICE" -n 80 --no-pager || true
      ;;
    *) ;;
  esac

  mgr_pause_wait
}

mgr_ensure_reality_443_inbound() {
  local db_file="${INSTALL_DIR}/data.db"
  local now domain camouflage sni existing_id managed_id port_owner_id row
  local tag uuid private_key public_key short_ids current_sni
  local reality_network reality_path reality_flow reality_host reality_service reality_xhttp_mode
  local keypair

  if [ ! -f "$db_file" ]; then
    log_warn "Database not found: $db_file"
    return 1
  fi

  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 is unavailable, skip auto-creating Reality inbound."
    return 1
  fi

  now="$(date +%s)"
  domain="$(mgr_get_panel_domain)"
  camouflage="$(mgr_get_camouflage_site)"
  if [ -n "$camouflage" ]; then
    sni="$camouflage"
  elif [ -n "$domain" ]; then
    sni="$domain"
  else
    sni="$(pick_random_camouflage_site)"
    log_warn "Reality SNI fallback is empty, temporary fallback to ${sni}."
  fi
  reality_network="$(mgr_get_reality_node_network)"
  reality_path=""
  reality_flow=""
  reality_host=""
  reality_service=""
  if [ "$reality_network" = "tcp" ]; then
    reality_flow="xtls-rprx-vision"
  else
    reality_path="$(mgr_get_reality_node_path)"
    reality_host="$domain"
    reality_xhttp_mode="$(mgr_get_reality_node_xhttp_mode)"
    reality_service="$reality_xhttp_mode"
  fi

  managed_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE tag LIKE 'reality-443-auto%' ORDER BY id LIMIT 1;")"
  port_owner_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE port=443 ORDER BY id LIMIT 1;")"

  if [ -n "$managed_id" ] && { [ -z "$port_owner_id" ] || [ "$managed_id" = "$port_owner_id" ]; }; then
    existing_id="$managed_id"
  elif [ -n "$port_owner_id" ]; then
    log_warn "Port 443 is already used by inbound id=${port_owner_id}; skip auto-overwrite. Configure Reality inbound manually if needed."
    return 1
  else
    existing_id=""
  fi

  if [ -n "$existing_id" ]; then
    row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(uuid,''),COALESCE(private_key,''),COALESCE(public_key,''),COALESCE(short_ids,''),COALESCE(sni,'') FROM inbounds WHERE id=${existing_id} LIMIT 1;")"
    IFS='|' read -r tag uuid private_key public_key short_ids current_sni <<< "$row"
  else
    tag="reality-443-auto"
  fi

  if [ -z "$uuid" ]; then
    uuid="$(mgr_generate_uuid)"
  fi
  if [ -z "$uuid" ]; then
    log_warn "生成 Reality 入站 UUID 失败。"
    return 1
  fi

  if [ -z "$private_key" ] || [ -z "$public_key" ]; then
    keypair="$(mgr_generate_reality_keypair)"
    if [ -z "$keypair" ]; then
      log_warn "生成 Reality 入站 X25519 密钥失败。"
      return 1
    fi
    IFS='|' read -r private_key public_key <<< "$keypair"
  fi

  if [ -z "$existing_id" ]; then
    short_ids="$(mgr_generate_short_id)"
  else
    short_ids="$(mgr_normalize_reality_short_ids "$short_ids")"
    if [ -z "$short_ids" ]; then
      short_ids="$(mgr_generate_short_id)"
    fi
  fi
  if [ -z "$tag" ]; then
    tag="reality-443-auto"
  fi
  current_sni="$sni"

  if [ -z "$existing_id" ]; then
    local base_tag="$tag"
    local suffix=1
    while [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE tag='$(sql_escape "$tag")';")" != "0" ]; do
      tag="${base_tag}-${suffix}"
      suffix=$((suffix + 1))
    done

    if ! sqlite3 "$db_file" "INSERT INTO inbounds (tag, protocol, listen, port, uuid, flow, transport, net_path, net_host, net_service, security, sni, target, public_key, private_key, short_ids, spider_x, up_time, down_time, total_quota, expire_time, enable, created_at, updated_at) VALUES ('$(sql_escape "$tag")','vless','',443,'$(sql_escape "$uuid")','$(sql_escape "$reality_flow")','$(sql_escape "$reality_network")','$(sql_escape "$reality_path")','$(sql_escape "$reality_host")','$(sql_escape "$reality_service")','reality','$(sql_escape "$current_sni")','127.0.0.1:${FALLBACK_PORT}','$(sql_escape "$public_key")','$(sql_escape "$private_key")','$(sql_escape "$short_ids")','/',0,0,0,0,1,${now},${now});"; then
      log_error "自动创建 Reality 443 入站失败。请检查端口冲突或数据库结构是否匹配当前脚本。"
      return 1
    fi
  else
    if ! sqlite3 "$db_file" "UPDATE inbounds SET protocol='vless', listen='', port=443, uuid='$(sql_escape "$uuid")', flow='$(sql_escape "$reality_flow")', transport='$(sql_escape "$reality_network")', net_path='$(sql_escape "$reality_path")', net_host='$(sql_escape "$reality_host")', net_service='$(sql_escape "$reality_service")', security='reality', sni='$(sql_escape "$current_sni")', target='127.0.0.1:${FALLBACK_PORT}', public_key='$(sql_escape "$public_key")', private_key='$(sql_escape "$private_key")', short_ids='$(sql_escape "$short_ids")', spider_x='/', enable=1, updated_at=${now} WHERE id=${existing_id};"; then
      log_error "更新受管 Reality 443 入站失败。请检查数据库状态后重试。"
      return 1
    fi
  fi

  save_cfg "REALITY_NODE_NETWORK" "$reality_network"
  if [ "$reality_network" = "xhttp" ]; then
    save_cfg "REALITY_NODE_PATH" "$reality_path"
    save_cfg "REALITY_NODE_XHTTP_MODE" "$reality_service"
  fi
  mgr_restart_backend_service
  if [ "$reality_network" = "xhttp" ]; then
    log_info "已确认 Reality 443 入站可用，并已重启后端。传输协议: XHTTP，模式: ${reality_service}，SNI: ${current_sni}，节点路径: ${reality_path}"
  else
    log_info "已确认 Reality 443 入站可用，并已重启后端。传输协议: TCP (RAW)，SNI: ${current_sni}"
  fi
  return 0
}

mgr_prepare_reality_fallback_port() {
  local db_file="${INSTALL_DIR}/data.db"
  local now managed_id port_owner_id row current_tag

  if [ ! -f "$db_file" ]; then
    return 0
  fi

  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 不可用，跳过 Reality 回落端口 ${FALLBACK_PORT} 的预检查。"
    return 0
  fi

  managed_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE tag LIKE 'nginx-tls-${FALLBACK_PORT}-auto%' ORDER BY id LIMIT 1;")"
  port_owner_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE port=${FALLBACK_PORT} AND enable=1 ORDER BY id LIMIT 1;")"

  if [ -z "$port_owner_id" ]; then
    return 0
  fi

  if [ -n "$managed_id" ] && [ "$managed_id" = "$port_owner_id" ]; then
    now="$(date +%s)"
    sqlite3 "$db_file" "UPDATE inbounds SET enable=0, updated_at=${now} WHERE id=${managed_id};"
    mgr_restart_backend_service
  log_info "已停用受管 TLS 回落入站 ${FALLBACK_PORT}，为 Reality mode 释放端口。"
    return 0
  fi

  row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(protocol,'') FROM inbounds WHERE id=${port_owner_id} LIMIT 1;")"
  IFS='|' read -r current_tag _ <<< "$row"
  log_error "端口 ${FALLBACK_PORT} 已被入站 id=${port_owner_id}（tag=${current_tag:-unknown}）占用，请先停用或迁移该入站后再启用 Reality mode。"
  return 1
}
mgr_ensure_tls_12345_inbound() {
  local domain="$1"
  local node_path="$2"
  local db_file="${INSTALL_DIR}/data.db"
  local now existing_id managed_id port_owner_id row tag uuid current_path existing_path existing_protocol
  local tls_network net_service base_tag suffix tls_xhttp_mode

  if [ -z "$domain" ]; then
    log_warn "未绑定域名，跳过自动创建 Nginx TLS 前置入站。"
    return 1
  fi
  if [ ! -f "$db_file" ]; then
    log_warn "未找到数据库文件: $db_file"
    return 1
  fi
  if ! mgr_ensure_sqlite3; then
    log_warn "sqlite3 不可用，跳过自动创建 Nginx TLS 前置入站。"
    return 1
  fi

  node_path="$(mgr_resolve_unique_tls_node_path "$node_path" "/$(mgr_get_panel_path)" "$(mgr_get_panel_api_prefix)")"
  tls_network="$(mgr_get_tls_node_network)"
  net_service=""
  if [ "$tls_network" = "xhttp" ]; then
    tls_xhttp_mode="$(mgr_get_tls_node_xhttp_mode)"
    net_service="$tls_xhttp_mode"
  fi
  now="$(date +%s)"
  managed_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE tag LIKE 'nginx-tls-${FALLBACK_PORT}-auto%' ORDER BY id LIMIT 1;")"
  port_owner_id="$(sqlite3 "$db_file" "SELECT id FROM inbounds WHERE port=${FALLBACK_PORT} ORDER BY id LIMIT 1;")"

  if [ -n "$managed_id" ]; then
    existing_id="$managed_id"
  elif [ -n "$port_owner_id" ]; then
    log_warn "端口 ${FALLBACK_PORT} 已被入站 id=${port_owner_id} 占用，跳过自动覆盖，请手动处理。"
    return 1
  else
    existing_id=""
  fi

  if [ -n "$existing_id" ]; then
    row="$(sqlite3 -separator '|' "$db_file" "SELECT COALESCE(tag,''),COALESCE(uuid,''),COALESCE(net_path,''),COALESCE(protocol,'') FROM inbounds WHERE id=${existing_id} LIMIT 1;")"
    IFS='|' read -r tag uuid existing_path existing_protocol <<< "$row"
  else
    tag="nginx-tls-${FALLBACK_PORT}-auto"
    existing_path=""
  fi

  existing_protocol="vless"
  if [ -z "$uuid" ]; then
    uuid="$(mgr_generate_uuid)"
  fi
  if [ -z "$uuid" ]; then
    log_warn "生成 Nginx TLS 前置入站 UUID 失败。"
    return 1
  fi
  current_path="$node_path"
  if [ -z "$current_path" ]; then
    current_path="$existing_path"
  fi
  current_path="$(normalize_node_path "$current_path")"

  if [ -z "$existing_id" ]; then
    base_tag="$tag"
    suffix=1
    while [ "$(sqlite3 "$db_file" "SELECT COUNT(1) FROM inbounds WHERE tag='$(sql_escape "$tag")';")" != "0" ]; do
      tag="${base_tag}-${suffix}"
      suffix=$((suffix + 1))
    done
    if ! sqlite3 "$db_file" "INSERT INTO inbounds (tag, protocol, listen, port, uuid, flow, transport, net_path, net_host, net_service, security, sni, tls_min_version, tls_alpn, tls_use_file, tls_cert_file, tls_key_file, tls_cert_content, tls_key_content, tls_ech_key, tls_ech_config, target, public_key, private_key, reality_u_tls, short_ids, spider_x, up_time, down_time, total_quota, expire_time, enable, created_at, updated_at) VALUES ('$(sql_escape "$tag")','$(sql_escape "$existing_protocol")','',${FALLBACK_PORT},'$(sql_escape "$uuid")','','$(sql_escape "$tls_network")','$(sql_escape "$current_path")','$(sql_escape "$domain")','$(sql_escape "$net_service")','none','','','',0,'','','','','','','','','','chrome','','/',0,0,0,0,1,${now},${now});"; then
      log_error "自动创建 Nginx TLS 前置入站 ${FALLBACK_PORT} 失败。请检查端口冲突或数据库结构是否匹配当前脚本。"
      return 1
    fi
  else
    if ! sqlite3 "$db_file" "UPDATE inbounds SET protocol='$(sql_escape "$existing_protocol")', listen='', port=${FALLBACK_PORT}, uuid='$(sql_escape "$uuid")', flow='', transport='$(sql_escape "$tls_network")', net_path='$(sql_escape "$current_path")', net_host='$(sql_escape "$domain")', net_service='$(sql_escape "$net_service")', security='none', sni='', tls_min_version='', tls_alpn='', tls_use_file=0, tls_cert_file='', tls_key_file='', tls_cert_content='', tls_key_content='', tls_ech_key='', tls_ech_config='', target='', public_key='', private_key='', reality_u_tls='chrome', short_ids='', spider_x='/', enable=1, updated_at=${now} WHERE id=${existing_id};"; then
      log_error "更新受管 Nginx TLS 前置入站 ${FALLBACK_PORT} 失败。请检查数据库状态后重试。"
      return 1
    fi
  fi

  save_cfg "TLS_NODE_PATH" "$current_path"
  save_cfg "TLS_NODE_NETWORK" "$tls_network"
  if [ "$tls_network" = "xhttp" ]; then
    save_cfg "TLS_NODE_XHTTP_MODE" "$net_service"
  fi
  mgr_restart_backend_service
  if [ "$tls_network" = "xhttp" ]; then
    log_info "已确认 Nginx TLS 前置入站 ${FALLBACK_PORT} 可用，传输协议: ${tls_network}，模式: ${net_service}，节点路径: ${current_path}"
  else
    log_info "已确认 Nginx TLS 前置入站 ${FALLBACK_PORT} 可用，传输协议: ${tls_network}，节点路径: ${current_path}"
  fi
  return 0
}

mgr_issue_ssl_certificate() {
  local domain="$1"
  local acme_bin="$HOME/.acme.sh/acme.sh"
  local email nginx_was_active=0 acme_installer=""
  local issue_ret=1

  if [ -z "$domain" ]; then
    return 1
  fi

  email="xray$(date +%s)$RANDOM@qq.com"

  firewall_allow_port 80
  firewall_reload

  if systemctl is-active --quiet "$NGINX_SERVICE"; then
    nginx_was_active=1
    systemctl stop "$NGINX_SERVICE" || true
  fi

  SSL_ISSUER_TOOL=""

  if [ ! -x "$acme_bin" ]; then
    acme_installer="$(mktemp "${TMPDIR:-/tmp}/acme-install.XXXXXX")" || acme_installer=""
    if [ -n "$acme_installer" ] &&
      curl -fsSL --connect-timeout 10 --max-time 60 https://get.acme.sh -o "$acme_installer" &&
      [ -s "$acme_installer" ] &&
      sh "$acme_installer"; then
      rm -f "$acme_installer"
    else
      [ -n "$acme_installer" ] && rm -f "$acme_installer"
      log_warn "acme.sh 在线安装失败，准备回退到 certbot。"
    fi
  fi

  if [ -x "$acme_bin" ]; then
    "$acme_bin" --set-default-ca --server letsencrypt >/dev/null 2>&1 || true
    "$acme_bin" --register-account -m "$email" --server letsencrypt >/dev/null 2>&1 || true
    if "$acme_bin" --issue -d "$domain" --standalone --server letsencrypt; then
      issue_ret=0
      SSL_ISSUER_TOOL="acme.sh"
      restore_http_firewall_policy
      return 0
    else
      issue_ret=$?
    fi
    log_warn "acme.sh 申请证书失败，准备回退到 certbot。"
  fi

  if ! command -v certbot >/dev/null 2>&1; then
    case "$OS" in
      debian)
        export DEBIAN_FRONTEND=noninteractive
        apt_get_update_with_retry || true
        apt_get_install_with_retry certbot || true
        ;;
      centos)
        yum install -y certbot || {
          yum install -y epel-release || true
          yum install -y certbot || true
        }
        ;;
      *)
        log_error "当前系统暂不支持自动安装 certbot。"
        issue_ret=1
        ;;
    esac
  fi

  if command -v certbot >/dev/null 2>&1; then
    if certbot certonly --standalone --preferred-challenges http -d "$domain" \
      --non-interactive --agree-tos -m "$email" --keep-until-expiring; then
      issue_ret=0
      SSL_ISSUER_TOOL="certbot"
      restore_http_firewall_policy
      return 0
    else
      issue_ret=$?
    fi
  fi

  if [ "$issue_ret" -ne 0 ] && [ "$nginx_was_active" -eq 1 ]; then
    systemctl start "$NGINX_SERVICE" || true
  fi

  restore_http_firewall_policy

  return "$issue_ret"
}

mgr_install_issued_certificate_for_domain() {
  local domain="$1"

  if [ -z "$domain" ]; then
    return 1
  fi

  mkdir -p /etc/certs
  chmod 755 /etc/certs

  if [ "$SSL_ISSUER_TOOL" = "certbot" ]; then
    if [ ! -f "/etc/letsencrypt/live/${domain}/privkey.pem" ] || [ ! -f "/etc/letsencrypt/live/${domain}/fullchain.pem" ]; then
      log_error "未找到 certbot 生成的证书文件: ${domain}"
      return 1
    fi
    ln -sfn "/etc/letsencrypt/live/${domain}/privkey.pem" "/etc/certs/${domain}.key"
    ln -sfn "/etc/letsencrypt/live/${domain}/fullchain.pem" "/etc/certs/${domain}.crt"
  else
    if [ ! -x "$HOME/.acme.sh/acme.sh" ]; then
      log_error "未找到 acme.sh，无法安装证书: ${domain}"
      return 1
    fi
    "$HOME/.acme.sh/acme.sh" --install-cert -d "$domain" \
      --key-file "/etc/certs/${domain}.key" \
      --fullchain-file "/etc/certs/${domain}.crt"
    chmod 644 "/etc/certs/${domain}.crt" >/dev/null 2>&1 || true
    chmod 600 "/etc/certs/${domain}.key" >/dev/null 2>&1 || true
  fi

  if [ ! -f "/etc/certs/${domain}.crt" ] || [ ! -f "/etc/certs/${domain}.key" ]; then
    log_error "证书安装后仍未找到: /etc/certs/${domain}.crt 和 /etc/certs/${domain}.key"
    return 1
  fi

  case "$SSL_ISSUER_TOOL" in
    acme.sh|certbot)
      save_cfg "SSL_ISSUER_TOOL" "$SSL_ISSUER_TOOL"
      ;;
  esac
  log_info "已安装证书: /etc/certs/${domain}.crt 和 /etc/certs/${domain}.key"
}

mgr_ensure_certificate_for_domain() {
  local domain="$1"

  if [ -z "$domain" ]; then
    return 0
  fi

  mgr_repair_panel_certificate_links "$domain" || true
  if [ -f "/etc/certs/${domain}.crt" ] && [ -f "/etc/certs/${domain}.key" ]; then
    log_info "已检测到证书文件: ${domain}"
    return 0
  fi

  log_info "未检测到 ${domain} 证书，开始自动申请。"
  if ! mgr_issue_ssl_certificate "$domain"; then
    log_error "自动申请证书失败: ${domain}"
    return 1
  fi
  mgr_install_issued_certificate_for_domain "$domain"
}

mgr_ensure_nezha_certificates() {
  local dashboard_domain agent_domain failed=0

  dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  agent_domain="$(mgr_get_nezha_agent_domain)"

  if [ -n "$dashboard_domain" ]; then
    mgr_ensure_certificate_for_domain "$dashboard_domain" || failed=1
  fi
  if [ -n "$agent_domain" ] && [ "$agent_domain" != "$dashboard_domain" ]; then
    mgr_ensure_certificate_for_domain "$agent_domain" || failed=1
  fi

  sync_ssl_renewal_timer || true
  [ "$failed" -eq 0 ]
}

mgr_normalize_api_prefix() {
  local prefix="$1"
  local segment
  prefix="$(printf "%s" "$prefix" | tr -d '\r\n\t ')"

  if [ -z "$prefix" ]; then
    echo ""
    return
  fi

  case "$prefix" in
    /*) ;;
    *) prefix="/$prefix" ;;
  esac

  while [ "${#prefix}" -gt 1 ] && [ "${prefix%/}" != "$prefix" ]; do
    prefix="${prefix%/}"
  done

  if [ "$prefix" = "/" ]; then
    echo ""
    return
  fi

  segment="${prefix#/}"
  if [ -z "$segment" ] || [ "${#segment}" -gt 64 ] || [[ "$segment" == */* ]] || ! [[ "$segment" =~ ^[A-Za-z0-9_-]+$ ]]; then
    echo ""
    return
  fi

  echo "$prefix"
}

mgr_get_panel_api_prefix() {
  local api_json prefix sqlite_prefix cached_prefix db_file attempt

  for attempt in 1 2 3; do
    api_json="$(curl -s --connect-timeout 2 --max-time 3 "http://127.0.0.1:${PANEL_PORT}/api-config" 2>/dev/null || true)"
    if printf "%s" "$api_json" | grep -q '"apiPrefix"'; then
      break
    fi
    sleep 1
  done

  prefix="$(echo "$api_json" | sed -n 's/.*"apiPrefix"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
  prefix="$(mgr_normalize_api_prefix "$prefix")"

  if [ -n "$prefix" ]; then
    save_cfg "API_PREFIX" "$prefix"
    echo "$prefix"
    return
  fi

  db_file="${INSTALL_DIR}/data.db"
  if [ -f "$db_file" ] && mgr_ensure_sqlite3 >/dev/null 2>&1; then
    sqlite_prefix="$(sqlite3 "$db_file" "SELECT value FROM app_settings WHERE \`key\`='api_prefix' ORDER BY id DESC LIMIT 1;" 2>/dev/null || true)"
    sqlite_prefix="$(mgr_normalize_api_prefix "$sqlite_prefix")"
    if [ -n "$sqlite_prefix" ]; then
      save_cfg "API_PREFIX" "$sqlite_prefix"
      echo "$sqlite_prefix"
      return
    fi
  fi

  cached_prefix="$(mgr_normalize_api_prefix "$(read_cfg "API_PREFIX")")"
  if [ -n "$cached_prefix" ]; then
    echo "$cached_prefix"
    return
  fi

  echo ""
}

mgr_get_panel_base_url() {
  local domain="$1"
  local server_ip="$2"
  local mode="$3"
  local nginx_status="$4"
  local public_host=""

  if [ "$nginx_status" = "active" ]; then
    case "$mode" in
      tls|reality)
        if [ -n "$domain" ]; then
          echo "https://${domain}"
          return
        fi
        ;;
      http)
        public_host="$domain"
        if [ -z "$public_host" ]; then
          public_host="$server_ip"
        fi
        if [ -n "$public_host" ] && [ "$public_host" != "127.0.0.1" ] && [ "$public_host" != "::1" ]; then
          echo "http://${public_host}"
          return
        fi
        ;;
    esac
  fi

  if [ -n "$server_ip" ] && [ "$server_ip" != "127.0.0.1" ] && [ "$server_ip" != "::1" ]; then
    echo "http://${server_ip}:${PANEL_PORT}"
    return
  fi

  echo ""
}

mgr_build_panel_url() {
  local base_url="$1"
  local panel_path="$2"

  if [ -z "$base_url" ]; then
    echo ""
    return
  fi

  panel_path="${panel_path#/}"
  if [ -z "$panel_path" ]; then
    echo "$base_url"
    return
  fi

  echo "${base_url}/${panel_path}"
}

mgr_get_nginx_conf_paths() {
  if [ -d /etc/nginx/sites-available ] && [ -f /etc/nginx/nginx.conf ] && grep -Eq '^[[:space:]]*include[[:space:]]+(/etc/nginx/)?sites-enabled/[*][^;]*;' /etc/nginx/nginx.conf; then
    NGINX_PANEL_CONF="/etc/nginx/sites-available/xray-panel"
    NGINX_FALLBACK_CONF="/etc/nginx/sites-available/xray-fallback"
    NGINX_ENABLE_DIR="/etc/nginx/sites-enabled"
  else
    mkdir -p /etc/nginx/conf.d
    NGINX_PANEL_CONF="/etc/nginx/conf.d/xray-panel.conf"
    NGINX_FALLBACK_CONF="/etc/nginx/conf.d/xray-fallback.conf"
    NGINX_ENABLE_DIR=""
  fi
}

mgr_backup_nginx_state() {
  local backup_dir="$1"
  mkdir -p "$backup_dir"

  [ -e "$NGINX_PANEL_CONF" ] && cp -a "$NGINX_PANEL_CONF" "$backup_dir/panel.conf"
  [ -e "$NGINX_FALLBACK_CONF" ] && cp -a "$NGINX_FALLBACK_CONF" "$backup_dir/fallback.conf"
  [ -e /etc/nginx/conf.d/xray-panel.conf ] && cp -a /etc/nginx/conf.d/xray-panel.conf "$backup_dir/conf-d-panel.conf"
  [ -e /etc/nginx/conf.d/xray-fallback.conf ] && cp -a /etc/nginx/conf.d/xray-fallback.conf "$backup_dir/conf-d-fallback.conf"
  [ -e /etc/nginx/sites-available/xray-panel ] && cp -a /etc/nginx/sites-available/xray-panel "$backup_dir/sites-available-panel.conf"
  [ -e /etc/nginx/sites-available/xray-fallback ] && cp -a /etc/nginx/sites-available/xray-fallback "$backup_dir/sites-available-fallback.conf"

  if [ -n "$NGINX_ENABLE_DIR" ]; then
    [ -e "$NGINX_ENABLE_DIR/xray-panel" ] && cp -a "$NGINX_ENABLE_DIR/xray-panel" "$backup_dir/enabled-panel"
    [ -e "$NGINX_ENABLE_DIR/xray-fallback" ] && cp -a "$NGINX_ENABLE_DIR/xray-fallback" "$backup_dir/enabled-fallback"
  fi
  [ -e /etc/nginx/sites-enabled/xray-panel ] && cp -a /etc/nginx/sites-enabled/xray-panel "$backup_dir/sites-enabled-panel"
  [ -e /etc/nginx/sites-enabled/xray-fallback ] && cp -a /etc/nginx/sites-enabled/xray-fallback "$backup_dir/sites-enabled-fallback"
}

mgr_restore_nginx_state() {
  local backup_dir="$1"

  rm -f "$NGINX_PANEL_CONF" "$NGINX_FALLBACK_CONF"
  rm -f /etc/nginx/conf.d/xray-panel.conf /etc/nginx/conf.d/xray-fallback.conf 2>/dev/null || true
  rm -f /etc/nginx/sites-available/xray-panel /etc/nginx/sites-available/xray-fallback 2>/dev/null || true
  rm -f /etc/nginx/sites-enabled/xray-panel /etc/nginx/sites-enabled/xray-fallback 2>/dev/null || true
  [ -e "$backup_dir/panel.conf" ] && cp -a "$backup_dir/panel.conf" "$NGINX_PANEL_CONF"
  [ -e "$backup_dir/fallback.conf" ] && cp -a "$backup_dir/fallback.conf" "$NGINX_FALLBACK_CONF"
  [ -e "$backup_dir/conf-d-panel.conf" ] && cp -a "$backup_dir/conf-d-panel.conf" /etc/nginx/conf.d/xray-panel.conf
  [ -e "$backup_dir/conf-d-fallback.conf" ] && cp -a "$backup_dir/conf-d-fallback.conf" /etc/nginx/conf.d/xray-fallback.conf
  if [ -d /etc/nginx/sites-available ]; then
    [ -e "$backup_dir/sites-available-panel.conf" ] && cp -a "$backup_dir/sites-available-panel.conf" /etc/nginx/sites-available/xray-panel
    [ -e "$backup_dir/sites-available-fallback.conf" ] && cp -a "$backup_dir/sites-available-fallback.conf" /etc/nginx/sites-available/xray-fallback
  fi

  if [ -n "$NGINX_ENABLE_DIR" ]; then
    rm -f "$NGINX_ENABLE_DIR/xray-panel" "$NGINX_ENABLE_DIR/xray-fallback"
    [ -e "$backup_dir/enabled-panel" ] && cp -a "$backup_dir/enabled-panel" "$NGINX_ENABLE_DIR/xray-panel"
    [ -e "$backup_dir/enabled-fallback" ] && cp -a "$backup_dir/enabled-fallback" "$NGINX_ENABLE_DIR/xray-fallback"
  fi
  if [ -d /etc/nginx/sites-enabled ]; then
    [ -e "$backup_dir/sites-enabled-panel" ] && cp -a "$backup_dir/sites-enabled-panel" /etc/nginx/sites-enabled/xray-panel
    [ -e "$backup_dir/sites-enabled-fallback" ] && cp -a "$backup_dir/sites-enabled-fallback" /etc/nginx/sites-enabled/xray-fallback
  fi
}

mgr_enable_nginx_conf() {
  local panel_conf="$1"
  local fallback_conf="$2"

  if [ -n "$NGINX_ENABLE_DIR" ]; then
    mkdir -p "$NGINX_ENABLE_DIR"
    rm -f "$NGINX_ENABLE_DIR/default"
    rm -f /etc/nginx/conf.d/xray-panel.conf /etc/nginx/conf.d/xray-fallback.conf
    ln -sf "$panel_conf" "$NGINX_ENABLE_DIR/xray-panel"
    if [ -f "$fallback_conf" ]; then
      ln -sf "$fallback_conf" "$NGINX_ENABLE_DIR/xray-fallback"
    else
      rm -f "$NGINX_ENABLE_DIR/xray-fallback"
    fi
  else
    rm -f /etc/nginx/sites-enabled/xray-panel /etc/nginx/sites-enabled/xray-fallback 2>/dev/null || true
  fi

  rm -f /etc/nginx/conf.d/default.conf
}

mgr_validate_nginx_config() {
  local output
  if output="$(nginx -t 2>&1)"; then
    return 0
  fi

  printf "%s\n" "$output" >&2
  return 1
}

mgr_apply_nginx_service() {
  systemctl enable "$NGINX_SERVICE"

  if systemctl is-active --quiet "$NGINX_SERVICE"; then
    if systemctl reload "$NGINX_SERVICE"; then
      return 0
    fi
    log_warn "Nginx reload 失败，回退到 restart。"
  fi

  systemctl restart "$NGINX_SERVICE"
}

mgr_build_nginx_websocket_map() {
  cat <<'EOF'
map $http_upgrade $xray_connection_upgrade {
    default upgrade;
    '' close;
}

map $http_user_agent $xray_blog_block_ua {
    default 0;
    '' 1;
    ~*(ahrefsbot|amazonbot|bytespider|ccbot|claudebot|curl|dotbot|facebookexternalhit|go-http-client|gptbot|headlesschrome|httpclient|java/|libwww-perl|mj12bot|nikto|okhttp|petalbot|phantomjs|python-requests|python-urllib|scrapy|semrushbot|selenium|wget|yandexbot|zgrab|zgrab2|httpx|sqlmap) 1;
}

limit_req_zone $binary_remote_addr zone=xray_blog_page_rate:10m rate=20r/m;
limit_req_zone $binary_remote_addr zone=xray_blog_asset_rate:10m rate=120r/m;
limit_req_zone $binary_remote_addr zone=xray_subscription_rate:10m rate=30r/m;
limit_conn_zone $binary_remote_addr zone=xray_blog_conn:10m;
limit_conn_zone $binary_remote_addr zone=xray_subscription_conn:10m;
EOF
}

mgr_build_nginx_real_ip_config() {
  cat <<'EOF'
    set_real_ip_from 127.0.0.1;
    set_real_ip_from ::1;
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    set_real_ip_from 2400:cb00::/32;
    set_real_ip_from 2606:4700::/32;
    set_real_ip_from 2803:f800::/32;
    set_real_ip_from 2405:b500::/32;
    set_real_ip_from 2405:8100::/32;
    set_real_ip_from 2a06:98c0::/29;
    set_real_ip_from 2c0f:f248::/32;
    real_ip_header CF-Connecting-IP;
    real_ip_recursive on;
EOF
}

mgr_build_api_prefix_location() {
  local api_prefix="$1"
  if [ -z "$api_prefix" ]; then
    echo ""
    return
  fi

  cat <<EOF
    location ^~ ${api_prefix}/ {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }
EOF
}

mgr_build_subscription_location() {
  local api_prefix="$1"
  if [ -z "$api_prefix" ]; then
    echo ""
    return
  fi

  cat <<EOF
    location = ${api_prefix}/subscriptions/clash.yaml {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location = ${api_prefix}/subscriptions/v2r.txt {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location = ${api_prefix}/subscriptions/sub {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }
EOF
}


mgr_build_default_api_locations() {
  cat <<EOF
    location ^~ /api/ {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ^~ /ws/ {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    # If nginx was generated before the API prefix was persisted, still forward runtime-learned prefix routes.
    location ~ "^/[A-Za-z0-9_-]{1,64}/(api|ws)/" {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ~ "^/[A-Za-z0-9_-]{1,64}/subscriptions/clash[.]yaml$" {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ~ "^/[A-Za-z0-9_-]{1,64}/subscriptions/v2r[.]txt$" {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ~ "^/[A-Za-z0-9_-]{1,64}/subscriptions/sub$" {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        access_log off;
        add_header Cache-Control "no-store" always;
        limit_req_status 429;
        limit_req zone=xray_subscription_rate burst=12 nodelay;
        limit_conn xray_subscription_conn 8;

        proxy_http_version 1.1;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }
EOF
}
mgr_build_panel_locations() {
  local panel_path="$1"
  local api_prefix="$2"
  local api_prefix_location default_api_locations subscription_location
  api_prefix_location="$(mgr_build_api_prefix_location "$api_prefix")"
  default_api_locations="$(mgr_build_default_api_locations)"
  subscription_location="$(mgr_build_subscription_location "$api_prefix")"

  cat <<EOF
    location = /${panel_path} {
        proxy_pass http://127.0.0.1:${PANEL_PORT}/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ^~ /${panel_path}/ {
        proxy_pass http://127.0.0.1:${PANEL_PORT}/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 75s;
        proxy_send_timeout 75s;
    }

    location ^~ /assets/ {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
    }

    location = /api-config {
        proxy_pass http://127.0.0.1:${PANEL_PORT}/api-config;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
    }

${subscription_location}

${default_api_locations}

${api_prefix_location}
EOF
}

mgr_configure_nginx_http() {
  local domain="$1"
  local panel_path api_prefix panel_locations root_location websocket_map real_ip_config nezha_upstream nezha_panel_locations
  local nginx_backup_dir
  panel_path="$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  panel_locations="$(mgr_build_panel_locations "$panel_path" "$api_prefix")"
  root_location="$(mgr_build_root_location)"
  websocket_map="$(mgr_build_nginx_websocket_map)"
  real_ip_config="$(mgr_build_nginx_real_ip_config)"
  nezha_upstream="$(mgr_build_nezha_panel_upstream)"
  nezha_panel_locations="$(mgr_build_nezha_panel_domain_locations)"

  mgr_get_nginx_conf_paths
  mkdir -p "$(dirname "$NGINX_PANEL_CONF")"
  nginx_backup_dir="$(mktemp -d)"
  mgr_backup_nginx_state "$nginx_backup_dir"
  mgr_ensure_local_camouflage_template

  cat > "$NGINX_PANEL_CONF" <<EOF
${websocket_map}
${nezha_upstream}

server {
    listen 80;
    server_name ${domain:-_};
    server_tokens off;
${real_ip_config}
    access_log /var/log/nginx/access.log;
    error_log /dev/null crit;

${panel_locations}

${nezha_panel_locations}

${root_location}
}
EOF

  rm -f "$NGINX_FALLBACK_CONF"
  mgr_enable_nginx_conf "$NGINX_PANEL_CONF" "$NGINX_FALLBACK_CONF"

  if mgr_validate_nginx_config; then
    if ! mgr_apply_nginx_service; then
      mgr_restore_nginx_state "$nginx_backup_dir"
      log_error "Nginx 启动失败，已恢复原配置。"
      rm -rf "$nginx_backup_dir"
      return 1
    fi
    mgr_apply_firewall_for_mode "http"
    save_cfg "NGINX_MODE" "http"
    mgr_sync_tg_alert_service || true
    log_info "已完成 Nginx HTTP mode 配置。"
    log_info "防火墙已关闭面板直连端口 ${PANEL_PORT}。"
    log_info "根路径显示$(mgr_get_root_camouflage_label)，/${panel_path} 访问面板。"
  else
    mgr_restore_nginx_state "$nginx_backup_dir"
    log_error "Nginx 配置检测失败。"
    rm -rf "$nginx_backup_dir"
    return 1
  fi
  rm -rf "$nginx_backup_dir"
}

mgr_build_tls_node_locations() {
  local node_path="$1"
  local node_network="$2"

  case "$node_network" in
    xhttp)
      cat <<EOF
    location = ${node_path} {
        grpc_pass grpc://127.0.0.1:${FALLBACK_PORT};
        grpc_set_header Host \$host;
        grpc_set_header X-Real-IP \$remote_addr;
        grpc_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        grpc_set_header X-Forwarded-Proto \$scheme;
        grpc_set_header X-Forwarded-Host \$host;
        grpc_connect_timeout 8s;
        grpc_read_timeout 300s;
        grpc_send_timeout 300s;
    }

    location ^~ ${node_path}/ {
        grpc_pass grpc://127.0.0.1:${FALLBACK_PORT};
        grpc_set_header Host \$host;
        grpc_set_header X-Real-IP \$remote_addr;
        grpc_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        grpc_set_header X-Forwarded-Proto \$scheme;
        grpc_set_header X-Forwarded-Host \$host;
        grpc_connect_timeout 8s;
        grpc_read_timeout 300s;
        grpc_send_timeout 300s;
    }
EOF
      ;;
    *)
      cat <<EOF
    location = ${node_path} {
        proxy_pass http://127.0.0.1:${FALLBACK_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }

    location ^~ ${node_path}/ {
        proxy_pass http://127.0.0.1:${FALLBACK_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;

        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$xray_connection_upgrade;
        proxy_connect_timeout 8s;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }
EOF
      ;;
  esac
}

mgr_refresh_active_nginx_mode() {
  local mode panel_domain
  mode="$(mgr_get_nginx_mode)"
  panel_domain="$(mgr_get_panel_domain)"

  case "$mode" in
    tls)
      if [ -z "$panel_domain" ]; then
        log_warn "当前未绑定域名，跳过刷新 TLS mode。"
        return 1
      fi
      MGR_USE_SAVED_NODE_SETTINGS=1 mgr_configure_nginx_tls "$panel_domain"
      ;;
    reality)
      if [ -z "$panel_domain" ]; then
        log_warn "当前未绑定域名，跳过刷新 Reality mode。"
        return 1
      fi
      MGR_USE_SAVED_NODE_SETTINGS=1 mgr_configure_nginx_reality "$panel_domain"
      ;;
    http)
      mgr_configure_nginx_http "$panel_domain"
      ;;
    *)
      log_warn "当前未启用受管 Nginx 模式，跳过刷新。"
      return 1
      ;;
  esac
}

mgr_configure_nginx_tls() {
  local domain="$1"
  local panel_path api_prefix panel_locations node_path node_network root_location_https node_locations websocket_map real_ip_config nezha_upstream nezha_panel_locations
  local nginx_backup_dir

  if [ -z "$domain" ]; then
    log_error "TLS mode 必须先绑定域名。"
    return 1
  fi
  if ! mgr_require_panel_certificate_files "$domain" "TLS mode"; then
    return 1
  fi

  panel_path="$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  save_cfg "TLS_NODE_NETWORK" "xhttp"
  node_network="$(mgr_get_tls_node_network)"
  mgr_get_tls_node_xhttp_mode >/dev/null
  node_path="$(mgr_get_tls_node_path)"
  panel_locations="$(mgr_build_panel_locations "$panel_path" "$api_prefix")"
  root_location_https="$(mgr_build_root_location)"
  node_locations="$(mgr_build_tls_node_locations "$node_path" "$node_network")"
  websocket_map="$(mgr_build_nginx_websocket_map)"
  real_ip_config="$(mgr_build_nginx_real_ip_config)"
  nezha_upstream="$(mgr_build_nezha_panel_upstream)"
  nezha_panel_locations="$(mgr_build_nezha_panel_domain_locations)"

  mgr_get_nginx_conf_paths
  mkdir -p "$(dirname "$NGINX_PANEL_CONF")"
  nginx_backup_dir="$(mktemp -d)"
  mgr_backup_nginx_state "$nginx_backup_dir"
  mgr_ensure_local_camouflage_template

  cat > "$NGINX_PANEL_CONF" <<EOF
${websocket_map}
${nezha_upstream}

server {
    listen 443 ssl;
    http2 on;
    server_name ${domain};
    server_tokens off;
${real_ip_config}
    access_log /var/log/nginx/access.log;
    error_log /dev/null crit;

    ssl_certificate /etc/certs/${domain}.crt;
    ssl_certificate_key /etc/certs/${domain}.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    error_page 497 = @xray_plain_http_drop;

    location @xray_plain_http_drop {
        internal;
        return 444;
    }

${panel_locations}

${node_locations}

${nezha_panel_locations}

${root_location_https}
}
EOF

  rm -f "$NGINX_FALLBACK_CONF"
  mgr_enable_nginx_conf "$NGINX_PANEL_CONF" "$NGINX_FALLBACK_CONF"

  if mgr_validate_nginx_config; then
    if ! mgr_apply_nginx_service; then
      mgr_restore_nginx_state "$nginx_backup_dir"
      log_error "Nginx 启动失败，已恢复原配置。"
      rm -rf "$nginx_backup_dir"
      return 1
    fi
    mgr_apply_firewall_for_mode "tls"
    save_cfg "NGINX_MODE" "tls"
    mgr_sync_tg_alert_service || true
    tls_inbound_ready=0
    if mgr_ensure_tls_12345_inbound "$domain" "$node_path"; then
      tls_inbound_ready=1
    else
      log_warn "自动创建 Nginx TLS 前置入站 ${FALLBACK_PORT} 失败。"
    fi
    log_info "已完成 Nginx TLS mode 配置（443 由 Nginx 占用）。"
    log_info "防火墙已关闭面板直连端口 ${PANEL_PORT}。"
    log_info "根路径显示$(mgr_get_root_camouflage_label)，/${panel_path} 访问面板。"
    log_info "TLS 节点路径: ${node_path}"
    if [ "$tls_inbound_ready" = "1" ]; then
      log_info "已自动创建/同步 VLESS + XHTTP + TLS 分享节点：443 对外，12345 本机 NONE 入站，模式: $(mgr_get_tls_node_xhttp_mode)。"
    else
      log_warn "VLESS + XHTTP + TLS 分享节点尚未创建成功，请修复上方错误后重试 Nginx TLS mode。"
    fi
  else
    mgr_restore_nginx_state "$nginx_backup_dir"
    log_error "Nginx 配置检测失败。"
    rm -rf "$nginx_backup_dir"
    return 1
  fi
  rm -rf "$nginx_backup_dir"
}

mgr_configure_nginx_reality() {
  local domain="$1"
  local panel_path api_prefix panel_locations root_location_https reality_network reality_path websocket_map
  local previous_mode revert_mode_on_failure real_ip_config nginx_backup_dir nezha_upstream nezha_panel_locations

  if [ -z "$domain" ]; then
    log_error "Reality mode 必须先绑定域名。"
    return 1
  fi
  if ! mgr_require_panel_certificate_files "$domain" "Reality mode"; then
    return 1
  fi

  previous_mode="$(mgr_get_nginx_mode)"
  revert_mode_on_failure=0
  if [ "$previous_mode" != "reality" ]; then
    # Persist the target mode before restarting the backend to release the
    # fallback port, otherwise backend startup may auto-heal the managed TLS
    # inbound and reclaim 12345 during the mode switch.
    save_cfg "NGINX_MODE" "reality"
    revert_mode_on_failure=1
  fi

  if ! mgr_prepare_reality_fallback_port; then
    if [ "$revert_mode_on_failure" = "1" ]; then
      save_cfg "NGINX_MODE" "$previous_mode"
    fi
    return 1
  fi

  panel_path="$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"
  save_cfg "REALITY_NODE_NETWORK" "xhttp"
  reality_network="$(mgr_get_reality_node_network)"
  mgr_get_reality_node_xhttp_mode >/dev/null
  reality_path="$(mgr_get_reality_node_path)"
  panel_locations="$(mgr_build_panel_locations "$panel_path" "$api_prefix")"
  root_location_https="$(mgr_build_root_location)"
  websocket_map="$(mgr_build_nginx_websocket_map)"
  real_ip_config="$(mgr_build_nginx_real_ip_config)"
  nezha_upstream="$(mgr_build_nezha_panel_upstream)"
  nezha_panel_locations="$(mgr_build_nezha_panel_domain_locations)"

  mgr_get_nginx_conf_paths
  mkdir -p "$(dirname "$NGINX_PANEL_CONF")"
  nginx_backup_dir="$(mktemp -d)"
  mgr_backup_nginx_state "$nginx_backup_dir"
  mgr_ensure_local_camouflage_template

  cat > "$NGINX_PANEL_CONF" <<EOF
${websocket_map}
${nezha_upstream}

server {
    listen ${FALLBACK_PORT} ssl;
    server_name ${domain};
    server_tokens off;
${real_ip_config}
    access_log /var/log/nginx/access.log;
    error_log /dev/null crit;

    ssl_certificate /etc/certs/${domain}.crt;
    ssl_certificate_key /etc/certs/${domain}.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    error_page 497 = @xray_plain_http_drop;

    location @xray_plain_http_drop {
        internal;
        return 444;
    }

${panel_locations}

${nezha_panel_locations}

${root_location_https}
}
EOF

  rm -f "$NGINX_FALLBACK_CONF"
  mgr_enable_nginx_conf "$NGINX_PANEL_CONF" "$NGINX_FALLBACK_CONF"

  if mgr_validate_nginx_config; then
    if ! mgr_apply_nginx_service; then
      mgr_restore_nginx_state "$nginx_backup_dir"
      if [ "$revert_mode_on_failure" = "1" ]; then
        save_cfg "NGINX_MODE" "$previous_mode"
        mgr_restart_backend_service || true
      fi
      log_error "Nginx 启动失败，已回滚后端运行模式。"
      rm -rf "$nginx_backup_dir"
      return 1
    fi
    mgr_apply_firewall_for_mode "reality"
    save_cfg "NGINX_MODE" "reality"
    revert_mode_on_failure=0
    mgr_sync_tg_alert_service || true
    if ! mgr_ensure_reality_443_inbound; then
      log_error "Reality mode 未完成：自动创建 443 Reality 入站失败，请先排查 443 端口对应的数据库入站记录后重试。"
      rm -rf "$nginx_backup_dir"
      return 1
    fi
    log_info "已完成 Reality mode 配置。"
    log_info "面板通过 Reality 回落链路使用 HTTPS 加密（Nginx:${FALLBACK_PORT} + 证书）。"
    log_info "防火墙已关闭面板直连端口 ${PANEL_PORT}。"
    log_info "请确认 Xray 占用 443，Reality 的 dest 指向 127.0.0.1:${FALLBACK_PORT}。"
    log_info "根路径显示$(mgr_get_root_camouflage_label)，/${panel_path} 访问面板。"
    log_info "已自动创建/同步 VLESS + XHTTP + Reality 节点：443 对外，模式: $(mgr_get_reality_node_xhttp_mode)，节点路径: ${reality_path}。"
  else
    mgr_restore_nginx_state "$nginx_backup_dir"
    if [ "$revert_mode_on_failure" = "1" ]; then
      save_cfg "NGINX_MODE" "$previous_mode"
      mgr_restart_backend_service || true
    fi
    log_error "Nginx 配置检测失败。"
    rm -rf "$nginx_backup_dir"
    return 1
  fi
  rm -rf "$nginx_backup_dir"
}

mgr_bind_domain() {
  clear
  echo -e "${CYAN}==== 绑定域名与 SSL ====${NC}"
  echo ""

  local current_domain domain
  current_domain="$(mgr_get_panel_domain)"
  if [ -n "$current_domain" ]; then
    echo "当前域名: $current_domain"
  fi

  echo -n "请输入域名（例如 panel.example.com）: "
  read -r domain
  domain="$(normalize_panel_domain "$domain")"
  if [ -z "$domain" ]; then
    log_error "域名不能为空。"
    mgr_pause_wait
    return
  fi

  save_cfg "PANEL_DOMAIN" "$domain"

  echo ""
  echo "1) 自动申请 SSL（acme.sh 独立模式）"
  echo "2) 使用已有证书文件"
  echo "3) 仅保存域名"
  echo ""
  echo -n "请选择: "
  read -r ssl_choice

  case "$ssl_choice" in
    1)
      if mgr_issue_ssl_certificate "$domain"; then
        mkdir -p /etc/certs
        if [ "$SSL_ISSUER_TOOL" = "certbot" ]; then
          if [ ! -f "/etc/letsencrypt/live/${domain}/privkey.pem" ] || [ ! -f "/etc/letsencrypt/live/${domain}/fullchain.pem" ]; then
            log_error "未找到 certbot 生成的证书文件。"
            mgr_pause_wait
            return
          fi
          ln -sfn "/etc/letsencrypt/live/${domain}/privkey.pem" "/etc/certs/${domain}.key"
          ln -sfn "/etc/letsencrypt/live/${domain}/fullchain.pem" "/etc/certs/${domain}.crt"
          systemctl enable certbot.timer >/dev/null 2>&1 || true
          systemctl start certbot.timer >/dev/null 2>&1 || true
        else
          "$HOME/.acme.sh/acme.sh" --install-cert -d "$domain" \
            --key-file "/etc/certs/${domain}.key" \
            --fullchain-file "/etc/certs/${domain}.crt"
        fi
        save_cfg "SSL_ISSUER_TOOL" "$SSL_ISSUER_TOOL"
        sync_ssl_renewal_timer
        systemctl stop "$NGINX_SERVICE" >/dev/null 2>&1 || true
        systemctl disable "$NGINX_SERVICE" >/dev/null 2>&1 || true
        if [ "$SSL_ISSUER_TOOL" = "certbot" ]; then
          log_info "已通过 certbot 安装 SSL 证书。"
        else
          log_info "已通过 acme.sh 安装 SSL 证书。"
        fi
        log_info "Nginx 暂未启动，请前往 Nginx 管理中手动启动并选择模式。"
      else
        log_error "SSL 申请失败。"
      fi
      ;;
    2)
      echo "请将证书放到: /etc/certs/${domain}.crt"
      echo "请将私钥放到: /etc/certs/${domain}.key"
      echo -n "证书已准备好？(y/n): "
      read -r uploaded
      if [ "$uploaded" = "y" ]; then
        if [ -f "/etc/certs/${domain}.crt" ] && [ -f "/etc/certs/${domain}.key" ]; then
          save_cfg "SSL_ISSUER_TOOL" "manual"
          sync_ssl_renewal_timer
          systemctl stop "$NGINX_SERVICE" >/dev/null 2>&1 || true
          systemctl disable "$NGINX_SERVICE" >/dev/null 2>&1 || true
          log_info "已检测到证书文件。"
          log_info "Nginx 暂未启动，请前往 Nginx 管理中手动启动并选择模式。"
        else
          log_error "未找到证书文件。"
        fi
      fi
      ;;
    3)
      save_cfg "SSL_ISSUER_TOOL" "manual"
      sync_ssl_renewal_timer
      log_info "域名已保存。"
      ;;
    *)
      log_warn "已取消。"
      ;;
  esac

  mgr_pause_wait
}

mgr_select_nginx_mode() {
  clear
  echo -e "${CYAN}==== Nginx 模式管理 ====${NC}"
  echo ""

  local panel_domain panel_path api_prefix
  panel_domain="$(mgr_get_panel_domain)"
  panel_path="$(mgr_get_panel_path)"
  api_prefix="$(mgr_get_panel_api_prefix)"

  echo "绑定域名: ${panel_domain:-未绑定}"
  echo "面板端口: ${PANEL_PORT}"
  echo "面板后缀: /${panel_path}"
  echo "API 前缀: ${api_prefix:-未生成}"
  echo ""
  echo "1) TLS mode（自动创建 VLESS + XHTTP + TLS 分享节点）"
  echo "2) Reality mode（自动创建 VLESS + XHTTP + Reality 节点）"
  echo "3) HTTP mode（开放 80，启用 HTTP 伪装）"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r mode_choice

  case "$mode_choice" in
    1) mgr_configure_nginx_tls "$panel_domain" ;;
    2) mgr_configure_nginx_reality "$panel_domain" ;;
    3) mgr_configure_nginx_http "$panel_domain" ;;
    *) ;;
  esac

  mgr_pause_wait
}

mgr_manage_nginx() {
  clear
  echo -e "${CYAN}==== Nginx 管理 ====${NC}"
  echo ""

  local nginx_status
  nginx_status="$(systemctl is-active "$NGINX_SERVICE" 2>/dev/null || echo "inactive")"
  echo "当前状态: $nginx_status"
  echo ""
  echo "1) 安装/更新 Nginx"
  echo "2) 启动 Nginx 并选择模式"
  echo "3) 停止 Nginx"
  echo "4) 切换伪装模式"
  echo "5) 设置 Nginx/Reality 伪装域名"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r choice

  case "$choice" in
    1)
      mgr_install_or_update_nginx_package
      ;;
    2)
      systemctl enable nginx
      mgr_select_nginx_mode
      return
      ;;
    3)
      systemctl stop nginx
      mgr_sync_tg_alert_service || true
      mgr_restore_panel_direct_access
      log_info "Nginx stopped."
      ;;
    4)
      mgr_select_nginx_mode
      return
      ;;
    5)
      mgr_set_camouflage_site
      return
      ;;
    *) ;;
  esac

  mgr_pause_wait
}

mgr_manage_firewall() {
  clear
  echo -e "${CYAN}==== 防火墙管理 ====${NC}"
  echo ""

  local fw_type current_ssh_port
  fw_type="$(detect_firewall_tool)"
  current_ssh_port="$(get_configured_ssh_port)"
  if [ "$fw_type" = "ufw" ]; then
    echo "已检测到 UFW"
  elif [ "$fw_type" = "firewalld" ]; then
    echo "已检测到 Firewalld"
  else
    log_error "未检测到受支持的防火墙工具。"
    mgr_pause_wait
    return
  fi

  echo ""
  echo "1) 开放端口"
  echo "2) 关闭端口"
  echo "3) 查看已开放端口 / 规则"
  echo "4) 修改 SSH 端口（当前: ${current_ssh_port}）"
  if is_cn_traffic_block_enabled; then
    echo "5) 禁止访问中国大陆站点（当前: 已启用）"
  else
    echo "5) 禁止访问中国大陆站点（当前: 已关闭）"
  fi
  if is_cloudflare_proxy_only_enabled; then
    if mgr_has_direct_nezha_agent_domain; then
      echo "6) Cloudflare 源站防火墙（当前: 已开启；443 为独立 Nezha Agent 域名保留直连）"
    else
      echo "6) Cloudflare 源站防火墙（当前: 仅允许 Cloudflare 访问 80/443）"
    fi
  else
    echo "6) Cloudflare 源站防火墙（当前: 已关闭，80/443 可公网直连）"
  fi
  echo "7) Cloudflare 优选地址（当前: $(read_cfg "CF_PREFERRED_DOMAINS" | sed 's/^$/未设置/')）"
  echo "8) Cloudflare 优选地址自动抓取（当前源: $(read_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" | sed 's/^$/内置中国移动源/')）"
  echo "0) 返回"
  echo ""
  echo -n "请选择: "
  read -r choice

  local ports_input normalized_ports
  local cf_domains_input cf_source_input
  local -a tokens
  local valid_ports=()
  local token

  case "$choice" in
    1)
      echo -n "请输入要开放的端口（逗号分隔，例如 80,443,2053）: "
      read -r ports_input
      normalized_ports="$(echo "$ports_input" | sed 's/[^0-9]/,/g; s/,,*/,/g; s/^,//; s/,$//')"
      IFS=',' read -r -a tokens <<< "$normalized_ports"
      valid_ports=()
      for token in "${tokens[@]}"; do
        if [[ "$token" =~ ^[0-9]+$ ]] && [ "$token" -ge 1 ] && [ "$token" -le 65535 ]; then
          valid_ports+=("$token")
        fi
      done
      if [ "${#valid_ports[@]}" -eq 0 ]; then
        log_error "未提供有效端口。"
        mgr_pause_wait
        return
      fi

      if [ "$fw_type" = "ufw" ]; then
        ufw --force enable >/dev/null 2>&1 || true
        ufw default deny incoming >/dev/null 2>&1 || true
        ufw default allow outgoing >/dev/null 2>&1 || true
      else
        systemctl start firewalld >/dev/null 2>&1 || true
        systemctl enable firewalld >/dev/null 2>&1 || true
      fi

      firewall_apply_ssh_policy
      for token in "${valid_ports[@]}"; do
        firewall_allow_port "$token"
      done
      firewall_reload
      log_info "已开放端口: ${valid_ports[*]}（SSH $(describe_ssh_port_policy)）"
      ;;
    2)
      echo -n "请输入要关闭的端口（逗号分隔，例如 2053,12345）: "
      read -r ports_input
      normalized_ports="$(echo "$ports_input" | sed 's/[^0-9]/,/g; s/,,*/,/g; s/^,//; s/,$//')"
      IFS=',' read -r -a tokens <<< "$normalized_ports"
      valid_ports=()
      for token in "${tokens[@]}"; do
        if [[ "$token" =~ ^[0-9]+$ ]] && [ "$token" -ge 1 ] && [ "$token" -le 65535 ]; then
          valid_ports+=("$token")
        fi
      done
      if [ "${#valid_ports[@]}" -eq 0 ]; then
        log_error "未提供有效端口。"
        mgr_pause_wait
        return
      fi

      for token in "${valid_ports[@]}"; do
        firewall_remove_port "$token"
      done
      if [ "$fw_type" = "firewalld" ]; then
        systemctl start firewalld >/dev/null 2>&1 || true
        systemctl enable firewalld >/dev/null 2>&1 || true
      fi
      firewall_reload
      log_info "已关闭端口: ${valid_ports[*]}"
      ;;
    3)
      if [ "$fw_type" = "ufw" ]; then
        ufw status verbose
      else
        firewall-cmd --list-all
      fi
      ;;
    4)
      mgr_change_ssh_port
      return
      ;;
    5)
      if is_cn_traffic_block_enabled; then
        save_cfg "BLOCK_CN_TRAFFIC" "0"
        systemctl restart "$BACKEND_SERVICE"
        log_info "已关闭中国大陆站点访问阻断，并已重启后端恢复常规路由与 DNS。"
      else
        save_cfg "BLOCK_CN_TRAFFIC" "1"
        systemctl restart "$BACKEND_SERVICE"
        log_info "已启用中国大陆站点访问阻断：geosite:cn 与 geoip:cn 命中后将走 blackhole，域名解析改走 HTTPS DoH 以避免本地 DNS 泄露。"
      fi
      ;;
    6)
      if is_cloudflare_proxy_only_enabled; then
        save_cfg "CLOUDFLARE_PROXY_ONLY" "0"
        mgr_apply_firewall_for_mode "$(read_cfg "NGINX_MODE")"
        log_info "已关闭 Cloudflare 源站防火墙，当前 Nginx 模式端口恢复公网访问。"
      else
        save_cfg "CLOUDFLARE_PROXY_ONLY" "1"
        mgr_apply_firewall_for_mode "$(read_cfg "NGINX_MODE")"
        if mgr_has_direct_nezha_agent_domain; then
          log_info "已启用 Cloudflare 源站防火墙；检测到独立 Nezha Agent 通信域名，443 保持公网直连。"
        else
          log_info "已启用 Cloudflare 源站防火墙：当前模式端口仅允许 Cloudflare 边缘 IP 访问。"
        fi
        log_warn "确认 DNS 已开启小黄云；否则浏览器会无法访问面板。"
      fi
      ;;
    7)
      echo "用于订阅导出的托管 TLS 节点连接地址；SNI/Host 仍保持面板域名。"
      echo "可填多个 IP/域名，逗号分隔，例如 104.18.1.1,cmcc.example.com。留空则清除。"
      echo -n "请输入 Cloudflare 优选地址: "
      read -r cf_domains_input
      save_cfg "CF_PREFERRED_DOMAINS" "$cf_domains_input"
      if [ -n "$(read_cfg "CF_PREFERRED_DOMAINS")" ]; then
        remove_cfg "CF_PREFERRED_DOMAIN"
        log_info "已保存 Cloudflare 优选地址；订阅会为托管 TLS 节点导出对应多条线路。"
      else
        log_info "已清除 Cloudflare 优选地址。"
      fi
      ;;
    8)
      echo "默认使用内置中国移动 CMCC 优选 IP 源每 24 小时自动抓取；也可填自定义 URL 覆盖，多个 URL 用逗号分隔。"
      echo "支持纯文本、JSON、HTML 中提取 IP、IP:端口和域名。留空则恢复内置中国移动源。"
      echo -n "请输入自定义抓取源 URL: "
      read -r cf_source_input
      save_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL" "$cf_source_input"
      install_cf_preferred_domains_refresh_timer
      /usr/local/bin/xray-cf-preferred-refresh.sh || true
      if [ -n "$(read_cfg "CF_PREFERRED_DOMAINS_SOURCE_URL")" ]; then
        log_info "已保存自定义抓取源，并启用 24 小时刷新定时器。"
      else
        log_info "已恢复内置中国移动源，并启用 24 小时刷新定时器。"
      fi
      ;;
    *) ;;
  esac

  mgr_pause_wait
}

mgr_change_ssh_port() {
  clear
  echo -e "${CYAN}==== 修改 SSH 端口 ====${NC}"
  echo ""

  local fw_type current_port target_port confirm
  fw_type="$(detect_firewall_tool)"
  current_port="$(get_configured_ssh_port)"

  if [ "$fw_type" = "none" ]; then
    log_error "未检测到防火墙工具，无法安全切换 SSH 端口。"
    mgr_pause_wait
    return
  fi

  echo "当前 SSH 端口: ${current_port}"
  echo "保留规则: 先开放新端口，重载 SSH 成功后再关闭旧端口。"
  if [ -n "${PANEL_PORT:-}" ]; then
    echo "不可用端口: 80、443、${PANEL_PORT}、${FALLBACK_PORT}"
  else
    echo "不可用端口: 80、443"
  fi
  echo ""
  echo -n "请输入新的 SSH 端口: "
  read -r target_port
  target_port="$(printf "%s" "$target_port" | tr -d '[:space:]')"

  if [ -z "$target_port" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi
  if ! is_valid_port_number "$target_port"; then
    log_error "端口必须是 1-65535 之间的数字。"
    mgr_pause_wait
    return
  fi
  if is_reserved_ssh_port "$target_port"; then
    log_error "端口 ${target_port} 与当前服务冲突，请换一个。"
    mgr_pause_wait
    return
  fi
  if [ "$target_port" = "$current_port" ]; then
    log_warn "目标端口与当前一致，无需修改。"
    mgr_pause_wait
    return
  fi

  echo ""
  log_warn "继续后会把 SSH 从 ${current_port} 切换到 ${target_port}。"
  log_warn "切换成功后将关闭旧 SSH 端口 ${current_port}。"
  echo -n "请输入 YES 确认: "
  read -r confirm
  if [ "$confirm" != "YES" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi

  firewall_allow_port "$target_port"
  firewall_reload

  if ! apply_ssh_runtime_config "$target_port"; then
    firewall_remove_port "$target_port"
    firewall_reload
    mgr_pause_wait
    return
  fi

  save_cfg "SSH_PORT" "$target_port"
  firewall_apply_ssh_policy
  if [ "$current_port" != "$target_port" ] && [ "$current_port" != "22" ]; then
    firewall_remove_port "$current_port"
  fi
  firewall_reload
  setup_fail2ban

  log_info "SSH 端口已切换到 ${target_port}。后续请使用: ssh -p ${target_port} <user>@<host>"
  mgr_pause_wait
}

mgr_reset_panel_password() {
  clear
  echo -e "${CYAN}==== 重置面板账号密码 ====${NC}"
  echo ""
  init_runtime_config

  local backend_binary="${INSTALL_DIR}/${BIN_NAME}"
  local db_file="${INSTALL_DIR}/data.db"
  local current_username new_username new_password confirm_password auto_generated confirm

  if [ ! -x "$backend_binary" ]; then
    log_error "未找到后端二进制: $backend_binary"
    mgr_pause_wait
    return
  fi
  if [ ! -f "$db_file" ]; then
    log_error "未找到数据库文件: $db_file"
    mgr_pause_wait
    return
  fi

  current_username="admin"
  if mgr_ensure_sqlite3; then
    current_username="$(sqlite3 "$db_file" "SELECT COALESCE(username,'') FROM users WHERE is_admin=1 ORDER BY id LIMIT 1;" 2>/dev/null || echo "admin")"
    if [ -z "$current_username" ]; then
      current_username="admin"
    fi
  fi

  echo "当前管理员用户名: $current_username"
  echo ""
  echo -n "请输入新的管理员用户名（留空保持当前）: "
  read -r new_username
  new_username="$(printf "%s" "$new_username" | xargs)"
  if [ -z "$new_username" ]; then
    new_username="$current_username"
  fi

  auto_generated="0"
  while true; do
    echo -n "请输入新的管理员密码（留空自动生成）: "
    read -r -s new_password
    echo ""
    if [ -z "$new_password" ]; then
      new_password="$(generate_management_password)"
      auto_generated="1"
      break
    fi
    if [ "${#new_password}" -lt 8 ]; then
      log_warn "密码至少需要 8 位。"
      continue
    fi

    echo -n "请再次输入新的管理员密码: "
    read -r -s confirm_password
    echo ""
    if [ "$new_password" != "$confirm_password" ]; then
      log_warn "两次输入的密码不一致，请重试。"
      continue
    fi
    break
  done

  echo ""
  log_warn "继续后会重置管理员账号密码，并清理当前所有登录会话。"
  echo -n "请输入 YES 确认: "
  read -r confirm
  if [ "$confirm" != "YES" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi

  if (
    cd "$INSTALL_DIR" &&
    XRAY_ADMIN_RECOVERY_USERNAME="$new_username" \
    XRAY_ADMIN_RECOVERY_PASSWORD="$new_password" \
    "./${BIN_NAME}" recover-admin
  ); then
    if systemctl cat "$BACKEND_SERVICE" >/dev/null 2>&1; then
      systemctl restart "$BACKEND_SERVICE" >/dev/null 2>&1 || log_warn "后端服务重启失败，请手动执行: systemctl restart ${BACKEND_SERVICE}"
    fi
    echo ""
    log_info "面板账号密码已重置成功。"
    echo "  用户名: $new_username"
    if [ "$auto_generated" = "1" ]; then
      echo "  自动生成密码: $new_password"
      log_warn "本次密码为自动生成，请立即保存并在登录后改成你自己的密码。"
    else
      echo "  密码: 已按输入设置（不回显）"
    fi
  else
    log_error "重置面板账号密码失败。"
  fi
  mgr_pause_wait
}

mgr_disable_2fa() {
  clear
  echo -e "${CYAN}==== 关闭 2FA ====${NC}"
  echo ""
  init_runtime_config

  local backend_binary="${INSTALL_DIR}/${BIN_NAME}"
  local db_file="${INSTALL_DIR}/data.db"
  local confirm

  if [ ! -x "$backend_binary" ]; then
    log_error "未找到后端二进制: $backend_binary"
    mgr_pause_wait
    return
  fi
  if [ ! -f "$db_file" ]; then
    log_error "未找到数据库文件: $db_file"
    mgr_pause_wait
    return
  fi

  log_warn "继续后会直接关闭 2FA，并清理当前所有登录会话。"
  echo -n "请输入 YES 确认: "
  read -r confirm
  if [ "$confirm" != "YES" ]; then
    log_warn "已取消。"
    mgr_pause_wait
    return
  fi

  if (
    cd "$INSTALL_DIR" &&
    "./${BIN_NAME}" disable-admin-2fa
  ); then
    if systemctl cat "$BACKEND_SERVICE" >/dev/null 2>&1; then
      systemctl restart "$BACKEND_SERVICE" >/dev/null 2>&1 || log_warn "后端服务重启失败，请手动执行: systemctl restart ${BACKEND_SERVICE}"
    fi
    log_info "2FA 已关闭。请使用账号密码重新登录。"
  else
    log_error "关闭 2FA 失败。"
  fi
  mgr_pause_wait
}

mgr_show_menu() {
  clear
  init_runtime_config

  local server_ip panel_domain nginx_status api_prefix panel_path camouflage mode panel_public_base_url panel_public_url panel_local_url api_public_endpoint api_local_endpoint tls_node_path
  local tls_node_network reality_node_network reality_node_path
  local tg_enabled tg_status weekly_update_status ping_block_status ping_block_effective cn_block_status cloudflare_proxy_status ssh_port_status
  local nezha_status nezha_dashboard_url nezha_agent_server nezha_dashboard_domain nezha_agent_domain
  local tls_xhttp_mode reality_xhttp_mode
  server_ip="$(fetch_public_ip)"
  panel_domain="$(mgr_get_panel_domain)"
  nginx_status="$(systemctl is-active "$NGINX_SERVICE" 2>/dev/null || echo "inactive")"
  api_prefix="$(mgr_get_panel_api_prefix)"
  panel_path="$(mgr_get_panel_path)"
  camouflage="$(mgr_get_camouflage_site)"
  mode="$(mgr_get_nginx_mode)"
  tls_node_path="$(read_cfg "TLS_NODE_PATH")"
  tls_node_network="$(mgr_get_tls_node_network)"
  reality_node_network="$(mgr_get_reality_node_network)"
  reality_node_path="$(read_cfg "REALITY_NODE_PATH")"
  tls_xhttp_mode="$(mgr_get_tls_node_xhttp_mode)"
  reality_xhttp_mode="$(mgr_get_reality_node_xhttp_mode)"
  tg_enabled="$(read_cfg "TG_ALERT_ENABLED")"
  tg_status="$(systemctl is-active xray-tg-access-alert 2>/dev/null || echo "inactive")/$(systemctl is-active xray-security-monitor.timer 2>/dev/null || echo "inactive")"
  weekly_update_status="$(systemctl is-active xray-weekly-update.timer 2>/dev/null || echo "inactive")"
  ssh_port_status="$(describe_ssh_port_policy)"
  nezha_status="$(systemctl is-active "$NEZHA_DASHBOARD_SERVICE" 2>/dev/null || echo "inactive")"
  nezha_dashboard_url="$(mgr_get_nezha_dashboard_public_url)"
  nezha_agent_server="$(mgr_get_nezha_agent_server)"
  nezha_dashboard_domain="$(mgr_get_nezha_dashboard_domain)"
  nezha_agent_domain="$(mgr_get_nezha_agent_domain)"
  if is_ping_block_enabled; then
    ping_block_status="已启用"
  else
    ping_block_status="已停用"
  fi
  if is_cn_traffic_block_enabled; then
    cn_block_status="已启用"
  else
    cn_block_status="已停用"
  fi
  if is_cloudflare_proxy_only_enabled; then
    if mgr_has_direct_nezha_agent_domain; then
      cloudflare_proxy_status="已启用（保留 443 直连给 Nezha Agent）"
    else
      cloudflare_proxy_status="已启用（80/443 仅允许 Cloudflare）"
    fi
  else
    cloudflare_proxy_status="已停用"
  fi
  if [ -f /proc/sys/net/ipv4/icmp_echo_ignore_all ] && [ "$(cat /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null)" = "1" ]; then
    ping_block_effective="已生效"
  else
    ping_block_effective="等待生效"
  fi
  panel_public_base_url="$(mgr_get_panel_base_url "$panel_domain" "$server_ip" "$mode" "$nginx_status")"
  panel_public_url="$(mgr_build_panel_url "$panel_public_base_url" "$panel_path")"
  panel_local_url="http://127.0.0.1:${PANEL_PORT}/${panel_path}"

  if [ -n "$api_prefix" ]; then
    if [ -n "$panel_public_base_url" ]; then
      api_public_endpoint="${panel_public_base_url}${api_prefix}/api"
    else
      api_public_endpoint=""
    fi
    api_local_endpoint="http://127.0.0.1:${PANEL_PORT}${api_prefix}/api"
  else
    if [ -n "$panel_public_base_url" ]; then
      api_public_endpoint="${panel_public_base_url}/api"
    else
      api_public_endpoint=""
    fi
    api_local_endpoint="http://127.0.0.1:${PANEL_PORT}/api"
  fi

  echo -e "${CYAN}==============================${NC}"
  echo -e "${CYAN}         Xray 后端管理器      ${NC}"
  echo -e "${CYAN}==============================${NC}"
  echo ""

  echo -e "${GREEN}面板信息${NC}"
  echo "  服务器 IP: $server_ip"
  echo "  当前模式: $mode"
  echo "  面板后缀: /$panel_path"
  if [ -n "$panel_public_url" ]; then
    echo "  面板公网地址: $panel_public_url"
  else
    echo "  面板公网地址: 未启用（当前仅本机 / SSH 隧道可访问）"
  fi
  echo "  面板本机地址: $panel_local_url"
  echo "  API 前缀: ${api_prefix:-未生成}"
  if [ -n "$api_public_endpoint" ]; then
    echo "  API 公网地址: $api_public_endpoint"
  else
    echo "  API 公网地址: 未启用（当前仅本机 / SSH 隧道可访问）"
  fi
  echo "  API 本机地址: $api_local_endpoint"
  if [ -n "$camouflage" ]; then
    echo "  Nginx/Reality 伪装域名: $camouflage"
  else
    echo "  Nginx/Reality 伪装域名: 未设置"
  fi
  echo "  无后缀访问: $(mgr_get_root_camouflage_label)"
  echo "  带后缀访问: 面板"
  echo "  后端服务: $(systemctl is-active "$BACKEND_SERVICE" 2>/dev/null || echo 'inactive')"
  echo "  Nginx 服务: $nginx_status"
  echo "  Telegram 通知: ${tg_enabled:-0}（访问/巡检: ${tg_status}）"
  echo "  Nezha Dashboard: ${nezha_status} -> ${nezha_dashboard_url}"
  echo "  Nezha Agent 通信地址: ${nezha_agent_server}"
  echo "  Nezha 独立域名: Dashboard=${nezha_dashboard_domain:-未设置}, Agent=${nezha_agent_domain:-未设置}"
  echo "  周期更新定时器: ${weekly_update_status}"
  echo "  SSH 端口策略: ${ssh_port_status}"
  echo "  Ping 防护: ${ping_block_status}（${ping_block_effective}）"
  echo "  中国大陆站点访问阻断: ${cn_block_status}"
  echo "  Cloudflare 源站防火墙: ${cloudflare_proxy_status}"
  if [ "$mode" = "tls" ]; then
    echo "  TLS 节点路径: ${tls_node_path:-未设置}"
    echo "  TLS 节点传输: ${tls_node_network:-xhttp}"
    if [ "${tls_node_network}" = "xhttp" ]; then
      echo "  TLS XHTTP 模式: ${tls_xhttp_mode:-auto}"
    fi
  elif [ "$mode" = "reality" ]; then
    echo "  Reality 节点传输: ${reality_node_network:-xhttp}"
    if [ "${reality_node_network}" = "xhttp" ]; then
      echo "  Reality 节点路径: ${reality_node_path:-未设置}"
      echo "  Reality XHTTP 模式: ${reality_xhttp_mode:-auto}"
    fi
  fi
  echo ""

  echo -e "${BLUE}功能菜单${NC}"
  echo "  1) 防火墙管理"
  echo "  2) 绑定域名与 SSL"
  echo "  3) Nginx 管理"
  echo "  4) 重置面板账号密码"
  echo "  5) 关闭 2FA"
  echo "  6) Telegram 通知管理"
  echo "  7) Nezha Dashboard 管理"
  echo "  0) 退出"
  echo ""
  echo -n "请选择 [0-7]: "
}

manager_main() {
  require_root
  detect_os
  init_runtime_config
  install_weekly_auto_update
  install_cf_preferred_domains_refresh_timer

  while true; do
    mgr_show_menu
    read -r choice
    case "$choice" in
      1) mgr_manage_firewall ;;
      2) mgr_bind_domain ;;
      3) mgr_manage_nginx ;;
      4) mgr_reset_panel_password ;;
      5) mgr_disable_2fa ;;
      6) mgr_manage_tg_alert ;;
      7) mgr_manage_nezha_dashboard ;;
      0)
        echo ""
        log_info "已退出。"
        exit 0
        ;;
      *)
        log_error "无效选项。"
        sleep 1
        ;;
    esac
  done
}

manager_run_command() {
  local command="${1:-}"

  case "$command" in
    ""|manage|--manage)
      return 2
      ;;
    blog-normal)
      require_root
      detect_os
      init_runtime_config
      mgr_ensure_local_camouflage_template
      mgr_run_backend_command "blog-normal"
      ;;
    blog-maintenance)
      require_root
      detect_os
      init_runtime_config
      mgr_ensure_local_camouflage_template
      mgr_run_backend_command "blog-maintenance"
      ;;
    blog-publish)
      require_root
      detect_os
      init_runtime_config
      mgr_ensure_local_camouflage_template
      mgr_run_backend_command "blog-publish"
      ;;
    refresh-nginx-mode)
      require_root
      detect_os
      init_runtime_config
      mgr_refresh_active_nginx_mode
      ;;
    refresh-nezha-dashboard)
      require_root
      detect_os
      init_runtime_config
      mgr_refresh_nezha_dashboard_runtime
      ;;
    refresh-cf-preferred-domains)
      require_root
      detect_os
      init_runtime_config
      install_cf_preferred_domains_refresh_timer
      /usr/local/bin/xray-cf-preferred-refresh.sh
      ;;
    *)
      log_error "未知命令: ${command}"
      return 1
      ;;
  esac
}

installer_main() {
  echo "=============================================="
  echo "Xray 后端一键安装脚本"
  echo "=============================================="

  require_root
  detect_arch
  detect_os
  check_binary

  # Configure swap before package upgrades/downloads so low-memory VPSes
  # have breathing room during the heaviest install steps.
  setup_swap
  get_server_ip

  log_step "Installing base packages"
  install_packages

  harden_ssh
  enable_bbr
  setup_firewall
  set_timezone
  install_xray_core
  install_mihomo_core
  install_nginx
  install_backend_service
  mgr_install_nezha_dashboard || log_warn "Nezha Dashboard 自动部署失败，可稍后在 xy 菜单中重试。"
  setup_fail2ban
  install_weekly_auto_update
  install_cf_preferred_domains_refresh_timer
  install_management_tool
  print_summary
}

is_manage_mode() {
  local arg1="${1:-}"
  if [ "$SCRIPT_NAME" = "xy" ]; then
    return 0
  fi
  if [ "$arg1" = "manage" ] || [ "$arg1" = "--manage" ]; then
    return 0
  fi
  return 1
}

is_overlay_update_mode() {
  local arg1="${1:-}"
  case "$arg1" in
    upgrade|overlay-update|overlay-install)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

main() {
  local manage_command status
  if is_manage_mode "${1:-}"; then
    if [ "$SCRIPT_NAME" = "xy" ]; then
      manage_command="${1:-}"
    else
      manage_command="${2:-}"
    fi

    # Keep this inside an if-statement so set -e does not abort before we can
    # distinguish "run interactive manager" (status 2) from real failures.
    if manager_run_command "$manage_command"; then
      exit 0
    else
      status=$?
      if [ "$status" -ne 2 ]; then
        exit "$status"
      fi
    fi
    manager_main
  elif is_overlay_update_mode "${1:-}"; then
    overlay_update_main
  else
    installer_main
  fi
}

main "$@"
